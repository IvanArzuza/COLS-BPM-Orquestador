package com.sap.bie.sca.scdl.contributors.glx;

import java.io.File;
import java.text.MessageFormat;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.IReference;
import com.sap.bie.sca.scdl.adapter.IScdlContributor;
import com.sap.bie.sca.scdl.adapter.glx.GalaxyImplementation;
import com.sap.bie.sca.scdl.adapter.impl.Component;
import com.sap.bie.sca.scdl.adapter.impl.Composite;
import com.sap.bie.sca.scdl.gen.mc.IMcReferenceGenerator;
import com.sap.bie.sca.scdl.gen.mc.McReferenceGeneratorFactory;
import com.sap.bie.sca.scdl.gen.mc.NoSuchServiceReferenceExistsException;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.ide.es.config.mc.model.mc.logicalsystem.LogicalSystem;
import com.sap.ide.es.config.mc.model.mc.logicalsystem.Qname;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.esmp.mm.wsdl2.Description;
import com.sap.tc.esmp.mm.wsdl2.Interface;
import com.sap.tc.esmp.tools.wsdlexport.ServiceDescriptionExtended;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1Exporter;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1ExporterProvider;
import com.sap.tc.esmp.tools.wsdlexport.WsdlExportException;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.MRI;

public class GalaxyScdlContributor implements IScdlContributor {
	private static final String WSDLS = "wsdls/"; //$NON-NLS-1$
	protected static final String LOG_PREFIX = "		[SCDL_GEN-GALAXY]"; //$NON-NLS-1$
	protected static final String LOG_PREFIX_ERROR = LOG_PREFIX + " ERROR:"; //$NON-NLS-1$
	protected static final String LOG_PREFIX_WARN = LOG_PREFIX + " WARNING:"; //$NON-NLS-1$
	private static final String DUMMY_COMPONENT_NAME = "BPMcomponent"; //$NON-NLS-1$
	private static final String SRC_WSDL = "src/wsdl/";
	private Connection connection;
	private IGlobalPluginUtil globalPluginUtil;
	private IPluginBuildInfo pluginBuildInfo;
	private CRI cri;
	
	public IComposite getComposite(Connection connection, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) 
	{
		setParams(connection, globalPluginUtil, pluginBuildInfo);
		
		final Composite composite = new Composite(pluginBuildInfo.getDCName());
		
		cri = createCRI(pluginBuildInfo.getDCName(), pluginBuildInfo.getDCVendor());
		
		try {			
			/*
			 * The commented part is the old way of generating the scdl file. In the past, all processes
			 * were collected and a component was created for each.
			 * In the new solution there is only one dummy component created.
			 */
//			Collection<Collaboration> processes = ToolUtils.getInstance().queryByType(connection, 
//					Collaboration.class, new String[] { "Galaxy", "Workflow", "Collaboration" }, true, cri); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
			
			// Creating a component item for each process
//			for(Collaboration coll: processes){
//				final IComponent component = createGalaxyComponent(coll);
//				if (component.getReferences().size() > 0) {
//					composite.addComponent(component);
//				}
//			}
			
			// Only one dummy component is created
			final IComponent component = createDummyGalaxyComponent();
			composite.addComponent(component);
			
		} catch (NoSuchServiceReferenceExistsException e) {
			final String message = "{0} Generation of component references failed as service reference id {1} cannot be found in designtime metamodel !"; //$NON-NLS-1$
			Log.error(MessageFormat.format(message, LOG_PREFIX_ERROR, e.getMessage()));
		}
		
		return composite;
	}
	
	/*
	 * Creates a dummy component, with a predefined name, and includes all Service References
	 */
	private IComponent createDummyGalaxyComponent()  throws NoSuchServiceReferenceExistsException
	{
		final GalaxyImplementation impl = new GalaxyImplementation();
		
		final String COMPONENT_NAME = tildeName(pluginBuildInfo.getDCVendor()) + "~" + tildeName(pluginBuildInfo.getDCName()) + "~" + DUMMY_COMPONENT_NAME;
		final Component component = new Component(COMPONENT_NAME, impl);
		addReferences(component);
		
		return component;
	}

	/*
	 * Old way of creating the component tags, deprecated
	 */
//	@Deprecated
//	private IComponent createGalaxyComponent() throws NoSuchServiceReferenceExistsException 
//	{
//		final GalaxyImplementation impl = new GalaxyImplementation();
//		
//		final Component component = new Component(getComponentName(coll), impl);
//		addReferences(coll, component);
//		
//		return component;
//	}
	
//	private String getComponentName(final Collaboration coll) {
//		return tildeName(pluginBuildInfo.getDCVendor()) + "~" 
//			+ tildeName(pluginBuildInfo.getDCName()) + "#" + coll.getOriginalName(); //$NON-NLS-1$ //$NON-NLS-2$
//	}

	private void addReferences(final Component component) throws NoSuchServiceReferenceExistsException 
	{
		final IMcReferenceGenerator generator = createRefGenerator();
		
		final Map<String, String> refInfo = collectServiceReferences();
		
		List<IReference> references =null;
		for(String srId : refInfo.keySet()) {
			if(refInfo.get(srId)!=null && refInfo.get(srId).length()>0) {
				references = generator.genReferences(new String[]{ srId }, new String[] { refInfo.get(srId) });
			}
			else {
				references = generator.genReferences(new String[]{ srId } );
			}
					
			for (IReference reference : references) {
				component.addReference(reference);
			}
		}
	}
	
	private Map<String, String> collectServiceReferences() {
		Collection<ServiceReference> services = ToolUtils.getInstance().queryByType(connection, 
				ServiceReference.class, new String[] { "mc", "servicereferences", "ServiceReference" }, true, cri);  //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
		
		Map<String, String> refInfo = new HashMap<String, String>();
		
		for(ServiceReference serv: services){
			StringBuffer wsdlLocationBuf = new StringBuffer();
			
			String location = getWsdlLocation(serv);
			
			// if empty String is returned, skip this reference
			if ("".equals(location)) 
			{ 
				continue; 
			}
			
			String inBpemLocation = getInBpemLocation(serv, location);
			//Log.info("inBpemLocation: " + inBpemLocation);
			wsdlLocationBuf.append(getBpemName(serv)).append(inBpemLocation);
			String srId = serv.getId();
			if(srId!=null) {
			  refInfo.put(srId, wsdlLocationBuf.toString());
			}
		}
		
		return refInfo;
	}

	/*
	 * return the location inside .bpem archive
	 * "wsdls/<dcVendor>~<dcName>/<wsdl filename>"
	 */
	private String getInBpemLocation(ServiceReference serv, String location) {
		String ret = null;
		String filename = null;
        if (location.startsWith(SRC_WSDL)) {
            filename = location.substring(SRC_WSDL.length());
        } else {
            filename = (new File(location)).getName();
        }

		StringBuilder builder = new StringBuilder(WSDLS);
		final String message = "Inconsistent servicereferences.servicerefs file: ";
		if (null == serv) {
			throw new IllegalArgumentException(
					"ServiceReference must not be null");
		}
		LogicalSystem system = serv.getLogicalSystem();
		if (null == system) {
			throw new IllegalArgumentException(
					MessageFormat.format(message
							+ "Logical System is missing for service reference id = {0}",
							serv.getId()));
		}
		MRI mri = system.get___Mri();
		if (null == mri) {
			throw new IllegalArgumentException(MessageFormat.format(
					"MRI is missing for Logical System id = {0}", system
					.getGuid()));
		}
		String containerName = mri.getContainerName();
		if (null == containerName) {
			throw new IllegalArgumentException("Container Name is missing");
		}
		ret = builder.append(tildeName(containerName)).append("/").append(
				filename).toString();
		return ret;
	}

	private String getBpemName(ServiceReference serv) {
		//return tildeName(serv.getLogicalSystem().get___Mri().getContainerName()) + ".bpem#"; //$NON-NLS-1$ //$NON-NLS-2$
		return tildeName(pluginBuildInfo.getDCVendor()) + "~" 
		+ tildeName(pluginBuildInfo.getDCName()) + ".bpem#"; //$NON-NLS-1$ //$NON-NLS-2$
	}
	
	private String getWsdlLocation(final ServiceReference servRef) {
		ServiceDescriptionExtended<String> desc = null;

		
		Qname portType = servRef.getPorttype();
		String nameSpace = portType.getNamespace();
		String localName = portType.getName();
		//Log.info("portType: " + portType.toString());
		QName qName = new QName(nameSpace, localName);
		//Log.info("qName: " + qName.toString());
		Interface i = ToolUtils.getInstance().findServiceInterface(connection, Interface.class, qName);
		
		// if the interface cannot be found, return empty String
		if (i==null) { return ""; }
		
		Wsdl1Exporter<String> exporter = null;
		try {
			exporter = Wsdl1ExporterProvider.getWsdl1Exporter(null);
			Description d = i.getDescriptions().iterator().next();
			desc = exporter.getExtendedServiceDescription(d);
		} catch (WsdlExportException e) {
			Log.warn("WsdlExportException is thrown during SCDL generation");
		}
		
		if (desc!=null){
			String wsdl_rootfile = desc.getRootWsdl1Document().getLocation();
			return wsdl_rootfile;
		}
		else {
			return "";
		}
	}
	private IMcReferenceGenerator createRefGenerator() {
		return McReferenceGeneratorFactory.getInstance().newMCReferenceGenerator(connection, globalPluginUtil, pluginBuildInfo);
	}
	
	private CRI createCRI(String name, String vendor){
		return connection.getSession().getMoin().createCri("PF", "DefaultDataArea", vendor + "/" + name); //$NON-NLS-1$
	}
	
	private void setParams(Connection connection, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) 
	{
		GalaxyScdlContributor.nullCheckParam(connection, "connection"); //$NON-NLS-1$
		GalaxyScdlContributor.nullCheckParam(globalPluginUtil, "globalPluginUtil"); //$NON-NLS-1$
		GalaxyScdlContributor.nullCheckParam(pluginBuildInfo, "pluginBuildInfo"); //$NON-NLS-1$
		
		this.connection = connection;
		this.globalPluginUtil = globalPluginUtil;
		this.pluginBuildInfo = pluginBuildInfo;
	}
	
	public static void nullCheckParam(final Object paramValue, final String paramName)
	{
		if (paramName == null) {
			throw new NullPointerException("paramName must not be null"); //$NON-NLS-1$ 
		}
		
		if (paramValue == null) {
			throw new NullPointerException(paramName + " must not be null"); //$NON-NLS-1$ 
		}
	}
	
	public static void emptyStringCheckParam(final String param, final String varName) 
	{
		nullCheckParam(param, varName);
		
		if (param.trim().length() == 0) {
			throw new IllegalArgumentException(MessageFormat.format("Parameter {0} is empty string or contains only white spaces", varName)); //$NON-NLS-1$
		}
	}
	
	private String tildeName(String name){
		return name.replace('/', '~');
	}
}
