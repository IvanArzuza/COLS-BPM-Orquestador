package com.sap.bie.sca.scdl.contributors.glx;

import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pp.api.IComponentDependencies;
import com.sap.tc.buildplugin.pp.api.IComponentDependency;

public class MassConfDependencyChecker {

	private static final String BIE_SCA_SCDL_GEN = "bie/sca/scdl/gen";
	private static final String TC_BI_MCTECH = "tc/bi/mctech";

	IPluginBuildInfo pluginBuildInfo;
	
	public MassConfDependencyChecker(IPluginBuildInfo pluginBuildInfo) {
		this.pluginBuildInfo = pluginBuildInfo;
		}
	
	/*
	 * Returns true if dependencies are OK
	 */
	public boolean checkDependencies() {
		boolean mctech = false;
		boolean scdl = false;
		
		IComponentDependencies dependencies = pluginBuildInfo.getDependencies();
		
		for (IComponentDependency dep: dependencies){
			Log.info("dep: " + dep.getComponentName());
			if (TC_BI_MCTECH.equals(dep.getComponentName()) && dep.isAtBuild()){
				Log.info("mctech true");
				mctech = true;
			}
			else if (BIE_SCA_SCDL_GEN.equals(dep.getComponentName()) && dep.isAtBuild()){
				Log.info("scdl true");
				scdl = true;
			}
		}
		
		return !(mctech && scdl);
	}

}
