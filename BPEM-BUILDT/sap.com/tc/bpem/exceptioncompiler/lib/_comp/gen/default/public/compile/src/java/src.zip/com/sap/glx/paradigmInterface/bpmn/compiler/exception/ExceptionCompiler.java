package com.sap.glx.paradigmInterface.bpmn.compiler.exception;

import static com.sap.glx.constants.SharedCompilerConstants.COMMA_IDENTIFIER;
import static com.sap.glx.constants.SharedCompilerConstants.EXCEPTION_COMPILER_VERSION_IDENTIFIER;
import static com.sap.glx.constants.SharedCompilerConstants.LINE_SEPARATOR;
import static com.sap.glx.constants.SharedCompilerConstants.NETWORK_IDENTIFIER;
import static com.sap.glx.constants.SharedCompilerConstants.REVISIONID_IDENTIFIER;
import static com.sap.glx.constants.SharedCompilerConstants.SCOPE_IDENTIFIER;
import static com.sap.glx.constants.SharedCompilerConstants.UTF_8;

import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Arrays;
import java.util.LinkedList;

import javax.xml.namespace.QName;

import com.sap.glx.constants.RevisionConstants;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.IdentifierHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.util.ExceptionIdCalculator;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdTypeDefinition;

public class ExceptionCompiler implements ICompiler {

    private static final int EXCEPTION_COMPILER_VERSION = 2;

    private static final String PRODUCT_VERSION_STRING = "Galaxy exception compiler as of NetWeaver CE "
            + RevisionConstants.getBuildVersion();

    public static final String EXTENSION = "err"; //$NON-NLS-1$

    public static final String EXCEPTION_ADAPTER = CompilerConstants.ADAPTER_EXCEPTION;
    public static final String EXCEPTION_CLASS = CompilerConstants.GALAXY_EXCEPTION;

    private Iterable<XsdElementDeclaration> scope = null;

    /**
     * The exception compiler is handling SOAP faults.
     */
    public boolean canCompile(final Object artifact) {
        return (artifact instanceof ErrorEventDefinition);
    }

    /**
     * Generates CSV to be digested by the Exception adapter: NETWORK,<exception version>,<fault name> -- CONFIG -- <exception
     * class>,<exception version>,SCOPE=<scope version> <exception class>,<exception version>,ROOT,NAME=<root element name> <exception
     * class>,<exception version>,ROOT,NAMESPACE=<root element ns>
     */
    public boolean compile(final IBuilderHost host, final Object artifact) throws Exception {
        final ErrorEventDefinition exception = (ErrorEventDefinition) artifact;
        final String scopeId = host.getVersionId(scope, CompilerType.TYPECOMPILER);
        final Pair<String, String> result = compileException(exception, scopeId);
        host.setVersionId(artifact, result.first); // tell it to the build plugin

        final String filename = IdentifierHelper.createFilename(exception, EXTENSION);
        OutputStream stream = null;
        Writer writer = null;

        try {
            stream = host.createVersionedTargetFile(filename, artifact);
            writer = new OutputStreamWriter(stream, UTF_8);
            writer.write(result.second);
        } finally {
            if (writer != null) {
                writer.flush();
                writer.close();
            }

            if (stream != null) {
                stream.flush();
                stream.close();
            }
        }

        return true;
    }

    public Object[] getDependencies(final IBuilderHost host, final Object artifact) {
        if (canCompile(artifact)) {
            final ErrorEventDefinition error = (ErrorEventDefinition) artifact;
            scope = new LinkedList<XsdElementDeclaration>(Arrays.asList(error.getWsdlFault() == null ? error.getParameter() : error
                    .getWsdlFault().getElement()));
            return new Object[] { scope };
        }
        return new Object[0];
    }

    Pair<String, String> compileException(final ErrorEventDefinition exception, final String scopeId) throws BpemBuildException {
        XsdElementDeclaration element = (exception.getWsdlFault() == null) ? exception.getParameter() : exception.getWsdlFault()
                .getElement();
        if (exception.getWsdlFault() == null) {
            element = exception.getParameter();
        } else {
            element = exception.getWsdlFault().getElement();
        }
        if (element == null) {
            throw new BpemBuildException("BPM.rt_c_exc.000000", //$NON-NLS-1$
                    String.format("Cannot compile exception '%s' without root element", exception.getOriginalName())); //$NON-NLS-1$
        }

        final XsdTypeDefinition type = WSDLHelper.getElementType(element);
        if (type == null) {
            throw new BpemBuildException("BPM.rt_c_exc.000001", //$NON-NLS-1$
                    String.format("Cannot compile exception '%s' without root type", exception.getOriginalName())); //$NON-NLS-1$
        }

        final QName sdoType = SDOHelper.generateSDOName(type);

        return createTriggerNet(exception, scopeId, element.getName(), element.getNamespace(), sdoType.getLocalPart(), sdoType
                .getNamespaceURI());
    }

    Pair<String, String> createTriggerNet(final ErrorEventDefinition exception, final String scopeId, final String name,
            final String namespace, final String typeLocalPart, final String typeNamespace) {

        final ExceptionIdCalculator exceptionIdCalculator = new ExceptionIdCalculator();
        exceptionIdCalculator.setCritical(exception.isCritical());
        exceptionIdCalculator.setMofId(exception.refMofId());
        exceptionIdCalculator.setRootElementName(name);
        exceptionIdCalculator.setRootElementNamespace(namespace);
        exceptionIdCalculator.setRootElementTypeName(typeLocalPart);
        exceptionIdCalculator.setRootElementTypeNamespace(typeNamespace);
        exceptionIdCalculator.setScopeId(scopeId);
        exceptionIdCalculator.setEventTriggerName(exception.getOriginalName());
        final String version = exceptionIdCalculator.calculateId();

        final StringBuilder sb = new StringBuilder();
        sb
                .append(String
                        .format(
                                "# %s error event definition %s (MOFId: %s)" + LINE_SEPARATOR, exception.isCritical() ? "Critical" : "Non-critical", exception //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
                                        .getOriginalName(), exception.refMofId()));
        sb.append(NETWORK_IDENTIFIER + version + COMMA_IDENTIFIER + exception.getOriginalName() + LINE_SEPARATOR); //$NON-NLS-1$ //$NON-NLS-2$

        sb.append(REVISIONID_IDENTIFIER);
        sb.append(RevisionConstants.REVISION_MAJOR);
        sb.append(COMMA_IDENTIFIER);
        sb.append(RevisionConstants.REVISION_MINOR);
        sb.append(COMMA_IDENTIFIER);
        sb.append(PRODUCT_VERSION_STRING);
        sb.append(LINE_SEPARATOR);

        sb.append("-- CONFIG --" + LINE_SEPARATOR); //$NON-NLS-1$
        sb
                .append("CONFIG," + EXCEPTION_ADAPTER + COMMA_IDENTIFIER + EXCEPTION_CLASS + COMMA_IDENTIFIER + version + COMMA_IDENTIFIER + SCOPE_IDENTIFIER //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                        + scopeId + LINE_SEPARATOR); //$NON-NLS-1$
        sb
                .append("CONFIG," + EXCEPTION_ADAPTER + COMMA_IDENTIFIER + EXCEPTION_CLASS + COMMA_IDENTIFIER + version + COMMA_IDENTIFIER + CompilerConstants.CONFIG_ROOT //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                        + COMMA_IDENTIFIER + CompilerConstants.CONFIG_NAME + "=" + name + LINE_SEPARATOR); //$NON-NLS-1$//$NON-NLS-2$
        sb
                .append("CONFIG," + EXCEPTION_ADAPTER + COMMA_IDENTIFIER + EXCEPTION_CLASS + COMMA_IDENTIFIER + version + COMMA_IDENTIFIER + CompilerConstants.CONFIG_ROOT //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                        + COMMA_IDENTIFIER + CompilerConstants.CONFIG_NAMESPACE + "=" + namespace + LINE_SEPARATOR); //$NON-NLS-1$//$NON-NLS-2$
        sb
                .append("CONFIG," + EXCEPTION_ADAPTER + COMMA_IDENTIFIER + EXCEPTION_CLASS + COMMA_IDENTIFIER + version + COMMA_IDENTIFIER + CompilerConstants.CONFIG_ROOT //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                        + COMMA_IDENTIFIER + CompilerConstants.CONFIG_TYPE + "=" + typeLocalPart + LINE_SEPARATOR); //$NON-NLS-1$//$NON-NLS-2$
        sb
                .append("CONFIG," + EXCEPTION_ADAPTER + COMMA_IDENTIFIER + EXCEPTION_CLASS + COMMA_IDENTIFIER + version + COMMA_IDENTIFIER + CompilerConstants.CONFIG_ROOT //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
                        + COMMA_IDENTIFIER + CompilerConstants.CONFIG_TYPENAMESPACE + "=" + typeNamespace + LINE_SEPARATOR); //$NON-NLS-1$//$NON-NLS-2$
        sb
                .append("CONFIG," + EXCEPTION_ADAPTER + COMMA_IDENTIFIER + EXCEPTION_CLASS + COMMA_IDENTIFIER + version + COMMA_IDENTIFIER + CompilerConstants.CONFIG_ROOT + COMMA_IDENTIFIER + EXCEPTION_COMPILER_VERSION_IDENTIFIER + EXCEPTION_COMPILER_VERSION + LINE_SEPARATOR); //$NON-NLS-1$

        return new Pair<String, String>(version, sb.toString());
    }
}
