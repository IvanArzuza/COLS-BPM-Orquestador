package com.sap.glx.generator;

import java.awt.geom.Point2D;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

import com.sap.tc.moin.repository.mmi.reflect.RefObject;

import com.sap.glx.generator.api.ILocation;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.workflow.Activity;
import com.sap.glx.ide.model.galaxy.workflow.Annotation;
import com.sap.glx.ide.model.galaxy.workflow.AnnotationConnector;
import com.sap.glx.ide.model.galaxy.workflow.ArtificialLoopScope;
import com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity;
import com.sap.glx.ide.model.galaxy.workflow.BoundaryEvent;
import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.ide.model.galaxy.workflow.ConditionalSequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.Lane;
import com.sap.glx.ide.model.galaxy.workflow.LaneProcessRole;
import com.sap.glx.ide.model.galaxy.workflow.LoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowConnector;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.MultiInstanceLoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.PoolReference;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.TextVariable;
import com.sap.glx.ide.model.galaxy.workflow.UncontrolledJoinGateway;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.mi.gfw.mm.datatypes.Point;
import com.sap.mi.gfw.mm.pictograms.Anchor;
import com.sap.mi.gfw.mm.pictograms.AnchorContainer;
import com.sap.mi.gfw.mm.pictograms.Connection;
import com.sap.mi.gfw.mm.pictograms.ConnectionDecorator;
import com.sap.mi.gfw.mm.pictograms.Diagram;
import com.sap.mi.gfw.mm.pictograms.FreeFormConnection;
import com.sap.mi.gfw.mm.pictograms.GraphicsAlgorithm;
import com.sap.mi.gfw.mm.pictograms.PictogramElement;
import com.sap.mi.gfw.mm.pictograms.Shape;
import com.sap.tc.esmp.mm.wsdl2.Interface;
import com.sap.tc.esmp.mm.wsdl2.Operation;

/**
 * Compiler to generate .procvis files. The file contains the XML description of 
 * the collaboration.
 * 
 * @author I043996
 * 
 */
public class DiagramToXMLConverter {
	
    private static String START = "\""; //$NON-NLS-1$
    
    private static String END = "\""; //$NON-NLS-1$
    
    protected static int HORIZONTAL_ORIENTATION = 0x04;
    
    protected static int VERTICAL_ORIENTATION = 0x05;
    
    protected final static int POOL_HEADER = 27;
    
    protected final static int ABSOLUTE = 0x01;
    
    protected final static int RELATIVE = 0x02;
    

    String XML_ELEMENT_CLOSING_TAG = ">"; //$NON-NLS-1$
    String EQUAL = "="; //$NON-NLS-1$
    String BOUNDARYEVENT_ELEMENT_CLOSE = "</BoundaryEvent>"; //$NON-NLS-1$
    String NODE_ELEMENT_CLOSE = "</Node>"; //$NON-NLS-1$
    String POOL_ELEMENT_CLOSE = "</Pool>"; //$NON-NLS-1$
    String CONNECTOR_ELEMENT_CLOSE = "</Connector>"; //$NON-NLS-1$
    
    private int iOrientation = DiagramToXMLConverter.HORIZONTAL_ORIENTATION;

    // stores the new line character from line.separator system property
    private String iNewLine = null;
    private Diagram iDiagram = null;

    private Hashtable<String, Pool> iPoolStorage = null;
    private Hashtable<String, Lane> iLaneStorage = null;
    private Hashtable<Lane, Vector<Annotation>> iAnnotationStorage = new Hashtable<Lane, Vector<Annotation>>();
    private Lane iCurrentLane = null;
    private Vector<Annotation> iAnnotationVectors = new Vector<Annotation>();
    private Hashtable<RefObject, PlStore> iRefObjectStore = new Hashtable<RefObject, PlStore>();
    
    //refMofID of the Activity, Vector of BoundaryEvents
    private Hashtable<String,Vector<BoundaryEvent>> iBoundaryEvents = new Hashtable<String, Vector<BoundaryEvent>>();

    // variable to store the LaneObject and the associated DataObjects
    private Hashtable<RefObject, ArrayList<DataObject>> iDataObjectAssociation = new Hashtable<RefObject, ArrayList<DataObject>>();

    // variable for the generated XML
    private StringBuilder iBuffer = new StringBuilder(1000);

    // variable to store whether the current pool which is processed is the
    // default one or not
    boolean isCurrenPoolDefault = false;

    /*
     * stores the active pool's id. This information will be inserted in the tag of the Collaboration
     */
    private String iActivePoolId = ""; //$NON-NLS-1$

    final static byte[] NIL_ID = new byte[] { (byte) 0xd4, 0x1d, (byte) 0x8c, (byte) 0xd9, (byte) 0x8f, 0x00, (byte) 0xb2, 0x04, (byte) 0xe9, (byte) 0x80,
            0x09, (byte) 0x98, (byte) 0xec, (byte) 0xf8, 0x42, 0x7e };

    // stores the right shift value
    private int iRightShift = 10;

    // stores the down shift value
    private int iDownShift = 10;

    // stores the highest X value
    private int iHighestX = 0;

    // stores the highest y value
    private int iHighestY = 0;
//	private StringBuilder builder;

    // available node types in the workbench
    @SuppressWarnings("nls")
    public enum NodeType {
        HUMANACTIVITY("HumanActivity"),
        AUTOMATEDACTIVITY("AutomatedActivity"),
        SUBWORKFLOW("SubWorkflow"),
        STARTEVENT("StartEvent"),     
        INTERMEDIATE_MESSAGE_EVENT("IntermediateMessageEvent"),
        ENDEVENT("EndEvent"), 
        EXCLUSIVECHOICE("ExclusiveChoice"),
        INCLUSIVECHOICE("InclusiveChoice"),
        UNCONTROLLEDMERGE("UncontrolledMerge"),
        PARALELSPLIT("ParallelSplit"),
        SYNCHRONIZATION("Synchronization"),
        DEFEREDCHOICE("DeferredChoice"),
        DATAOBJECT("DataObject"), 
        ANNOTATION("Annotation"),
        LANE("Lane"),
        POOL("Pool"),  
        EVENTIONBOUNDARYEVENT("IntermediateErrorEvent"), 
        RAISEEVENT(""),
        TIMER_INTERMEDIATE_EVENT("IntermediateTimerEvent"),
        ERROR_END_EVENT("ErrorEndEvent"),
        INTERMEDIATE_ERROR_EVENT("IntermediateErrorEvent"),
        NOTIFICATION_ACTIVITY("NotificationActivity"),
        REPORTING_ACTIVITY("ReportingActivity"),
        ABSTRACT_STARTEVENT("AbstractStartEvent"),
        ESCALATION_END_EVENT("EscalationEndEvent"),
        ABSTRACT_ENDEVENT("AbstractEndEvent"),
        BOUNDARY_ESCALATION_EVENT("IntermediateEscalationEvent"),
        BOUNDARY_ERROR_EVENT("IntermediateErrorEvent"),
        TERMINATION_END_EVENT("TerminationEndEvent");
       
        private String iNodeType = null;

        NodeType(String aNodeType) {
            this.iNodeType = aNodeType;
        }

        public String type() {
            return this.iNodeType;
        }

    }

    /**
     * Default constructor
     * 
     */
    public DiagramToXMLConverter() {
        // get the new line - OS dependent
        this.iNewLine = System.getProperty("line.separator"); //$NON-NLS-1$
        this.iPoolStorage = new Hashtable<String, Pool>();
        this.iLaneStorage = new Hashtable<String, Lane>();
    }

    /**
     * Inner class to store the lane and it's pool"s start coordinates. The class is used in the preparse method to
     * store the ScopeObject and it's lane and pool's x,y coordinate. These coordinates are calculated in the preparse()
     * method, and are used during the .procvis file content generation.
     * 
     * @author I043996
     */
    class PlStore {
        private int poolX;
        private int poolY;
        private int laneX;
        private int laneY;

        public PlStore(int px, int py, int lx, int ly) {
            poolX = px;
            poolY = py;
            laneX = lx;
            laneY = ly;
        }

        public int getPoolX() {
            return poolX;
        }

        public void setPoolX(int poolX) {
            this.poolX = poolX;
        }

        public int getPoolY() {
            return poolY;
        }

        public void setPoolY(int poolY) {
            this.poolY = poolY;
        }

        public int getLaneX() {
            return laneX;
        }

        public void setLaneX(int laneX) {
            this.laneX = laneX;
        }

        public int getLaneY() {
            return laneY;
        }

        public void setLaneY(int laneY) {
            this.laneY = laneY;
        }
    }

    /*
     * Pre-parse the available lane objects. The method is used to make a calculation of the x and y coordinates of the
     * lanes and pools. For each ScopeObject, it's lane and pool's coordinate is stored in a Hashtable (Hashtable<RefObject,
     * PlStore>). During the XML generation, the ScopeObject's coordinates are calculated by the content of this
     * Hashtable.
     * 
     * @param Diagram the diagram @param Workflow the collaboration
     */
    @SuppressWarnings({ "unchecked", "null" })
	public void preParse(Diagram aDiagram, Collaboration collaboration) {
        PVUtil.log("PV file generation: parsing..."); //$NON-NLS-1$
        int _currentPoolCoordinateX = 0;
        int _currentPoolCoordinateY = 0;
        int _currentLaneCoordinateX = 0;
        int _currentLaneCoordinateY = 0;
        int _laneNr = 0;
        int _poolNr = 1;
        // int _prevLaneWidth = 0;

        this.getWfOrientation(aDiagram);
        for (Pool pool : collaboration.getPools()) {
            // check if this is the active pool, and store the id
            if (pool.isActive()) {
                this.iActivePoolId = pool.refMofId();
            }
            _laneNr = 0;
            _currentPoolCoordinateX = PVUtil.getXCoordinate(pool);
            _currentPoolCoordinateY = PVUtil.getYCoordinate(pool);
            this.checkXForShift(_currentPoolCoordinateX);
            this.checkYForShift(_currentPoolCoordinateY);
            /* put the pool to the iRefObjectStore too, because it will
             * be used when the message flow start or end point is from
             * a pool
             */
            this.iRefObjectStore.put(pool, new PlStore(_currentPoolCoordinateX, _currentPoolCoordinateY, 0,0));
            
            // if the pool not default pool, then calculate the highest points of it
            if (pool.isBoundaryVisible()) {
                this.checkForHighestXCoordinate(_currentPoolCoordinateX + PVUtil.getRefObjectWidth(pool));
                this.checkForHighestYCoordinate(_currentPoolCoordinateY + PVUtil.getRefObjectHeight(pool));
            }
            for (ScopeObject po : pool.getScopeObjects()) {
                if (po instanceof Lane) {
                    Lane _lane = (Lane) po;
                    _currentLaneCoordinateX = 0;
                    _currentLaneCoordinateY = 0;
                    _currentLaneCoordinateY = 0;
                    _currentLaneCoordinateX = 0;
                    _currentLaneCoordinateX = PVUtil.getXCoordinate(po);
                    _currentLaneCoordinateY = PVUtil.getYCoordinate(po);
                    _currentLaneCoordinateX += _currentPoolCoordinateX;
                    _currentLaneCoordinateY += _currentPoolCoordinateY;

                    // add new PlStore to the iRefObjectStore
                    this.iRefObjectStore.put(_lane, new PlStore(_currentPoolCoordinateX+this.iRightShift,
									                    		_currentPoolCoordinateY+this.iDownShift,
									                    		_currentLaneCoordinateX,
									                            _currentLaneCoordinateY));
                    for (ScopeObject _laneObj : _lane.getScopeObjects()) {
                    	if(!(_laneObj instanceof BoundaryEvent) && !this.toGenerate(_laneObj))continue;
                        if (!(_laneObj instanceof LaneProcessRole)) {
                            this.checkXForShift(PVUtil.getXCoordinate(_laneObj));
                            this.checkYForShift(PVUtil.getYCoordinate(_laneObj));
                            // calculate the position and check for highest
                            this.checkForHighestXCoordinate(_currentPoolCoordinateX + PVUtil.getXCoordinate(_laneObj) + PVUtil.getRefObjectWidth(_laneObj));
                            this.checkForHighestYCoordinate(_currentPoolCoordinateY + PVUtil.getYCoordinate(_laneObj) + PVUtil.getRefObjectHeight(_laneObj));
                            List<SequenceConnector> list = _laneObj.getOutgoingConnectors();
                            if (list != null) {
                                for (SequenceConnector connector : list) {
                                    this.checkBendPointsForShift(connector);
                                }
                            }
                        }
                        // check if it is a DataObject
                        if (_laneObj instanceof DataObject) {
                            // calculate the position and check for highest
                            this.checkForHighestXCoordinate(_currentPoolCoordinateX + PVUtil.getXCoordinate(_laneObj) + PVUtil.getRefObjectWidth(_laneObj));
                            this.checkForHighestYCoordinate(_currentPoolCoordinateX + PVUtil.getYCoordinate(_laneObj) + PVUtil.getRefObjectHeight(_laneObj));
                            Collection<Connection> _conn = new Vector<Connection>();
                            Shape _shape = (Shape) PVUtil.getPictogramElement(_laneObj);
                            if(_shape!=null) {//in case of loop data objects it is null
	                            for (Anchor a : _shape.getAnchors()) {
	                                for (Connection _c : a.getIncomingConnections()) {
	                                    _conn.add(_c);
	                                }
	                            }
                            }
                            if (_conn.size() != 0) {
                            	for(int i=0;i<_conn.size();i++) {
                            		Connection _connection = (Connection) ((Vector)_conn).get(i);
	                                PictogramElement _pe = _connection.getStart().getParent();
	                                Object _obj = PVUtil.getBusinessObject(_pe);
	                                ArrayList<DataObject> list = this.iDataObjectAssociation.get((RefObject) _obj);
	                                if (list == null) {
	                                    ArrayList<DataObject> arList = new ArrayList<DataObject>();
	                                    arList.add((DataObject) _laneObj);
	                                    this.iDataObjectAssociation.put((RefObject) _obj, arList);
	                                } else {
	                                    list.add((DataObject) _laneObj);
	                                    this.iDataObjectAssociation.put((RefObject) _obj, list);
	                                }
                            	}
                            }//end if
                        }//end checking if it is DataObject
                        // if it is a BoundaryEvent, then add to the iBoundaryEvent storage
                        if (_laneObj instanceof BoundaryEvent) {
                        	Activity act = (Activity)((BoundaryEvent) _laneObj).getActivity();
                        	String refID = act.refMofId();
                        	Vector<BoundaryEvent> v = this.iBoundaryEvents.get(refID);
                        	if(v!=null){
                        		v.add((BoundaryEvent) _laneObj);
                        		this.iBoundaryEvents.put(refID, v);
                        	}else{
                        		Vector<BoundaryEvent> bEventVector = new Vector<BoundaryEvent>();
                        		bEventVector.add((BoundaryEvent) _laneObj);
                        		this.iBoundaryEvents.put(refID, bEventVector);
                        	}
                        }
                        //checks for the Embedded subflow elements
                        if(_laneObj instanceof EmbeddedScope) {
                        	//get and register all elements in the
                        	scanEmbeddedScope((EmbeddedScope)_laneObj,
                        						_currentPoolCoordinateX,
                        						_currentPoolCoordinateY,
                        						_currentLaneCoordinateX, 
                        						_currentLaneCoordinateY
                        					 );
                        }
                        // add the lane objects to the iRefObjectStore
                        this.iRefObjectStore.put(_laneObj, 
                        		new PlStore(_currentPoolCoordinateX, 
                        					_currentPoolCoordinateY,
                        					_currentLaneCoordinateX,
                        					_currentLaneCoordinateY
                        					)
                        );
                    }// end for _labeObj
                    _laneNr += 1;
                }// po instanceof Lane
                _poolNr++;
            }// end forPoolObject po : (Collection<PoolObject>) pool.getPoolObjects()
        }// end for
        this.iRightShift = (-this.iRightShift);
        this.iDownShift = (-this.iDownShift);
    }


    /*
     * Scans the Embedded scope elements
     */
    private void scanEmbeddedScope(final EmbeddedScope aEmbeddedScope, int poolX,int poolY, int laneX, int laneY) {
    	int _x = PVUtil.getXCoordinate(aEmbeddedScope);
    	int _y = PVUtil.getYCoordinate(aEmbeddedScope);
    	storeCoordinates(aEmbeddedScope, poolX, poolY, laneX, laneY);
    	Collection<ScopeObject> elements = aEmbeddedScope.getScopeObjects();
    	//get the coordinates of the embedded scope
    	for(ScopeObject so: elements) {
    		if(so instanceof EmbeddedScope) {
    			scanEmbeddedScope((EmbeddedScope)so, poolX+_x, poolY+_y, laneX, laneY);
    		}
    		storeCoordinates(so, poolX+_x, poolY+_y, laneX, laneY);
    	}
    }
    
    private void storeCoordinates(ScopeObject sObject, int poolX,int poolY, int laneX, int laneY) {
        this.iRefObjectStore.put(sObject, new PlStore(poolX, poolY, laneX,laneY));    	
    }
    
    /**
     * Stores the orientation of the collaboration
     * 
     * @param Diagram the diagram
     */
    private void getWfOrientation(Diagram aDiagram) {
        String _diagramOrientation = PVUtil.getDiagramOrientation(aDiagram);
        if (_diagramOrientation.equals("orientationVertical")) { //$NON-NLS-1$
            this.iOrientation = DiagramToXMLConverter.VERTICAL_ORIENTATION;
        } else {
            this.iOrientation = DiagramToXMLConverter.HORIZONTAL_ORIENTATION;
        }
    }

    /**
     * Generates the xml file.
     * 
     * @param aDiagram
     *            the Diagram instance
     * @param collaboration
     *            the Collaboration instance
     */
    public void iterateOverElements(Diagram aDiagram, Collaboration collaboration) {
        preParse(aDiagram, collaboration);
        iterate(aDiagram, collaboration);
    }

    /**
     * Get's the generated XML content This method should be used after the iterateOverElements(Diagram aDiagram,
     * Collaboration aCollaboration) method was runned. After the method returns, the content is not deleted
     * 
     * @return String the generated XML content
     */
    public String getCompiledContent() {
        return this.iBuffer.toString();
    }

    protected void clean() {
        this.iPoolStorage = new Hashtable<String, Pool>();
        this.iLaneStorage = new Hashtable<String, Lane>();
        this.iAnnotationStorage = new Hashtable<Lane, Vector<Annotation>>();
        this.iAnnotationVectors = new Vector<Annotation>();
        this.iDataObjectAssociation = new Hashtable<RefObject, ArrayList<DataObject>>();
        this.iRefObjectStore = new Hashtable<RefObject, PlStore>();
        this.iBuffer = new StringBuilder(1000);
    }

    /**
     * Method to iterate through the elements of the collaboration
     * 
     * @param aDiagram
     *            the diagram
     * @param collaboration
     *            the collaboration
     */
    public void iterate(Diagram aDiagram, Collaboration collaboration) {
    	this.iBuffer.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); //$NON-NLS-1$
    	this.iBuffer.append(this.iNewLine);
        this.storeDiagramOrientation(aDiagram);
        this.iDiagram = aDiagram;
        this.createProcessTag(this.iDiagram, collaboration, this.iBuffer);
        for (Pool pool : collaboration.getPools()) {
            this.createPoolTag(pool, this.iBuffer);
            for (ScopeObject po : pool.getScopeObjects()) {
                if (po instanceof Lane) {
                    Lane _lane = (Lane) po;
                    this.iCurrentLane = _lane;
                    // register for annotations
                    this.iAnnotationStorage.put(_lane, this.iAnnotationVectors);
                    this.createLaneTag(_lane, this.iBuffer);
                    for (ScopeObject _laneObj : _lane.getScopeObjects()) {
                    // filter out ScopeObjects which does not have to be generated
                   	if((this.toGenerate(_laneObj)==false) || (_laneObj.getScope() instanceof EmbeddedScope && 
                   			!(_laneObj.getScope() instanceof ArtificialLoopScope))){
                    		continue;
                    }
                   	//if this _laneObj's scope is ArtificialLoopScope, we check ArtificialLoopScope's scope instead of this _laneObj's scope
                   	if(_laneObj.getScope() instanceof ArtificialLoopScope && ((ArtificialLoopScope)_laneObj.getScope()).getScope() instanceof EmbeddedScope)
                   	{
                   		continue;
                   	}
                        Shape _shape = (Shape) PVUtil.getPictogramElement(_laneObj);
                        if(_shape!=null) { //check in case of loop the DataObjects
                        	this.createNodeType(_laneObj, this.iBuffer, false, DiagramToXMLConverter.ABSOLUTE);
                        	this.createNodeEndType(_laneObj, this.iBuffer, false, DiagramToXMLConverter.ABSOLUTE);
                        }
                    }// end for _labeObj
                    // lane position properties
                    this.createLaneEndTag((Lane) po, this.iBuffer);
                }// po instance of Lane
            }// end forPoolObject po : (Collection<PoolObject>) pool.getPoolObjects()
            this.createPoolEndTag(pool, this.iBuffer);
        }// end for
        this.iBuffer.append("</Workflow>"); //$NON-NLS-1$
        this.iBuffer.append(this.iNewLine);
        PVUtil.writeXMLToFile(this.iDiagram, this.iBuffer.toString());
        PVUtil.log("PV file generation done."); //$NON-NLS-1$
    }

    /**
     * Filter for some scope objects which has to be filtered out
     * @param scopeObject
     * @return boolean
     */
    private boolean toGenerate(final ScopeObject scopeObject){
        if ((scopeObject instanceof LaneProcessRole) || 
        		(scopeObject instanceof TextVariable) || 
        		(scopeObject instanceof SequenceConnector)||
        		(scopeObject instanceof AnnotationConnector)||
                (scopeObject instanceof BoundaryEvent)){
        	return false;
        }else{
        	return true;
        }
    }
    
    private boolean toGenerateInEmbeddedSubflow(final ScopeObject scopeObject){
        if ((scopeObject instanceof LaneProcessRole) || 
        		(scopeObject instanceof TextVariable) || 
        		(scopeObject instanceof SequenceConnector)||
        		(scopeObject instanceof AnnotationConnector)||
                (scopeObject instanceof BoundaryEvent)){
        	return false;
        }else{
        	return true;
        }
    }    
    
    /**
     * Stores the orientation of the diagram
     * 
     * @param aDiagram
     */
    private void storeDiagramOrientation(Diagram aDiagram) {
        String _diagramOrientation = PVUtil.getDiagramOrientation(aDiagram);
        if (_diagramOrientation.equals("orientationVertical")) { //$NON-NLS-1$
            this.iOrientation = DiagramToXMLConverter.VERTICAL_ORIENTATION;
        } else {
            this.iOrientation = DiagramToXMLConverter.HORIZONTAL_ORIENTATION;
        }
    }

    /**
     * Gets the position of the RefOject. Method is used for calculate the 
     * connector target and source coordinates
     * 
     * @return String
     */
    private String getPositionOfElement(final RefObject aRefObject) {
        String _str = ""; //$NON-NLS-1$
        Shape _shape = (Shape) PVUtil.getPictogramElement(aRefObject);
        ILocation _location = PVUtil.getLocationRelativetoDiagram(_shape);

        int _x = _location.getX();
        int _y = _location.getY();

        _x = _x + PVUtil.getRefObjectWidth(aRefObject) / 2;
        _y = _y + PVUtil.getRefObjectHeight(aRefObject) / 2;

        _str = _x + "," + _y; //$NON-NLS-1$
        return _str;
    }

    /**
     * Inserts the process tag into the buffer Process tag has the following properties:
     * <ul>
     * <li>id
     * <li>label
     * <li>orientation
     * <li>language
     * </ul>
     * 
     * @param Diagram
     *            the Diagram object
     * @param StringBuffer
     *            contains the generated XML
     */
    private void createProcessTag(final Diagram aDiagram, final Collaboration collaboration, StringBuilder aBuffer) {
        aBuffer.append("<Workflow "); //$NON-NLS-1$
        aBuffer.append("id="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aDiagram.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" label="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + getTextId(ToolUtils.getInstance().getTextId(collaboration.getName()),collaboration.getName().getOriginalText()) + DiagramToXMLConverter.END);
        aBuffer.append(" orientation="); //$NON-NLS-1$
        if (this.iOrientation == DiagramToXMLConverter.VERTICAL_ORIENTATION) {
            aBuffer.append(DiagramToXMLConverter.START + "vertical" + DiagramToXMLConverter.END); //$NON-NLS-1$
        } else {
            aBuffer.append(DiagramToXMLConverter.START + "horizontal" + DiagramToXMLConverter.END); //$NON-NLS-1$
        }
        aBuffer.append(" language=\"en\""); //$NON-NLS-1$
        aBuffer.append(" activePoolId=\""); //$NON-NLS-1$
        aBuffer.append(this.iActivePoolId);
        aBuffer.append("\" "); //$NON-NLS-1$
        aBuffer.append("xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\""); //$NON-NLS-1$
        aBuffer.append(" procvisVersion=\"1\""); //$NON-NLS-1$
        aBuffer.append(" >"); //$NON-NLS-1$

        aBuffer.append(this.iNewLine);
    }

    /**
     * Inserts the pool tag into the buffer Pool has the following properties:
     * <ul>
     * <li>id
     * <li>label
     * <li>Position (PointType)
     * <li>Size (SizeType)
     * </ul>
     * 
     * @param Pool
     *            the Pool object
     * @param StringBuffer
     *            contains the generated XML
     */
    private void createPoolTag(Pool aPool, StringBuilder aBuffer) {
        // add the pool to the iPoolStorage
        this.iPoolStorage.put(aPool.refMofId(), aPool);
        aBuffer.append("<Pool "); //$NON-NLS-1$
        aBuffer.append("id="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aPool.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" label="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + getTextId(ToolUtils.getInstance().getTextId(aPool.getName()),aPool.getName().getOriginalText()) + DiagramToXMLConverter.END);

        // subject
        aBuffer.append(" subject="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + this.getTextId(ToolUtils.getInstance().getTextId(aPool.getSubject()),aPool.getSubject().getOriginalText()) + DiagramToXMLConverter.END);


        // add whether has deadline or not
        if (!aPool.isActive()) {
            aBuffer.append(" hasDeadlines=\"false\""); //$NON-NLS-1$
        } else {
            // query it
            boolean _has = PVUtil.getActivityCompletition(aPool);
            if (_has) {
                aBuffer.append(" hasDeadlines=\"true\""); //$NON-NLS-1$
            } else {
                aBuffer.append(" hasDeadlines=\"false\""); //$NON-NLS-1$
            }
        }
        if (aPool.isBoundaryVisible()) {
            aBuffer.append(" boundaryVisible=\"true\""); //$NON-NLS-1$
            this.isCurrenPoolDefault = true;
        } else {
            aBuffer.append(" boundaryVisible=\"false\""); //$NON-NLS-1$
            this.isCurrenPoolDefault = false;
        }
        aBuffer.append(XML_ELEMENT_CLOSING_TAG);
        aBuffer.append(this.iNewLine);
    }

    /**
     * Creates the description and the "</Pool>" tag
     * 
     * @param Pool
     *            the Pool object
     * @param StringBuilder
     */
    private void createPoolEndTag(Pool aPool, StringBuilder aBuffer) {
        PictogramElement _poolElement = PVUtil.getPictogramElement(aPool);
        // insert the Position information
        this.createPositionTag(_poolElement, aBuffer);
        // insert the Size information
        this.createSizeTag(aPool, aBuffer);
        this.createPoolDocumentation(aPool, aBuffer);
        
        // insert the description tag
		aBuffer.append(POOL_ELEMENT_CLOSE);
        aBuffer.append(this.iNewLine);
    }

    /**
     * Creates the pool's description attribute.
     * 
     * @param aPool
     * @param aBuffer
     */
    public void createPoolDocumentation(final Pool aPool, StringBuilder aBuffer){
    	aBuffer.append("<description>"); //$NON-NLS-1$
        aBuffer.append(this.getTextId(ToolUtils.getInstance().getTextId(aPool.getDescription()),aPool.getDescription().getOriginalText()));
    	aBuffer.append("</description>"); //$NON-NLS-1$
    }
    
    /**
     * Creates position tag
     * 
     * @param PictogramElement
     * @param RefObject
     *            The model element which is draw (LaneObject)
     * @param StringBuilder
     */
    private void createPositionTag(final PictogramElement aPictogramElement, final RefObject aElementObject, StringBuilder aBuffer) {
        // get the coordinates of the element
        int laneX = (this.iRefObjectStore.get(aElementObject)).getLaneX();
        int laneY = (this.iRefObjectStore.get(aElementObject)).getLaneY();
        laneX = laneX + this.iRightShift;
        laneY = laneY + this.iDownShift;
        aBuffer.append("<Position x="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + laneX + DiagramToXMLConverter.END);
        aBuffer.append(" y="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + laneY + DiagramToXMLConverter.END);
        aBuffer.append(" />"); //$NON-NLS-1$
        aBuffer.append(this.iNewLine);
    }

    /**
     * Gets the X coordinate of a BoundaryEvent
     * @param aEvent BoundaryEvent
     * @return int
     */
    private Point2D getXYCoordinateOfBoundaryEvent(final BoundaryEvent aEvent){
    	int x =0;
    	int y=0;
    	Activity activity = aEvent.getActivity();
    	//get lane's x,y of the activity
    	x += (this.iRefObjectStore.get(activity)).getLaneX();
    	y += (this.iRefObjectStore.get(activity)).getLaneY();
    	//get the x,y of the activity
    	x += PVUtil.getXCoordinate(activity);
    	y += PVUtil.getYCoordinate(activity);
    	int activityX=x;
    	int activityY=y;
    	//add the x,y of the Boundary event
    	x += PVUtil.getXCoordinate(aEvent);
    	y += PVUtil.getYCoordinate(aEvent);
    	
    	GraphicsAlgorithm ga = XMLUtil.getFirstPictogramElementForBusinessObject( activity ).getGraphicsAlgorithm();
    	if( !ga.isFilled()){
    		x = x - ga.getGraphicsAlgorithmChildren().get(0).getX();
    		y = y - ga.getGraphicsAlgorithmChildren().get(0).getY();
    	}        	
    	PictogramElement pe = PVUtil.getPictogramElement(activity);
    	if(activity instanceof EmbeddedScope)
    	{
    		int embededScopeWidth=Integer.parseInt(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_WIDTH));
    		int embededScopeHeight=Integer.parseInt(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_HEIGHT));
    		//for some reason during visualisation, width is coming more, to compensate this
    		//redugin the embeded scope's width by 40.
    		embededScopeWidth=embededScopeWidth-40;
    		return PVUtil.getClosestPointOnRectangle(activityX,activityY,embededScopeWidth,embededScopeHeight, new Point2D.Double(x,y)); 
    	}
    	else
    	{
    		return new Point2D.Double(x,y);
    	}
    	
    }
        
    /**
     * Creates the position tag of the RefObjects. The XML tag is inserted into the StringBuffer received as method
     * parameter
     * 
     * @param RefObject
     * @param StringBuilder
     */
    private void createPositionTag(final RefObject aRefObject, StringBuilder aBuffer, int relativeOrAbsolute) {
        int x = 0;
        int y = 0;
        x = x + this.iRightShift;
        y = y + this.iDownShift;
        if (aRefObject instanceof BoundaryEvent) {
        	BoundaryEvent event = (BoundaryEvent)aRefObject;
        	Point2D bPoint=getXYCoordinateOfBoundaryEvent(event);
        	x = x + (int)bPoint.getX();
        	y = y + (int)bPoint.getY();
        } else {
            // get the x coordinate of the lane
			if (relativeOrAbsolute != DiagramToXMLConverter.RELATIVE) {
				x += (this.iRefObjectStore.get(aRefObject)).getLaneX();
			}

            // add the x coordinates of the RefObject

            x += PVUtil.getXCoordinate(aRefObject);
            // }
            // get the y coordinate of the lane
			if (relativeOrAbsolute != DiagramToXMLConverter.RELATIVE) {
				y += (this.iRefObjectStore.get(aRefObject)).getLaneY();
			}
            // add the y coordinates of the RefObject
            y += PVUtil.getYCoordinate(aRefObject);
            if(relativeOrAbsolute == DiagramToXMLConverter.RELATIVE){
            	x = x - PVUtil.getSelectionGraphicsAlgorithm(this.subflowTmpSorage.get(this.subflowTmpSorage.size()-1)).getX();
            	y = y - PVUtil.getSelectionGraphicsAlgorithm(this.subflowTmpSorage.get(this.subflowTmpSorage.size()-1)).getY();
            }
            // get the insets
//            x = x + PVUtil.getInsets(aRefObject, 0);
//            y = y + PVUtil.getInsets(aRefObject, 1);
            // calculate with the pool's header
            x = PVUtil.modifyXCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, x);
            y = PVUtil.modifyYCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, y);
        }
        // get the lane of the element
        aBuffer.append("<Position x="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + x + DiagramToXMLConverter.END);
        aBuffer.append(" y="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + y + DiagramToXMLConverter.END);
        aBuffer.append(" />"); //$NON-NLS-1$
        aBuffer.append(this.iNewLine);
    }

    private void createPositionTag(PictogramElement aPictogramElement, StringBuilder aBuffer) {
        int x = aPictogramElement.getGraphicsAlgorithm().getX();
        int y = aPictogramElement.getGraphicsAlgorithm().getY();
        x = x + this.iRightShift;
        y = y + this.iDownShift;
        // get the lane of the element
        aBuffer.append("<Position x="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + x + DiagramToXMLConverter.END);
        aBuffer.append(" y="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + y + DiagramToXMLConverter.END);
        aBuffer.append(" />"); //$NON-NLS-1$
        aBuffer.append(this.iNewLine);
    }

    private void createPointTag(final int aX, final int aY, StringBuilder aBuffer) {

        aBuffer.append("<Point x="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aX + DiagramToXMLConverter.END);
        aBuffer.append(" y="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aY + DiagramToXMLConverter.END);
        aBuffer.append(" />"); //$NON-NLS-1$
        aBuffer.append(this.iNewLine);

    }

    private void createSizeTag(final RefObject aRefObject, StringBuilder aBuffer) {
        /*
         * For the pool size, we have to check whether it is a default pool or not. The default pool should not have the
         * width and height of the graphical editor, instead we have to use the calculated iHighestX and iHighestY
         * coordinates
         */
        aBuffer.append("<Size x=\""); //$NON-NLS-1$
        if (aRefObject instanceof Pool && !((Pool) aRefObject).isBoundaryVisible()) {
            aBuffer.append(this.iHighestX);
        } else {
            aBuffer.append(PVUtil.getRefObjectWidth(aRefObject));
        }
        aBuffer.append("\""); //$NON-NLS-1$
        aBuffer.append(" y=\""); //$NON-NLS-1$
        if ((aRefObject instanceof Pool) && !((Pool) aRefObject).isBoundaryVisible()) {
            aBuffer.append(this.iHighestY);
        } else {
            aBuffer.append(PVUtil.getRefObjectHeight(aRefObject));
        }
        aBuffer.append("\""); //$NON-NLS-1$
        aBuffer.append(" />"); //$NON-NLS-1$
        aBuffer.append(this.iNewLine);
    }

    /**
     * Inserts the lane tag into the buffer Lane object has the following properties:
     * <ul>
     * <li>Position (PositionType)
     * <li>Size (SizeType)
     * <li>id -String
     * <li>label -String
     * </ul>
     * 
     * @param Lane
     *            the Lane element
     * @param StringBuffer
     *            contains the generated XML
     */
    private void createLaneTag(Lane aLane, StringBuilder aBuffer) {
        // add the lane to the iLaneStorage
        this.iLaneStorage.put(aLane.refMofId(), aLane);
        aBuffer.append("<Lane "); //$NON-NLS-1$
        aBuffer.append("id="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aLane.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" label="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + getTextId(ToolUtils.getInstance().getTextId(aLane.getName()), aLane.getName().getOriginalText()) + DiagramToXMLConverter.END);
        aBuffer.append(XML_ELEMENT_CLOSING_TAG); 
        aBuffer.append(this.iNewLine);
    }

    /**
     * Creates the end tag for Lane object
     * 
     * @param Lane
     *            the Lane object
     * @param StringBuilder
     *            the buffer where the generated tag is added
     */
    private void createLaneEndTag( final Lane aLane, StringBuilder aBuffer ) {
        aBuffer.append(this.iNewLine);
        PictogramElement _poolElement = PVUtil.getPictogramElement(aLane);
        // insert the Position information
        this.createPositionTag(_poolElement, aLane, aBuffer);

        // insert the Size information
        // this.createSizeTag( _poolElement, aBuffer );
        this.createSizeTag(aLane, aBuffer);
        aBuffer.append("</Lane>"); //$NON-NLS-1$
        aBuffer.append(this.iNewLine);
    }

    /**
     * Creates the "Node" XML start node 
     * @param ScopeObject
     * @param StringBuilder The generated content is appended here
     * @param boolean whether the ScopeObject is boundary type
     */
    private void createNodeType( final ScopeObject aLaneObject, StringBuilder aBuffer, boolean isBoundary, int absoluteOrRelative ) {

        if (isBoundary) {
            aBuffer.append("<BoundaryEvent type="); //$NON-NLS-1$            
        } else {
            aBuffer.append("<Node type="); //$NON-NLS-1$  
        }
        aBuffer.append(DiagramToXMLConverter.START + PVUtil.getLaneObjectType(aLaneObject) + DiagramToXMLConverter.END); //$NON-NLS-1$
        aBuffer.append(" id="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aLaneObject.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" label="); //$NON-NLS-1$
        if(aLaneObject instanceof Annotation){
            aBuffer.append(DiagramToXMLConverter.START  
                    + this.getTextId(ToolUtils.getInstance().getTextId(((Annotation)aLaneObject).getDocumentation()),
                    		((Annotation)aLaneObject).getDocumentation().getOriginalText())
                    + DiagramToXMLConverter.END);
        }else{
            aBuffer.append(DiagramToXMLConverter.START + getTextId(ToolUtils.getInstance().getTextId(aLaneObject.getName()), aLaneObject.getName().getOriginalText()) + DiagramToXMLConverter.END);
        }
        //if element is PoolReference
        if( aLaneObject instanceof PoolReference ){
        	aBuffer.append(" subflowId=\""); //$NON-NLS-1$
        	//A referenced subprocess in an inactive pool can have null process, so do a null check here.
        	if(((PoolReference)aLaneObject).getReferencedScope()!=null)
        	{
        		aBuffer.append(((PoolReference)aLaneObject).getReferencedScope().refMofId());
        	}
        	aBuffer.append( "\"" ); //$NON-NLS-1$
        }
        
        //if the element is an activity, then check for the loop property
        if(aLaneObject instanceof Activity){
        	aBuffer.append(this.getLoopXMLTag((Activity)aLaneObject));
        }
        
		aBuffer.append(XML_ELEMENT_CLOSING_TAG);
        aBuffer.append(this.iNewLine);

        if(aLaneObject instanceof EmbeddedScope) {
        	generateEmbeddedSubflowElements((EmbeddedScope)aLaneObject,aBuffer);
        }
        
        //if ScopeObject is Activity and has BoundaryEvents, then generate them 
        if ( aLaneObject instanceof Activity ) {
            // if it has boundary event
        	Activity activity = (Activity) aLaneObject;
        	String refID = activity.refMofId();
            if (this.iBoundaryEvents.containsKey(refID)) {
                // add the boundary events if there are it has NodeType
                Vector<BoundaryEvent> boundaryEvents = this.iBoundaryEvents.get(refID);
                for(BoundaryEvent be: boundaryEvents){                    
                	this.createNodeType(be, aBuffer, true, absoluteOrRelative);
                	this.createNodeEndType(be, aBuffer, true, absoluteOrRelative);
                }
            }
        }
    }
    
    /**
	 * If the artifact is set as loopeable, then the looptype attribute must be
	 * set:
	 *  <xsd:attribute name="loopType" use="optional"> 
	 *  <xsd:annotation>
	 * 			<xsd:documentation>Type of the loop. The attribute is optional.
	 * 			</xsd:documentation> 
	 * </xsd:annotation> 
	 * <xsd:simpleType> <xsd:restriction base="xsd:string"> 
	 * 			<xsd:enumeration value="Sequential"/> 
	 * 			<xsd:enumeration value="Parallel"/> </xsd:restriction>
	 *  </xsd:simpleType> 
	 *  </xsd:attribute>
	 * 
	 * 
	 * @return String The generated XML attribute
	 * 
	 */
	private String getLoopXMLTag(Activity aActivity) {
		String _attrib = ""; //$NON-NLS-1$
		final String _NAME = "  loopType"; //$NON-NLS-1$
		final String _TYPE_PARALLEL = "\"parallel\""; //$NON-NLS-1$
		final String _TYPE_SEQUENTIAL = "\"sequential\""; //$NON-NLS-1$
		LoopCharacteristics lc = null;
		
        if (aActivity instanceof EmbeddedScope) {
            lc = ((EmbeddedScope) aActivity).getLoopCharacteristics();
        } else if (aActivity.getScope() instanceof ArtificialLoopScope) {
            lc = ((ArtificialLoopScope) aActivity.getScope()).getLoopCharacteristics();
        }
        if(lc == null)return _attrib;
        
		if(((MultiInstanceLoopCharacteristics)lc).isSequential()) {
        	_attrib = _NAME + EQUAL + _TYPE_SEQUENTIAL;	
        }else {
        	_attrib = _NAME + EQUAL + _TYPE_PARALLEL;
        }
        	
		//if the activity has no loop attribute, then returns empty String 
		return _attrib;

	}
    
    private class Pair {
    	public int first;
    	public int second;
    	public Pair(int a, int b) {
    		first = a;
    		second = b;
    	}
    }
	
    /**
     * Inserts the annotations, outgoing connectors and the position tags.
     * 
     * @param ScopeObject
     *            the lane object
     * @param aBuffer
     *            the buffer where the XML tags will be appended
     */
    /**
     * @param aLaneObject
     * @param aBuffer
     * @param isBoundary
     */
    @SuppressWarnings("unchecked")
    private void createNodeEndType(final ScopeObject aLaneObject, StringBuilder aBuffer, boolean isBoundary, int relativeOrAbsolute) {
        PictogramElement _pElement = PVUtil.getPictogramElement(aLaneObject);
        // add connectors of the node element
        if (!(aLaneObject instanceof Annotation) ) {
            List<SequenceConnector> _outgoingConnectors = aLaneObject.getOutgoingConnectors();
        	//in case of DataObject we have to query a bit differently the outgoing connectors
        	if(aLaneObject instanceof DataObject && _pElement != null){
        		Collection<Anchor> ca = ((Shape)_pElement).getAnchors();
        		Iterator<Anchor> _anchor_iter = ca.iterator();
        		while(_anchor_iter.hasNext()){
        			Anchor _an = _anchor_iter.next();
        				Iterator<Connection> _connection_iter = _an.getOutgoingConnections().iterator();
        				while(_connection_iter.hasNext()){
        					Connection _c = _connection_iter.next();
        					RefObject _targetObject = XMLUtil.getBusinessObjectForLinkedPictogramElement(_c.getEnd().getParent());
        					if(!(_targetObject instanceof Annotation ))
        					this.createConnectorTagFromDataObject( _c,XMLUtil.getBusinessObjectForLinkedPictogramElement(_c.getEnd().getParent().getGraphicsAlgorithm().getPictogramElement()).refMofId(),
        							aBuffer,
        							_c.getStart().getParent(), //start element
        							_c.getEnd().getParent()//end element
        							);
        				}
        		}
        	}

            //get the ScopeObject's outgoing connectors
            Iterator<SequenceConnector> _iter = _outgoingConnectors.iterator();
            while (_iter.hasNext()) {
                this.createConnectorTag(_iter.next(), aBuffer, relativeOrAbsolute);
            }

            // get  annotations of the ScopeObject
            Collection<AnnotationConnector> aAnnotationConnectors = (Collection) aLaneObject.getAnnotationConnectorsOfModelElement();

            //each AnnotatonConnector has one Annotation associated 
            Iterator _iterAnnotations = aAnnotationConnectors.iterator();

            // insert the connectors for the Annotations if there are
            Vector<Annotation> _annotationsVector = this.iAnnotationStorage.get(this.iCurrentLane);
            while (_iterAnnotations.hasNext()) {
            	//get the Annotation associated with the AnnotationConnector
            	AnnotationConnector ac = (AnnotationConnector) _iterAnnotations.next();
            	Annotation _ann = ac.getAnnotation();
            	if(_ann == null)continue;
                // use the PeUtil's getLocationRelativeToDiagram to get the position
                String _anCoord = this.getPositionOfElement(_ann);
                int _annotX = Integer.parseInt(this.getNrFromString(_anCoord, 0));
                int _annotY = Integer.parseInt(this.getNrFromString(_anCoord, 1));

                PlStore _store = this.iRefObjectStore.get(aLaneObject);
                if(aLaneObject instanceof BoundaryEvent){
                	Point2D bPoint=getXYCoordinateOfBoundaryEvent((BoundaryEvent)aLaneObject);
                	this.createConnectorForAnnotation(aLaneObject,
                									 _ann, //the annotation
                									 ac,//the connector
                									 aBuffer,
                									 (int)bPoint.getX(),
                									 (int)bPoint.getY(),
                									 _annotX + this.iRightShift, _annotY + this.iDownShift
                									 );
                }else{
                	//create connector for annotation
                	int startX = PVUtil.getXForConnector(aLaneObject) + _store.getLaneX() + this.iRightShift -PVUtil.getRefObjectWidth(aLaneObject)/2 ;
                	//if it is PoolReference then add the height/2
                	int startY = (aLaneObject instanceof PoolReference)?_pElement.getGraphicsAlgorithm().getY() + _store.getLaneY()+ PVUtil.getRefObjectHeight(aLaneObject)/2 + this.iDownShift:
                			_pElement.getGraphicsAlgorithm().getY() + _store.getLaneY() + this.iDownShift;
                	int endX = _annotX + this.iRightShift;
                	int endY = _annotY + this.iDownShift;
                	//if we need relative points, then we are inside Embedded subflow, decrease with insets
                	if(relativeOrAbsolute == DiagramToXMLConverter.RELATIVE){
                		EmbeddedScope currentEmbeddedScope = this.subflowTmpSorage.get(this.subflowTmpSorage.size()-1);
                		startX = startX - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getX();
                		startY = startY - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getY();
                		endX = endX - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getX();
                		endY = endY - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getY();
                		endX = endX - PVUtil.getPictogramElement(currentEmbeddedScope).getGraphicsAlgorithm().getX();
                		endY = endY - PVUtil.getPictogramElement(currentEmbeddedScope).getGraphicsAlgorithm().getY();
                	}
                	this.createConnectorForAnnotation(aLaneObject,
                			_ann, //the annotation
                			ac, //the connector
                			aBuffer,
                			startX ,
                			startY,
                			endX,
                			endY
                			);
                }
                /* Register annotation to the current Lane.
                 * The annotation tag will be generated later during the
                 * process
                 */
                _annotationsVector.add( _ann );
            }
            /* if data object is associated to the current lane object, then 
             * create the connectors to the DataObject
             */
            if (this.iDataObjectAssociation.containsKey(aLaneObject)) {
                PlStore _store = this.iRefObjectStore.get(aLaneObject);
                // get the DataObject
                ArrayList<DataObject> list = this.iDataObjectAssociation.get(aLaneObject);
                for (DataObject dataObject : list) {
                    //get x,y coordinates for the DataObject
                    PlStore _dataObjectCoordinates = this.iRefObjectStore.get(dataObject);
                    int startX = PVUtil.getXForConnector(aLaneObject) + _store.getLaneX()+ this.iRightShift; //startX of the connector
                    int startY = PVUtil.getYForConnector(aLaneObject) + _store.getLaneY() + this.iDownShift; //startY of the connector
                    int endX = PVUtil.getXForConnector(dataObject)+ _dataObjectCoordinates.getLaneX() + this.iRightShift; //endX of the connector
                    int endY = PVUtil.getYForConnector(dataObject) + _dataObjectCoordinates.getLaneY() + this.iDownShift;//endY of the connector
                	//if we need relative points, then we are inside Embedded subflow, decrease with insets
                	if(relativeOrAbsolute == DiagramToXMLConverter.RELATIVE){
                		EmbeddedScope currentEmbeddedScope = this.subflowTmpSorage.get(this.subflowTmpSorage.size()-1);
                		startX = startX - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getX();
                		startY = startY - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getY();
                		endX = endX - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getX();
                		endY = endY - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getY();
                	}
                    this.createConnectorForDataObject(aLaneObject, dataObject, aBuffer, 
                    		startX,
                            startY, 
                            endX,
                            endY
                            );
                }// end for
            }
        }
        // create the outgoing messageflowConnectors
        Collection<MessageFlowConnector> _outgoingConnectors = aLaneObject.getOutgoingMessageFlowConnectors();
        for (MessageFlowConnector _mfc : _outgoingConnectors) {
            this.createMessageFlowConnectorTag(_mfc, aBuffer);
        }
        // insert the Position information
        this.createPositionTag(aLaneObject, aBuffer, relativeOrAbsolute);

        // insert the Size information <Size x="" y="" />
        if(aLaneObject instanceof EmbeddedScope) {
        	PictogramElement pe = PVUtil.getPictogramElement(aLaneObject);
	        aBuffer.append("<Size x=\""); 																//$NON-NLS-1$
	        aBuffer.append(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_WIDTH));
	        aBuffer.append("\" y=\"");																		//$NON-NLS-1$
	        aBuffer.append(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_HEIGHT));
	        aBuffer.append("\" />");																		//$NON-NLS-1$
        }
        else{
        	this.createSizeTag(aLaneObject, aBuffer);
        }


        if(aLaneObject instanceof EmbeddedScope) {
        	//the size is stored in PictogramElement's property
        	PictogramElement pe = PVUtil.getPictogramElement(aLaneObject);
        	aBuffer.append("<ExpandedSize ");								//$NON-NLS-1$ 
        	aBuffer.append("x=\"");											//$NON-NLS-1$
        	aBuffer.append(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_EXPANDED_WIDTH));	//width										
        	aBuffer.append("\" ");											//$NON-NLS-1$
        	aBuffer.append("y=\"");											//$NON-NLS-1$
        	aBuffer.append(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_EXPANDED_HEIGHT));	//height								
        	aBuffer.append("\" ");        									//$NON-NLS-1$
        	aBuffer.append("/>");											//$NON-NLS-1$
        	
        }
        if(aLaneObject instanceof AutomatedActivity){
        	this.generateServiceTagForActivity((AutomatedActivity)aLaneObject, aBuffer);
        }
        aBuffer.append(this.iNewLine);
        
        if (isBoundary) {
			aBuffer.append(BOUNDARYEVENT_ELEMENT_CLOSE);
        } else {
			aBuffer.append(NODE_ELEMENT_CLOSE);
        }
        aBuffer.append(this.iNewLine);
    }
    
    /**
	 * <Service>
	 *  <ServiceInterface namespace="http://sap.com" name="this is the name"/> 
	 *  <Operation>This_is_an_operaton</Operation>
	 *  <LogicalDestination>hello</LogicalDestination> 
	 * </Service>
	 * 
	 * @param AutomatedActivity
	 * @param StringBuilder
	 */
    public void generateServiceTagForActivity(AutomatedActivity activity, StringBuilder stringBuilder){
    	
    	Operation operation = activity.getOperation();
    	Interface serviceInterface = operation.getServiceInterface();
    	String serviceName = serviceInterface.getName();
    	String serviceNamespace = serviceInterface.getNamespace();
    	String logicalDestination = activity.getLogicalDestination();
    	String serviceGroupName = ""; //$NON-NLS-1$
    	if(activity.getServiceReference() != null){
    		com.sap.ide.es.config.mc.model.mc.logicalsystem.LogicalSystem ls = activity.getServiceReference().getLogicalSystem();
    		if(ls != null){
    			serviceGroupName = ls.getName();
    		}
    	}
    	stringBuilder.append("<Service>"); //$NON-NLS-1$
    	stringBuilder.append(this.iNewLine);
    	stringBuilder.append("<ServiceInterface "); //$NON-NLS-1$
    		stringBuilder.append("namespace=\""); //$NON-NLS-1$
    		stringBuilder.append(serviceNamespace);
    		stringBuilder.append("\" "); //$NON-NLS-1$
    		stringBuilder.append("name=\""); //$NON-NLS-1$
    		stringBuilder.append(serviceName);
    		stringBuilder.append("\"/>"); //$NON-NLS-1$
    	stringBuilder.append(this.iNewLine);
    	
    		//Operation
    		stringBuilder.append("<Operation>"); //$NON-NLS-1$
    		stringBuilder.append(operation.getName());
    		stringBuilder.append("</Operation>"); //$NON-NLS-1$
    	stringBuilder.append(this.iNewLine);
    	
    		//if we have logical destination, then generate the Logical destination
    	if(logicalDestination != null){
    		stringBuilder.append("<LogicalDestination>"); //$NON-NLS-1$
    		stringBuilder.append(logicalDestination);
    		stringBuilder.append("</LogicalDestination>"); //$NON-NLS-1$
    	}
    	else{
    		//if we have service group, then generate the service group
    		stringBuilder.append("<ServiceGroup>"); //$NON-NLS-1$
    		stringBuilder.append(serviceGroupName);
    		stringBuilder.append("</ServiceGroup>"); //$NON-NLS-1$
    	}
    	stringBuilder.append(this.iNewLine);
    	stringBuilder.append("</Service>"); //$NON-NLS-1$
    	stringBuilder.append(this.iNewLine);
    }
    
    /**
     * 
     * Creates the connector xml tag to the 
     * connectors which comes from the DataObject
     * 
     * @param Connection Outgoing Connector
     * @param refID of the connector
     * @param StringBuilder the buffer
     * @param AnchorContainer the start Object
     * @param AnchorContainer the end Object
     */
    private void createConnectorTagFromDataObject(Object aConnector,
										    		String aRefID,
										    		StringBuilder aBuffer , 
										    		final AnchorContainer aStartObject,
										    		final AnchorContainer aEndObject) {
        // EdgeType
        if (aConnector == null)
            return;
        if(XMLUtil.getBusinessObjectForLinkedPictogramElement(aStartObject.getGraphicsAlgorithm().getPictogramElement()) instanceof
        		Annotation) return;
        aBuffer.append("<Connector "); //$NON-NLS-1$
        aBuffer.append(" id="); //$NON-NLS-1$
       	aBuffer.append(DiagramToXMLConverter.START + ((RefObject)aConnector).refMofId() + DiagramToXMLConverter.END);
        
        aBuffer.append(" label=" + DiagramToXMLConverter.START + getTextId("","") + DiagramToXMLConverter.END ); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        aBuffer.append(" target="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aRefID + DiagramToXMLConverter.END);
        aBuffer.append(" type="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + "DirectedAssociation" + DiagramToXMLConverter.END); //$NON-NLS-1$

        aBuffer.append(XML_ELEMENT_CLOSING_TAG);
        aBuffer.append(this.iNewLine);
        // insert the points information
        this.getConnectorPointsForConnectorsFromDataObject(aBuffer, aConnector,aStartObject, aEndObject);

        aBuffer.append(CONNECTOR_ELEMENT_CLOSE);
        aBuffer.append(this.iNewLine);
    }
    
    /*
     * Creates connector points 
     * @param aBuffer StringBuilder
     * @param aPoolObject OutgoingConnector
     * @param aStartElement AnchorContainer
     * @param aEndElement AnchorContainer
     */
    private void getConnectorPointsForConnectorsFromDataObject(StringBuilder aBuffer,
    															final Object aPoolObject,
    															final AnchorContainer aStartElement, 
    															final AnchorContainer aEndElement) {

        RefObject _source = null;
        RefObject _target = null;

        _source = XMLUtil.getBusinessObjectForLinkedPictogramElement(aStartElement.getGraphicsAlgorithm().getPictogramElement());
        _target = XMLUtil.getBusinessObjectForLinkedPictogramElement(aEndElement.getGraphicsAlgorithm().getPictogramElement());

        //check of the target is a BoundaryEvent
        int _targetX = 0;
        int _targetY = 0;
      	int _srcX = (this.iRefObjectStore.get(_source)).getLaneX() + PVUtil.getXCoordinate(_source);
       	int _srcY = (this.iRefObjectStore.get(_source)).getLaneY() + PVUtil.getYCoordinate(_source);
        if(_target instanceof BoundaryEvent){
        	Point2D bPoint=getXYCoordinateOfBoundaryEvent((BoundaryEvent)_target);
        	_targetX = (int)bPoint.getX(); 
        	_targetY = (int)bPoint.getY(); 
        }else{
        	_targetX = (this.iRefObjectStore.get(_target)).getLaneX() + PVUtil.getXCoordinate(_target);// + this.iRightShift;
        	_targetY = (this.iRefObjectStore.get(_target)).getLaneY() + PVUtil.getYCoordinate(_target);// + this.iDownShift;
        }

        // get the target coordinates
        // modify the targetX if it is needed
         _srcX = this.modifyXCoordinate(_source, _srcX);
         _srcY = this.modifyYCoordinate(_source, _srcY);
         // calculate with the pool's header
         _srcX = PVUtil.modifyXCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, _srcX);
         _srcY = PVUtil.modifyYCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, _srcY);
         this.createPointTag(_srcX + this.iRightShift, _srcY + this.iDownShift, aBuffer);

         List<Point> _points = ((FreeFormConnection)aPoolObject).getBendpoints();

         for (int i = 0; i < _points.size(); i++) {
              int aX = _points.get(i).getX();
              int aY = _points.get(i).getY();
              // add the pool's width or height if it is necessary
              aX = PVUtil.modifyXCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, aX);
              aY = PVUtil.modifyYCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, aY);
              this.createPointTag(aX + this.iRightShift, aY + this.iDownShift, aBuffer);
              this.checkForHighestXCoordinate(aX + this.iRightShift);
              this.checkForHighestYCoordinate(aY + this.iDownShift);
         }
         _targetX = this.modifyXCoordinate(_target, _targetX);
         _targetY = this.modifyYCoordinate(_target, _targetY);
         // calculate with the pool's header
         _targetX = PVUtil.modifyXCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, _targetX);
         _targetY = PVUtil.modifyYCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, _targetY);
         this.createPointTag(_targetX + this.iRightShift, _targetY + this.iDownShift, aBuffer);
    }


    /**
     * Creates the connector tags for the MessageFlowConnectors of a lane object
     * 
     * @param MessageFlowConnector The connector can point from one pool's element
     * to another pool or to another pool's element.
     * @param StringBuilder
     */
    private void createMessageFlowConnectorTag(final MessageFlowConnector aConnector, StringBuilder aBuffer) {
        MessageFlowObject _sourceObject = aConnector.getSource();
        MessageFlowObject _targetObject = aConnector.getTarget();
        // get the coordinates of the source
        int _srcX = (this.iRefObjectStore.get(_sourceObject)).getLaneX() + PVUtil.getXCoordinate(_sourceObject);
        int _srcY = (this.iRefObjectStore.get(_sourceObject)).getLaneY() + PVUtil.getYCoordinate(_sourceObject);
        // get the target coordinates
        int _targetX = (this.iRefObjectStore.get(_targetObject)).getLaneX() + PVUtil.getXCoordinate(_targetObject);
        int _targetY = (this.iRefObjectStore.get(_targetObject)).getLaneY() + PVUtil.getYCoordinate(_targetObject);
        this.createConnectorTagForMessageFlowConnector(aConnector, _srcX, _srcY, _targetX, _targetY, _targetObject.refMofId(), aBuffer);
    }

    /**
     * Creates the connector xml tag for the MessageFlowConnector
     * 
     * @param MessageFlowConnector
     * @param int
     *            startX
     * @param int
     *            startY
     * @param int
     *            targetX
     * @param int
     *            targetY
     * @param StringBuilder
     */
    private void createConnectorTagForMessageFlowConnector(final MessageFlowConnector aConnector, int startX, int startY, int targetX, int targetY,
            final String aTargetID, StringBuilder aBuffer) {
        aBuffer.append("<Connector "); //$NON-NLS-1$
        aBuffer.append(" id="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aConnector.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" label="); //$NON-NLS-1$
        // MM
//        aBuffer.append(DiagramToXMLConverter.START + getTextId(aConnector.getName().getTextId()) + DiagramToXMLConverter.END);
        aBuffer.append(DiagramToXMLConverter.START + getTextId(ToolUtils.getInstance().getTextId(aConnector.getName()), aConnector.getName().getOriginalText()) + DiagramToXMLConverter.END);
        aBuffer.append(" target="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aTargetID + DiagramToXMLConverter.END);
        aBuffer.append(" type="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + "MessageFlow" + DiagramToXMLConverter.END); //$NON-NLS-1$

        aBuffer.append(XML_ELEMENT_CLOSING_TAG);
        aBuffer.append(this.iNewLine);
        // insert the points information
        startX = this.modifyXCoordinate(aConnector.getSource(), startX) + this.iRightShift;
        startY = this.modifyYCoordinate(aConnector.getSource(), startY) + this.iDownShift;
        targetX = this.modifyXCoordinate(aConnector.getSource(), targetX) + this.iRightShift;
        targetY = this.modifyYCoordinate(aConnector.getSource(), targetY) + this.iDownShift;

        this.createPointTag(startX, startY, aBuffer);
        this.createPointTag(targetX, targetY, aBuffer);

        aBuffer.append(CONNECTOR_ELEMENT_CLOSE); 
        aBuffer.append(this.iNewLine);

    }

    /**
     * @param aRefObject the object from where the connector goes
     * @param aObject    the Annotation
     * @param aAnnotationConnector the connector
     * @param aBuffer
     * @param startx
     * @param starty
     * @param endx
     * @param endy
     */
    private void createConnectorForAnnotation(final RefObject aSourceobject,
    										  final Object aObject,
    										  final AnnotationConnector aAnnotationConnector, 
    										  StringBuilder aBuffer, 
    										  int startx, 
    										  int starty, 
    										  int endx,
    										  int endy) {
        MessageFlowObject _poolObject = (MessageFlowObject) aObject;

        aBuffer.append("<Connector "); //$NON-NLS-1$
        aBuffer.append(" id="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + aAnnotationConnector.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" label="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + getTextId(ToolUtils.getInstance().getTextId(_poolObject.getName()), _poolObject.getName().getOriginalText()) + DiagramToXMLConverter.END);
        aBuffer.append(" target="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + _poolObject.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" type="); //$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + "Association" + DiagramToXMLConverter.END); //$NON-NLS-1$

        aBuffer.append(XML_ELEMENT_CLOSING_TAG);
        aBuffer.append(this.iNewLine);
        // insert the points information
        startx = this.modifyXCoordinate(aSourceobject, startx);
        starty = this.modifyYCoordinate(aSourceobject, starty);
        this.createPointTag(startx, starty, aBuffer);
        this.createPointTag(endx, endy, aBuffer);

		aBuffer.append(CONNECTOR_ELEMENT_CLOSE); 
        aBuffer.append(this.iNewLine);
    }

    /**
     * @param aRefObject
     *            the object from where the connector goes
     * @param aObject
     *            the Annotation
     * @param aBuffer
     * @param startx
     * @param starty
     * @param endx
     * @param endy
     */
    private void createConnectorForDataObject(final RefObject aSourceobject, final Object aObject, StringBuilder aBuffer, int startx, int starty, int endx,
            int endy) {
        MessageFlowObject _poolObject = (MessageFlowObject) aObject;

        aBuffer.append("<Connector "); //$NON-NLS-1$
        aBuffer.append(" id=");//$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + _poolObject.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" label=");//$NON-NLS-1$
        // MM
//        aBuffer.append(DiagramToXMLConverter.START + getTextId(_poolObject.getName().getTextId()) + DiagramToXMLConverter.END);
        aBuffer.append(DiagramToXMLConverter.START + getTextId(ToolUtils.getInstance().getTextId(_poolObject.getName()), _poolObject.getName().getOriginalText()) + DiagramToXMLConverter.END);
        aBuffer.append(" target=");//$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + _poolObject.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" type=");//$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + "DirectedAssociation" + DiagramToXMLConverter.END); //$NON-NLS-1$

        aBuffer.append(XML_ELEMENT_CLOSING_TAG);
        aBuffer.append(this.iNewLine);
        // add pool header
        // calculate with the pool's header
        endx = PVUtil.modifyXCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, endx);
        startx = PVUtil.modifyXCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, startx);

        endy = PVUtil.modifyYCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, endy);
        starty = PVUtil.modifyYCoordinateWithPoolHeader(this.isCurrenPoolDefault, this.iOrientation, starty);

        this.createPointTag(startx, starty, aBuffer);
        this.createPointTag(endx, endy, aBuffer);

        aBuffer.append(CONNECTOR_ELEMENT_CLOSE);
        aBuffer.append(this.iNewLine);
    }

    /**
     * If the name of the element is an empty String, then the NIL_ID must be returned
     * 
     * @param String
     *            the resname of the element
     * @return NIL_ID if the the resname is empty or the resname of the element
     */
    private String getTextId(String aId, String originalName) {
    	if (aId == null || originalName == null || originalName.length() == 0) {
            return new BigInteger(1, DiagramToXMLConverter.NIL_ID).toString(16);
        } else {
            return aId;
        }
    }

    /**
     * 
     * @param OutgoingConnector
     * @param aBuffer
     * @param startx
     * @param starty
     */
    private void createConnectorTag(final RefObject aConnector, StringBuilder aBuffer, int relativeOrAbsolute) {
        // EdgeType
        if (aConnector == null)
            return;
        ModelElement _poolObject = (ModelElement) aConnector;
        aBuffer.append("<Connector ");//$NON-NLS-1$
        aBuffer.append(" id=");//$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + _poolObject.refMofId() + DiagramToXMLConverter.END);
        aBuffer.append(" label=");//$NON-NLS-1$
        // MM
//        aBuffer.append(DiagramToXMLConverter.START + getTextId(_poolObject.getName().getTextId()) + DiagramToXMLConverter.END);
        aBuffer.append(DiagramToXMLConverter.START + getTextId(ToolUtils.getInstance().getTextId(_poolObject.getName()), _poolObject.getName().getOriginalText()) + DiagramToXMLConverter.END);
        aBuffer.append(" target=");//$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + this.getConnectorTarget(aConnector) + DiagramToXMLConverter.END);
        aBuffer.append(" type=");//$NON-NLS-1$
        aBuffer.append(DiagramToXMLConverter.START + PVUtil.getConnectorType(aConnector) + DiagramToXMLConverter.END);
        //in case of ConditionalSequenceConnector the isDefault attribute is necessary 
        if(aConnector instanceof ConditionalSequenceConnector){
        	boolean isDefault = ((ConditionalSequenceConnector)aConnector).isDefault();
        	aBuffer.append(" isDefault=\"");//$NON-NLS-1$
        	aBuffer.append(Boolean.toString(isDefault));
        	aBuffer.append(DiagramToXMLConverter.END);
        }
        aBuffer.append(XML_ELEMENT_CLOSING_TAG);
        aBuffer.append(this.iNewLine);
        // insert the points information
        this.getConnectorPoints(aBuffer, aConnector, relativeOrAbsolute);

       //insert label position if it is
        this.createLabelPosition(aConnector, aBuffer);
        
        //insert label size information if it is
        this.createLabelSize(aConnector, aBuffer);
        
        aBuffer.append(CONNECTOR_ELEMENT_CLOSE);
        aBuffer.append(this.iNewLine);
    }

    /*
     * Format:
     * <LabelPosition  x="0" y="0" />
     */
    private void createLabelPosition(final RefObject aConnector, StringBuilder aBuffer) {
    	Pair result = this.getLabelCoordinates(aConnector);
    	if(result != null) {
    		aBuffer.append("<LabelPosition ");//$NON-NLS-1$
    		aBuffer.append("x=\"");//$NON-NLS-1$
    		aBuffer.append(result.first);
    		aBuffer.append("\" ");//$NON-NLS-1$
    		aBuffer.append("y=\"");//$NON-NLS-1$
    		aBuffer.append(result.second);
    		aBuffer.append("\"");//$NON-NLS-1$
    		aBuffer.append("/>");//$NON-NLS-1$
    		aBuffer.append(this.iNewLine);
    	}
    }

    /*
     * Format:
     * <LabelSize  x="0" y="0"/>
     */
    private void createLabelSize(final RefObject aConnector, StringBuilder aBuffer) {
    	Pair result = this.getLabelSize(aConnector);
    	if(result != null) {
    		aBuffer.append("<LabelSize ");	//$NON-NLS-1$
    		aBuffer.append("x=\"");	//$NON-NLS-1$
    		aBuffer.append(result.first);
    		aBuffer.append("\" ");	//$NON-NLS-1$
    		aBuffer.append("y=\"");	//$NON-NLS-1$
    		aBuffer.append(result.second);
    		aBuffer.append("\"");	//$NON-NLS-1$
    		aBuffer.append("/>");	//$NON-NLS-1$
    		aBuffer.append(this.iNewLine);
    	}
    }
    
    /*
     * Calculates the coordinates of the connector's label
     * @return Pair
     */
   private Pair getLabelCoordinates(RefObject aConnector) {
    	Pair result = null;
    	if(!(aConnector instanceof ConditionalSequenceConnector)) return result;
    	ConditionalSequenceConnector csc = (ConditionalSequenceConnector)aConnector;
    	
    	ScopeObject startObject = csc.getSource();
    	//get the end point
    	ScopeObject endObject = csc.getTarget();
    	int startX = PVUtil.getXCoordinate(startObject) + (this.iRefObjectStore.get(startObject)).getLaneX() + this.iRightShift;
        int startY = PVUtil.getYCoordinate(startObject) + (this.iRefObjectStore.get(startObject)).getLaneY() + this.iDownShift;
        int endX = PVUtil.getXCoordinate(endObject) + (this.iRefObjectStore.get(endObject)).getLaneX()  + this.iRightShift;
        int endY = PVUtil.getYCoordinate(endObject) + (this.iRefObjectStore.get(endObject)).getLaneY() + this.iDownShift;
          
    	PictogramElement[] pes = XMLUtil.getAllPictogramElementForBusinessObject(aConnector);
    	for (int i = 0; i < pes.length; i++) {
          PictogramElement element = pes[i];
          if (element instanceof ConnectionDecorator) {
              ConnectionDecorator cd = (ConnectionDecorator) element;
              double _location = cd.getLocation();
              java.awt.Point _point = XMLUtil.getConnectionMidpoint(cd.getConnection(),cd.getLocation());
              com.sap.mi.gfw.mm.pictograms.Text cdText = (com.sap.mi.gfw.mm.pictograms.Text) cd.getGraphicsAlgorithm();
              /*
               * The label coordinates are relative ones, they are calculated from
               * the connector's midpoint
               */
              int searchedX = (int)_point.getX() + cdText.getX() + this.iRightShift;
              int searchedY = (int)_point.getY() + cdText.getY() + this.iDownShift;
              result = new Pair(searchedX, searchedY);
          }//end if
      }//end for    	
      return result;
    }

   /**
    * 
    * @param aBuffer StringBuilder
    * @param aPoolObject OutgoingConnector
    */
   public void getConnectorPoints(StringBuilder aBuffer, final Object aPoolObject, int absoluteOrRelative) {

       RefObject _source = null;
       RefObject _target = null;

       _source = ((SequenceConnector) aPoolObject).getSource();
       _target = ((SequenceConnector) aPoolObject).getTarget();
       
       int _srcX = 0;
       int _srcY = 0;
       int _targetX = 0;
       int _targetY = 0;
       if(_source instanceof BoundaryEvent){
    	   Point2D bPoint=getXYCoordinateOfBoundaryEvent((BoundaryEvent)_source);
	       	_srcX = (int)bPoint.getX();
	       	_srcY = (int)bPoint.getY();
       }
       else if(_source instanceof EmbeddedScope){
	       	PictogramElement pe = PVUtil.getPictogramElement(_source);
	        int e_width = Integer.parseInt(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_WIDTH));
	        int e_height = Integer.parseInt(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_HEIGHT));
	        int ta_X = (this.iRefObjectStore.get(_source)).getLaneX()+PVUtil.getXCoordinate(_source);
	        int ta_Y = (this.iRefObjectStore.get(_source)).getLaneY()+PVUtil.getYCoordinate(_source);
	        _srcX = ta_X + e_width/2;
	        _srcY = ta_Y + e_height/2;
       }else{
       		_srcX = (this.iRefObjectStore.get(_source)).getLaneX() + PVUtil.getXCoordinate(_source);
       		_srcY =  (this.iRefObjectStore.get(_source)).getLaneY() + PVUtil.getYCoordinate(_source);
       }
       
       //check the target
       if(_target instanceof BoundaryEvent){
    	     Point2D bPoint=getXYCoordinateOfBoundaryEvent((BoundaryEvent)_source);
       		_targetX = (int)bPoint.getX();
       		_targetY = (int)bPoint.getY();
       }
       else if(_target instanceof EmbeddedScope){
	       	PictogramElement pe = PVUtil.getPictogramElement(_target);
	       	if(pe !=null){
		        int e_width = Integer.parseInt(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_WIDTH));
		        int e_height = Integer.parseInt(PVUtil.getPropertyValue(pe, FlowConstants.CONTAINER_HEIGHT));
		        int ta_X = this.iRefObjectStore.get(_target).getLaneX()+PVUtil.getXCoordinate(_target);
		        int ta_Y = this.iRefObjectStore.get(_target).getLaneY()+PVUtil.getYCoordinate(_target);
		        _targetX = ta_X + e_width/2;
		        _targetY = ta_Y + e_height/2;
	       	}
    	   //}
       }else{
    	   _targetX =  this.iRefObjectStore.get(_target).getLaneX() + PVUtil.getXCoordinate(_target);
     	   _targetY =  this.iRefObjectStore.get(_target).getLaneY() + PVUtil.getYCoordinate(_target);
       }
       //if we need the relative coordinates, then remove the laneX and laneY coordinates of the source object
       if(absoluteOrRelative == DiagramToXMLConverter.RELATIVE ){
          	_srcX = _srcX - this.iRefObjectStore.get(_source).getLaneX() ;
           	_srcY = _srcY - this.iRefObjectStore.get(_source).getLaneY() ;
           	_targetX = _targetX - this.iRefObjectStore.get(_target).getLaneX();
           	_targetY = _targetY - this.iRefObjectStore.get(_target).getLaneY();   
           	//decrease their values with the insets of the embedded subflow
           	EmbeddedScope currentEmbeddedScope = this.subflowTmpSorage.get(this.subflowTmpSorage.size()-1);
           	_srcX = _srcX - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getX();
           	_srcY = _srcY - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getY();
           	_targetX = _targetX - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getX();
           	_targetY = _targetY - PVUtil.getSelectionGraphicsAlgorithm(currentEmbeddedScope).getY();
       }
       // get the target coordinates
       PictogramElement _pPoolObject = PVUtil.getPictogramElementForSequenceConnector((RefObject) aPoolObject);

       //get the bendpoints if there are - only FreeFormConnections has bendpoints!
       if ((_pPoolObject instanceof FreeFormConnection)) {
    	   //FOR EmbeddedScope we have already modified the coordinates!
           if(!(_source instanceof EmbeddedScope)){
        	   _srcX = this.modifyXCoordinate(_source, _srcX);
        	   _srcY = this.modifyYCoordinate(_source, _srcY);
           }
           this.createPointTag(_srcX + this.iRightShift, _srcY + this.iDownShift, aBuffer);

           List<Point> _points = ((FreeFormConnection) _pPoolObject).getBendpoints();

           for (int i = 0; i < _points.size(); i++) {
               int aX = _points.get(i).getX();
               int aY = _points.get(i).getY();
               /*
                * In case we are in an Embedded subflow, the coordinates must be relative ones.
                * This means, that the coordinates of the bendpoints must be decreased with the
                * coordinate of the embedded subflow and the embedded subflow's lane coordinates
                */
               if(absoluteOrRelative == DiagramToXMLConverter.RELATIVE){
            	   EmbeddedScope currentEmbeddedScope = this.subflowTmpSorage.get(this.subflowTmpSorage.size()-1);
            	   aX = aX - PVUtil.getXCoordinate(currentEmbeddedScope) - this.iRefObjectStore.get(currentEmbeddedScope).getLaneX(); 
            	   aY = aY - PVUtil.getYCoordinate(currentEmbeddedScope) - this.iRefObjectStore.get(currentEmbeddedScope).getLaneY();
               }
               this.createPointTag(aX + this.iRightShift, aY + this.iDownShift, aBuffer);
               this.checkForHighestXCoordinate(aX + this.iRightShift);
               this.checkForHighestYCoordinate(aY + this.iDownShift);
           }
           //FOR EmbeddedScope we have already modified the coordinates!
           if(!(_target instanceof EmbeddedScope)){
        	   _targetX = this.modifyXCoordinate(_target, _targetX);
        	   _targetY = this.modifyYCoordinate(_target, _targetY);
           }
           this.createPointTag(_targetX + this.iRightShift, _targetY + this.iDownShift, aBuffer);
       } 
   }
   
   
    /**
     * Returns the size of the label
     * @param RefObject aConnector
     * @return Pair
     */
    private Pair getLabelSize(final RefObject aConnector) {
    	Pair result = null;
    	if(!(aConnector instanceof ConditionalSequenceConnector)) return result;
    	PictogramElement[] pes = XMLUtil.getAllPictogramElementForBusinessObject(aConnector);
    	for (int i = 0; i < pes.length; i++) {
          PictogramElement element = pes[i];
          if (element instanceof ConnectionDecorator) {
              ConnectionDecorator cd = (ConnectionDecorator) element;
              com.sap.mi.gfw.mm.pictograms.Text cdText = (com.sap.mi.gfw.mm.pictograms.Text) cd.getGraphicsAlgorithm();
              result = new Pair(cdText.getWidth(), cdText.getHeight());
          }
        }    	
    	return result;
    }
    
    /**
     * Modifies the X coordinate: adds the insets + the half of the width
     * 
     * @param RefObject
     * @param int
     *            the default x coordinate
     * @return int the modified x coordinate
     */
    private int modifyXCoordinate(final RefObject aRefObject, int coordinate) {
        coordinate = coordinate + PVUtil.getRefObjectWidth(aRefObject) / 2 + PVUtil.getInsets(aRefObject, 0);
        return coordinate;
    }

    /**
     * Modifies the Y coordinate: adds the insets + in case of Gateway the half of the height
     * 
     * @param RefObject
     * @param int
     *            the default y coordinate
     * @return int the modified y coordinate
     */
    private int modifyYCoordinate(final RefObject aRefObject, int coordinate) {
        coordinate = coordinate + PVUtil.getRefObjectHeight(aRefObject) / 2 + PVUtil.getInsets(aRefObject, 1);
        return coordinate;
    }

  
    /**
     * Gets the connector's target
     * The method checks whether the target element is artificial or not.
     * If the target element is artificial, then the next not artificial element's
     * MOF id is returned 
     *  
     * @param aConnector RefObject The connector object
     * @return String the MOF ID of the target element
     */
    public String getConnectorTarget(final RefObject aConnector) {
        //check whether the target is artificial
    	RefObject target = null;
    	if(aConnector instanceof MessageFlowConnector){
    		target = ((MessageFlowConnector)aConnector).getTarget();
    	}else{
    		target = ((SequenceConnector)aConnector).getTarget();
    	}
        if(target instanceof UncontrolledJoinGateway && PVUtil.isGatewayArtificial((UncontrolledJoinGateway)target)){ 
        	//get the next not artificial element 
        	List<SequenceConnector> connectors = ((UncontrolledJoinGateway)target).getOutgoingConnectors();
        	return connectors.get(0).getTarget().refMofId();
        }
        return target.refMofId();
    }

    /**
     * 
     * @param String
     *            contains the numbers in format: "<number1>, <number2>"
     * @param int
     *            which number to get -first or the second
     * @return
     */
    private String getNrFromString(String aString, final int aWhich) {
        // get the first
        if (aWhich == 0) {
            int index = aString.indexOf(","); 	//$NON-NLS-1$
            return aString.substring(0, index);
        }
        // get the second
        else if (aWhich == 1) {
            int index = aString.indexOf(",");	//$NON-NLS-1$
            return aString.substring(index + 1, aString.length());
        } else {
            return "";	//$NON-NLS-1$
        }
    }

    private void checkXForShift(final int aXcoordinate) {
        if (aXcoordinate < this.iRightShift) {
            this.iRightShift = aXcoordinate;
        }
    }

    private void checkYForShift(final int aYcoordinate) {
        if (aYcoordinate < this.iDownShift) {
            this.iDownShift = aYcoordinate;
        }
    }

    private void checkForHighestXCoordinate(final int aXCoordinate) {
        if (aXCoordinate > this.iHighestX) {
            this.iHighestX = aXCoordinate;
        }
    }

    private void checkForHighestYCoordinate(final int aYCoordinate) {
        if (aYCoordinate > this.iHighestY) {
            this.iHighestY = aYCoordinate;
        }
    }

    /*
     * Checks the bendpoints coordinates of the connector.
     * 
     * @param ScopeObject
     *            the Connector
     */
    private void checkBendPointsForShift(final ScopeObject aConnector) {
        PictogramElement pElement = PVUtil.getPictogramElementForSequenceConnector((RefObject) aConnector);
        if (!(pElement instanceof FreeFormConnection))
            return;
        List<Point> list = ((FreeFormConnection) pElement).getBendpoints();
        for (Point point : list) {
            this.checkXForShift(point.getX());
            this.checkYForShift(point.getY());
        }
    }
    
    /*
     * Generate all note types inside the embedded subflow
     * In case of embedded subflow, the x and y coordinates of the
     * scope objects must be calculated with absolute coordinates, not
     * with relative ones. 
     * 
     * @param aScope EmbeddedScope
     * @param aBuffer StringBuilder
     */
    private void generateEmbeddedSubflowElements(EmbeddedScope aScope, StringBuilder aBuffer) {
    	boolean artificialLoopsScope=false;
    	if(aScope instanceof ArtificialLoopScope)
    	{
    		artificialLoopsScope=true;
    	}
    	else
    	{
    		this.subflowTmpSorage.add(aScope);
    	}
    	
    	Collection<ScopeObject> elements = aScope.getScopeObjects();
    	for(ScopeObject so: elements) {
    		if(this.toGenerateInEmbeddedSubflow(so) == false){
    			continue;
    		}
    		if(so instanceof ArtificialLoopScope)
    		{
    			generateEmbeddedSubflowElements((EmbeddedScope)so, aBuffer);
    			continue;
    		}
   			this.createNodeType(so, aBuffer, false, DiagramToXMLConverter.RELATIVE);
   			this.createNodeEndType(so, aBuffer, false, DiagramToXMLConverter.RELATIVE);
    	}
    	if(!artificialLoopsScope)
    	{
    	//remove the added EmbeddedScope
    	this.subflowTmpSorage.remove(this.subflowTmpSorage.size()-1);
    	}
    }

    private Vector<EmbeddedScope>  subflowTmpSorage = new Vector<EmbeddedScope>(); 
}
