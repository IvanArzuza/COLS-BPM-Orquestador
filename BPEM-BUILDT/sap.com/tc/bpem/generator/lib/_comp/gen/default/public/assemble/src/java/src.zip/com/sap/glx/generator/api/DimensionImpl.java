package com.sap.glx.generator.api;

import com.sap.glx.generator.api.IDimension;

public class DimensionImpl implements IDimension {

    private int width;

    private int height;

    public DimensionImpl(int width, int height) {
        setWidth(width);
        setHeight(height);
    }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public void setWidth(int width) {
        this.width = width;
    }
}
