package com.sap.glx.generator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import com.sap.glx.generator.api.DimensionImpl;
import com.sap.glx.generator.api.IDimension;
import com.sap.glx.generator.api.ILocation;
import com.sap.glx.generator.api.LocationImpl;
import com.sap.glx.ide.model.galaxy.mapping.Mapping;
import com.sap.glx.ide.model.galaxy.mapping.MappingPart;
import com.sap.glx.ide.model.galaxy.task.StandaloneTask;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.MappingActivity;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.TextVariable;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.mi.gfw.mm.datatypes.Point;
import com.sap.mi.gfw.mm.links.DiagramLink;
import com.sap.mi.gfw.mm.links.LinksPackage;
import com.sap.mi.gfw.mm.links.PictogramLink;
import com.sap.mi.gfw.mm.links.PictogramLinkReferencesBusinessObjects;
import com.sap.mi.gfw.mm.pictograms.Anchor;
import com.sap.mi.gfw.mm.pictograms.AnchorContainer;
import com.sap.mi.gfw.mm.pictograms.BoxRelativeAnchor;
import com.sap.mi.gfw.mm.pictograms.ChopboxAnchor;
import com.sap.mi.gfw.mm.pictograms.ConnectionDecorator;
import com.sap.mi.gfw.mm.pictograms.Diagram;
import com.sap.mi.gfw.mm.pictograms.FixPointAnchor;
import com.sap.mi.gfw.mm.pictograms.FreeFormConnection;
import com.sap.mi.gfw.mm.pictograms.GraphicsAlgorithm;
import com.sap.mi.gfw.mm.pictograms.PictogramElement;
import com.sap.mi.gfw.mm.pictograms.Polyline;
import com.sap.mi.gfw.mm.pictograms.Property;
import com.sap.mi.gfw.mm.pictograms.Shape;
import com.sap.tc.esmp.mm.xsd1.XsdComplexTypeContent;
import com.sap.tc.esmp.mm.xsd1.XsdComplexTypeDefinition;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdFeature;
import com.sap.tc.esmp.mm.xsd1.XsdModelGroup;
import com.sap.tc.esmp.mm.xsd1.XsdParticle;
import com.sap.tc.esmp.mm.xsd1.XsdParticleContent;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.Partitionable;
import com.sap.tc.moin.repository.mmi.descriptors.ClassDescriptor;
import com.sap.tc.moin.repository.mmi.reflect.RefObject;

public class XMLUtil {

    public static final String CONTROL_FLOW_ASSIGN_T4_MAPPING_ACTIVITY_NAME = "AssignT4";	//$NON-NLS-1$
	public static final String DATA_FLOW_TASK_INSTANCE_ATTRIBUTES_DATA_OBJECT_NAME = "TaskAttributes";	//$NON-NLS-1$
    public static final List<String> PATH_COMPLETION_DEADLINE = Arrays.asList("TaskAttributes",	//$NON-NLS-1$
    		"completionDeadline");	//$NON-NLS-1$
    public static final String XSD1_PACKAGE_NAME = "XSD1";	//$NON-NLS-1$
    private static final String GRAPHICS_CONTAINER_NAME = "sap.com/com/sap/mi/gfw/mm";	//$NON-NLS-1$
    private static final String LINKS_PACKAGE_NAME = "links";	//$NON-NLS-1$
    private static final String KEY_INDEPENDENT_PROPERTY = "independentObject"; // key for the shape	//$NON-NLS-1$


	/**
	 * checks if the completion deadline is set at the Task Scope level
	 * 
	 * @param task
	 * @return
	 */
	public static boolean isCompletionDeadlineSet(StandaloneTask task){
		
		Connection connection = ((Partitionable) task).get___Connection();
		
		MappingActivity assignT4 = findMappingActivityByName(connection, task, CONTROL_FLOW_ASSIGN_T4_MAPPING_ACTIVITY_NAME);
		if(assignT4 == null){
			return false;
		}
		
		Mapping mapping = assignT4.getOutputMapping();
		
		DataObject taskAttributesDo = findDataObjectByName(connection, task, DATA_FLOW_TASK_INSTANCE_ATTRIBUTES_DATA_OBJECT_NAME);
		XsdElementDeclaration rootXsd = taskAttributesDo.getXsdElementDeclaration();
		
		ArrayList<XsdElementDeclaration> xsdPath = null;
		try {
			xsdPath = transformPathToXsdElementDeclartions(rootXsd, PATH_COMPLETION_DEADLINE);
		} catch (Exception e) {
			return false;
		}
		
		int pathSize = xsdPath.size();
		
		XsdElementDeclaration mappingTarget = xsdPath.get(pathSize-1);
		
		ArrayList<MappingPart> targetMps = new ArrayList<MappingPart>();
		XMLUtil.findMappingPartForXsdFeature(mappingTarget, mapping.getMappingParts(), targetMps);
		if(targetMps.size() == 2 && (targetMps.get(0).isEnabled() || targetMps.get(1).isEnabled())){
			return true;
		}
		
		return false;
		
	}

	/**
	 * searches for a Mapping Activity in the given scope by name
	 * 
	 * @param connection
	 * @param scope
	 * @param name
	 * @return
	 */
	public static MappingActivity findMappingActivityByName(
			Connection connection, Scope scope, String name)
			throws IllegalArgumentException {

		return (MappingActivity) findScopeObjectByName(connection, scope, name,
				MappingActivity.CLASS_DESCRIPTOR, MappingActivity.class);
	}

	/**
	 * searches for a Data Object in the given scope by name
	 * 
	 * @param connection
	 * @param scope
	 * @param name
	 * @return
	 */
	public static DataObject findDataObjectByName(Connection connection,
			Scope scope, String name) throws IllegalArgumentException {
		return (DataObject) findScopeObjectByName(connection, scope, name,
				DataObject.CLASS_DESCRIPTOR, DataObject.class);
	}
	/**
	 * searches for a Scope Object in the given scope by name
	 * 
	 * @param connection
	 * @param scope
	 * @param name
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static ScopeObject findScopeObjectByName(Connection connection,
			Scope scope, String name, ClassDescriptor descriptor, Class clazz)
			throws IllegalArgumentException {
		if (scope == null || name == null)
			throw new IllegalArgumentException(
					"Passed arguments must not be null");	//$NON-NLS-1$

		Collection<ScopeObject> scopeObjects = getScopeObjectsOfScope(
				connection, scope, descriptor, clazz);

		for (ScopeObject scopeObject : scopeObjects) {
			if (scopeObject.getName().getOriginalText().equals(name))
				return scopeObject;
		}

		return null;
	}

	/**
	 * retrieve all Scope Objects of a scope (with subtypes)
	 * 
	 * @param connection
	 * @param scope
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static Collection<ScopeObject> getScopeObjectsOfScope(
			Connection connection, Scope scope, ClassDescriptor descriptor,
			Class clazz) {
		return ToolUtils.getInstance().queryByType(connection, clazz, descriptor
				.getQualifiedName(), true, scope);
	}

	/**
	 * searches for a mapping part with the given XsdFeature as target
	 * 
	 * @param xsdFeature
	 * @param mappingParts
	 * @return the first match
	 */
	public static MappingPart findMappingPartForXsdFeature(
			XsdFeature xsdFeature, List<MappingPart> mappingParts) {
		for (MappingPart mappingPart : mappingParts) {
			if (mappingPart.getTarget() == xsdFeature) {
				return mappingPart;
			}
			return findMappingPartForXsdFeature(xsdFeature, mappingPart
					.getChildren());
		}
		return null;
	}
	
	/**
	 * searches for a mapping part with the given XsdFeature as target
	 * 
	 * @param xsdFeature
	 * @param mappingParts
	 * @return all matches
	 */
	public static void findMappingPartForXsdFeature(
			XsdFeature xsdFeature, List<MappingPart> mappingParts, List<MappingPart> foundMps) {
		for (MappingPart mappingPart : mappingParts) {
			if (mappingPart.getTarget() == xsdFeature) {
				foundMps.add(mappingPart);
			}
			findMappingPartForXsdFeature(xsdFeature, mappingPart
					.getChildren(), foundMps);
		}
		return;
	}	

	/**
	 * transforms a given path to a list of the XsdElementDeclerations found at
	 * this path Entry point is the given root xsdElement
	 * 
	 * @param rootXsdElement
	 * @param path
	 * @return
	 * @throws Exception
	 */
	public static ArrayList<XsdElementDeclaration> transformPathToXsdElementDeclartions(
			XsdElementDeclaration rootXsdElement, List<String> path)
			throws Exception {

		if (rootXsdElement == null || path == null || path.size() == 0)
			throw new IllegalArgumentException();
		ArrayList<String> internalPath = new ArrayList<String>(path);
		String elementName = internalPath.get(0);
		ArrayList<XsdElementDeclaration> pathList = new ArrayList<XsdElementDeclaration>();
		if (!rootXsdElement.getName().equals(elementName)) {
			throw new Exception(
					"Root Xsd Element Declaration name does not match passed path.");	//$NON-NLS-1$
		}
		
		if (internalPath.size() == 1) {
			pathList.add(rootXsdElement);
			return pathList;
		}
		internalPath.remove(0);
		buildXsdElementPathList(pathList, rootXsdElement, internalPath);
		return pathList;
	}

	private static void buildXsdElementPathList(
			ArrayList<XsdElementDeclaration> pathList,
			XsdElementDeclaration parentElement, ArrayList<String> internalPath)
			throws Exception {
		
		pathList.add(parentElement);
		if (internalPath.size() == 0) {			
			return;
		}
		String elementName = internalPath.get(0);
		XsdElementDeclaration childElement = (XsdElementDeclaration) ToolUtils.getInstance().getFeatureByName(parentElement, elementName);
		if (childElement == null) {
			throw new Exception("Could not find element with name "	//$NON-NLS-1$
					+ elementName);
		}
		internalPath.remove(0);
		buildXsdElementPathList(pathList, childElement, internalPath);
	}

    /**
     * This method is similar to
     * 
     * @see "LinkUtil.getPictogramElements()", but it doesn't require any extra input and only return the first pe.
     */
    @SuppressWarnings("unchecked")
    public static PictogramElement getFirstPictogramElementForBusinessObject(RefObject refObject) {
        LinksPackage lp = getLinksPackage(refObject);
        PictogramLinkReferencesBusinessObjects assoc = lp.getPictogramLinkReferencesBusinessObjects();
        Collection<PictogramLink> links = assoc.getPictogramLink(refObject);
        if (links != null) {
            for (PictogramLink link : links) {
                return link.getPictogramElement();

            }
        }
        return null;
    }
    
    
    @SuppressWarnings("unchecked")
    public static PictogramElement[] getAllPictogramElementForBusinessObject(RefObject refObject) {
    	ArrayList<PictogramElement> result = new ArrayList(); 
        LinksPackage lp = getLinksPackage(refObject);
        PictogramLinkReferencesBusinessObjects assoc = lp.getPictogramLinkReferencesBusinessObjects();
        Collection<PictogramLink> links = assoc.getPictogramLink(refObject);
        if (links != null) {
            for (PictogramLink link : links) {
            	result.add(link.getPictogramElement());
            }
        }
        return result.toArray(new PictogramElement[result.size()]);
    }
    

    @SuppressWarnings("unchecked")
    public static Diagram getDiagram(RefObject refObject) {
        LinksPackage lp = getLinksPackage(refObject);
        PictogramLinkReferencesBusinessObjects assoc = lp.getPictogramLinkReferencesBusinessObjects();
        Collection<PictogramLink> links = assoc.getPictogramLink(refObject);
        if (links != null) {
            for (PictogramLink link : links) {
                DiagramLink dl = link.getDiagramLink();
                if (dl != null)
                    return dl.getDiagram();

            }
        }
        return null;
    }

    public static LinksPackage getLinksPackage(RefObject refObject) {
        Connection connection = ((Partitionable) refObject).get___Connection();
        return getLinksPackage(connection);
    }

    public static LinksPackage getLinksPackage(Connection connection) {
        LinksPackage p = (LinksPackage) connection.getPackage(GRAPHICS_CONTAINER_NAME, LINKS_PACKAGE_NAME);
        return p;
    }

    /**
     * Calculates the size of the given graphics algorithm. If the graphics algorithm is a polyline or polygon then the
     * size will be calculated. Otherwise the size of the graphics algorithm is simply returned.
     * 
     * @param ga GraphicsAlgorithm
     * @return
     */
    public static IDimension calculateSizeOfGraphicsAlgorithm(GraphicsAlgorithm ga) {
        IDimension ret = null;
        if (ga instanceof Polyline) {
            Polyline pl = (Polyline) ga;
            ret = calculatePolylineMinSize(pl);
        } else {
            ret = new DimensionImpl(ga.getWidth(), ga.getHeight());
        }
        return ret;
    }

    /**
     * @param polyline
     * @return
     */
    private static IDimension calculatePolylineMinSize(Polyline polyline) {
        Collection<Point> points = polyline.getPoints();

        int minX = points.isEmpty() ? 0 : ((Point) points.toArray()[0]).getX();
        int minY = points.isEmpty() ? 0 : ((Point) points.toArray()[0]).getY();
        int maxX = minX;
        int maxY = minY;

        for (Iterator<Point> iter = points.iterator(); iter.hasNext();) {
            Point point = iter.next();
            int x = point.getX();
            int y = point.getY();
            minX = Math.min(minX, x);
            minY = Math.min(minY, y);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, y);
        }
        return new DimensionImpl(Math.abs(maxX - minX) + 1, Math.abs(maxY - minY) + 1);
    }

    /**
     * Returns the first one of all linked domain model elements
     * 
     * @param pictogramElement
     * @return the first one of all linked domain model elements (if at least one available)
     */
    public static RefObject getBusinessObjectForLinkedPictogramElement(PictogramElement pictogramElement) {
        RefObject ret = null;
        RefObject refObject[] = getAllBusinessObjectsForPictogramElement(pictogramElement);
        if (refObject != null && refObject.length > 0) {
            ret = refObject[0];
        }
        return ret;
    }

    @SuppressWarnings("unchecked")
    public static RefObject[] getAllBusinessObjectsForPictogramElement(PictogramElement pictogramElement) {
        PictogramLink link = pictogramElement.getLink();
        if (link != null)
            return link.getBusinessObjects().toArray(new RefObject[0]);
        return new RefObject[0];
    }


    /**
     * @param obj
     * @return
     */
    public static boolean isObjectAlive(RefObject obj) {
        if (obj instanceof Partitionable) {
            Partitionable objX = (Partitionable) obj;
            return (objX.is___Alive());
        }
        return true;

    }


    public static Property getIndependentProperty(PictogramElement pictogramElement) {
        return getProperty(pictogramElement, KEY_INDEPENDENT_PROPERTY);
    }

    /**
     * Returns the property of a given pictogram element for a specific key
     * 
     * @param pictogramElement the pictogram element
     * @param key the property's key
     * @return the property for the given key
     */
    public static Property getProperty(PictogramElement pictogramElement, String key) {
        if (pictogramElement == null || key == null) {
            return null;
        }
        Collection<Property> collection = pictogramElement.getProperties();
        for (Iterator<Property> iter = collection.iterator(); iter.hasNext();) {
            Property property = iter.next();
            if (key.equals(property.getKey())) {
                return property;
            }
        }
        return null;
    }

    /**
     * Returns the property's value of a given pictogram element for a specific
     * key
     * 
     * @param pictogramElement the pictogram element
     * @param key the property's key
     * @return the property's value
     */
    public static String getPropertyValue(PictogramElement pictogramElement, String key) {
        Property property = getProperty(pictogramElement, key);
        if (property != null) {
            return property.getValue();
        }
        return null;
    }

    /**
     * Returns the location of the anchor relative to the diagram
     * 
     * @param anchor the given anchor
     * @return the relative location
     */
    public static ILocation getLocationRelativeToDiagram(Anchor anchor) {
        int x = getRelativeToDiagramX(anchor);
        int y = getRelativeToDiagramY(anchor);
        ILocation ret = new LocationImpl(x, y);
        return ret;
    }

    /**
     * Returns the location of the shape relative to the diagram
     * 
     * @param shape the given shape
     * @return the relative location
     */
    public static ILocation getLocationRelativeToDiagram(Shape shape) {
        int x = getRelativeToDiagramX(shape);
        int y = getRelativeToDiagramY(shape);
        ILocation ret = new LocationImpl(x, y);
        return ret;
    }

    /**
     * Returns the x coordinate of the anchor relative to the diagram
     * 
     * @param anchor the given anchor
     * @return the x coordinate
     */
    private static int getRelativeToDiagramX(Anchor anchor) {
		int ret = 0;
		if (anchor == null) {
			return ret;
		}
		if (anchor instanceof FixPointAnchor) {
			FixPointAnchor fpa = (FixPointAnchor) anchor;
			java.awt.Rectangle gaBoundsForAnchor = getGaBoundsForAnchor(anchor);
			ret = gaBoundsForAnchor.x + fpa.getLocation().getX();
		} else if (anchor instanceof BoxRelativeAnchor) {
			BoxRelativeAnchor bra = (BoxRelativeAnchor) anchor;
			java.awt.Rectangle gaBoundsForAnchor = getGaBoundsForAnchor(anchor);
			ret = gaBoundsForAnchor.x + (int) Math.round(gaBoundsForAnchor.width * bra.getRelativeWidth());
		} else if (anchor instanceof ChopboxAnchor) {
			ret = Math.round(getWidthOfPictogramElement(anchor.getParent()) / 2);
		}

        if (anchor != null) {
            AnchorContainer anchorContainer = anchor.getParent();
            if (anchorContainer instanceof Shape) {
                Shape shape = (Shape) anchorContainer;
                ret = ret + getRelativeToDiagramX(shape);
            }
        }

        return ret;
    }

    /**
     * Returns the x coordinate of the shape relative to the diagram
     * 
     * @param shape the given shape
     * @return the x coordinate
     */
    private static int getRelativeToDiagramX(Shape shape) {
        int ret = 0;
		if (!(shape instanceof ConnectionDecorator)) {
			while (shape != null && !(shape instanceof Diagram)) {
				ret = ret + getXOfPictogramElement(shape);
				shape = shape.getContainer();
			}
		} else {
			ConnectionDecorator decorator = (ConnectionDecorator) shape;
			java.awt.Point midpoint = getConnectionMidpoint(decorator.getConnection(), decorator.getLocation());
			ret = decorator.getGraphicsAlgorithm().getX() + midpoint.x;
		}
		return ret;
	}

    /**
     * Returns the y coordinate of the anchor relative to the diagram
     * 
     * @param anchor the given anchor
     * @return the y coordinate
     */
	private static int getRelativeToDiagramY(Anchor anchor) {
		int ret = 0;
		if (anchor == null) {
			return ret;
		}
		if (anchor instanceof FixPointAnchor) {
			FixPointAnchor fpa = (FixPointAnchor) anchor;
			java.awt.Rectangle gaBoundsForAnchor = getGaBoundsForAnchor(anchor);
			ret = gaBoundsForAnchor.y + fpa.getLocation().getY();
		} else if (anchor instanceof BoxRelativeAnchor) {
			BoxRelativeAnchor bra = (BoxRelativeAnchor) anchor;
			java.awt.Rectangle gaBoundsForAnchor = getGaBoundsForAnchor(anchor);
			ret = gaBoundsForAnchor.y + (int) Math.round(gaBoundsForAnchor.height * bra.getRelativeHeight());
		} else if (anchor instanceof ChopboxAnchor) {
			ret = Math.round(getHeightOfPictogramElement(anchor.getParent()) / 2);
		}

        AnchorContainer anchorContainer = anchor.getParent();
        if (anchorContainer instanceof Shape) {
            Shape shape = (Shape) anchorContainer;
            ret = ret + getRelativeToDiagramY(shape);
        }

        return ret;
    }

    /**
     * Returns the size of the pictogram element (more exactly: size of its
     * graphics algorithm)
     * 
     * @param pe given pictogram element
     * @return the size
     */
    private static int getWidthOfPictogramElement(PictogramElement pe) {
        int ret = 0;
        GraphicsAlgorithm ga = pe.getGraphicsAlgorithm();
        if (ga != null) {
            ret = ga.getWidth();
        }
        return ret;
    }

    /**
     * Returns the location of the given pictogram element - more exactly the
     * location of the pictogram element's graphics algorithm
     * 
     * @param pe the given pictogram element
     * @return the location
     */
    private static int getXOfPictogramElement(PictogramElement pe) {
        int ret = 0;
        GraphicsAlgorithm ga = pe.getGraphicsAlgorithm();
        if (ga != null) {
            ret = ga.getX();
        }
        return ret;
    }

    /**
     * Returns the size of the pictogram element (more exactly: size of its
     * graphics algorithm)
     * 
     * @param pe given pictogram element
     * @return the size
     */
    private static int getHeightOfPictogramElement(PictogramElement pe) {
        int ret = 0;
        GraphicsAlgorithm ga = pe.getGraphicsAlgorithm();
        if (ga != null) {
            ret = ga.getHeight();
        }
        return ret;
    }

    /**
     * Returns the y coordinate of the shape relative to the diagram
     * 
     * @param shape the given shape
     * @return the y coordinate
     */
    private static int getRelativeToDiagramY(Shape shape) {
        int ret = 0;
		if (!(shape instanceof ConnectionDecorator)) {
			while (shape != null && !(shape instanceof Diagram)) {
				ret = ret + getYOfPictogramElement(shape);
				shape = shape.getContainer();
			}
		} else {
			ConnectionDecorator decorator = (ConnectionDecorator) shape;
			java.awt.Point midpoint = getConnectionMidpoint(decorator.getConnection(), decorator.getLocation());
			ret = decorator.getGraphicsAlgorithm().getY() + midpoint.y;
		}
        return ret;
    }

    /**
     * Returns the location of the given pictogram element - more exactly the
     * location of the pictogram element's graphics algorithm
     * 
     * @param pe the given pictogram element
     * @return the location
     */
    private static int getYOfPictogramElement(PictogramElement pe) {
        int ret = 0;
        GraphicsAlgorithm ga = pe.getGraphicsAlgorithm();
        if (ga != null) {
            ret = ga.getY();
        }
        return ret;
    }

    /**
     * Returns a list of {@link XsdElementDeclaration}s reprenting the modelled text variables of a pool or task.
     * @param scope either a pool or task
     * @return list of text variables
     */
    public static List<XsdElementDeclaration> getTextVariablesOfScope(Scope scope) {
        Connection connection = ToolUtils.getInstance().getConnection(scope);
        Collection<TextVariable> textVariables = ToolUtils.getInstance().queryByTypeAndJoinCondition(connection, TextVariable.class,
                TextVariable.CLASS_DESCRIPTOR.getQualifiedName(), true, scope, "scope", scope); //$NON-NLS-1$
        if (textVariables.size() == 1) {
            TextVariable textVariable = textVariables.iterator().next();
            XsdComplexTypeDefinition variableType = (XsdComplexTypeDefinition) textVariable.getXsdElementDeclaration().getTypeDefinition();
            return getXsdElementsOfComplexType(variableType);
        } else {
            throw new IllegalArgumentException("Scope '" + scope.getOriginalName() + "' does not contain any text variables."); //$NON-NLS-1$ //$NON-NLS-2$
        }
    }

    private static List<XsdElementDeclaration> getXsdElementsOfComplexType(XsdComplexTypeDefinition anonymusComplexType) {
        XsdComplexTypeContent variablesComplexTypeContent = anonymusComplexType.getContent();
        XsdParticle xsdParticle = (XsdParticle) variablesComplexTypeContent;
        XsdParticleContent xsdParticleContent = xsdParticle.getContent();
        XsdModelGroup xsdModelGroup = (XsdModelGroup) xsdParticleContent;
        List<XsdParticle> contents = xsdModelGroup.getContents();

        List<XsdElementDeclaration> result = new ArrayList<XsdElementDeclaration>(contents.size());
        for (XsdParticle particle : contents) {
            XsdParticleContent particleContent = particle.getContent();
            XsdElementDeclaration elemDecl = (XsdElementDeclaration) particleContent;
            if (elemDecl == null) {
                continue;
            }
            result.add(elemDecl);
        }
        return result;
    }


	/**
	 * Returns the bounds of the GA, which is referenced by the anchor.
	 */
	public static java.awt.Rectangle getGaBoundsForAnchor(Anchor anchor) {
		java.awt.Rectangle ret = new java.awt.Rectangle();

		GraphicsAlgorithm parentGa = anchor.getParent().getGraphicsAlgorithm();
		if (parentGa != null) {
			if (anchor.getReferencedGraphicsAlgorithm() != null) {
				GraphicsAlgorithm referencedGa = anchor.getReferencedGraphicsAlgorithm();
				int relX = getRelativeX(referencedGa, parentGa);
				int relY = getRelativeY(referencedGa, parentGa);
				ret = new java.awt.Rectangle(relX, relY, referencedGa.getWidth(), referencedGa.getHeight());
			} else {
				ret = new java.awt.Rectangle(0, 0, parentGa.getWidth(), parentGa.getHeight());
			}
		}

		return ret;
	}


	private static java.awt.Point getChopboxLocationOnBox(java.awt.Point outsidePoint, java.awt.Rectangle box) {
		java.awt.Rectangle r = new java.awt.Rectangle(box.x - 1, box.y - 1, box.width + 1, box.height + 1);

		float centerX = r.x + 0.5f * r.width;
		float centerY = r.y + 0.5f * r.height;

		if (r.isEmpty() || (outsidePoint.x == (int) centerX && outsidePoint.y == (int) centerY))
			return new java.awt.Point((int) centerX, (int) centerY); // This
		// avoids
		// divide-by-zero

		float dx = outsidePoint.x - centerX;
		float dy = outsidePoint.y - centerY;

		// r.width, r.height, dx, and dy are guaranteed to be non-zero.
		float scale = 0.5f / Math.max(Math.abs(dx) / r.width, Math.abs(dy) / r.height);

		dx *= scale;
		dy *= scale;
		centerX += dx;
		centerY += dy;

		return new java.awt.Point(Math.round(centerX), Math.round(centerY));
	}

	/**
	 * Gets the connection midpoint.
	 * 
	 * @param c
	 *            the c
	 * @param d
	 *            the d
	 * @return the connection midpoint
	 */
	public static java.awt.Point getConnectionMidpoint(com.sap.mi.gfw.mm.pictograms.Connection c, double d) {
		java.awt.Point ret = null;

		Anchor startAnchor = c.getStart();
		ILocation startLocation = getLocationRelativeToDiagram(startAnchor);
		java.awt.Point startPoint = new java.awt.Point(startLocation.getX(), startLocation.getY());

		Anchor endAnchor = c.getEnd();
		ILocation endLocation = getLocationRelativeToDiagram(endAnchor);
		java.awt.Point endPoint = new java.awt.Point(endLocation.getX(), endLocation.getY());

		// special solutions for chopbox anchors
		if (startAnchor instanceof ChopboxAnchor || endAnchor instanceof ChopboxAnchor) {
			if (startAnchor instanceof ChopboxAnchor) {
				ChopboxAnchor cbStartAnchor = (ChopboxAnchor) startAnchor;
				GraphicsAlgorithm parentGa = cbStartAnchor.getParent().getGraphicsAlgorithm();
				Shape shape = (Shape) cbStartAnchor.getParent();
				ILocation location = getLocationRelativeToDiagram(shape);
				java.awt.Rectangle parentRect = new java.awt.Rectangle(location.getX(), location.getY(), parentGa.getWidth(), parentGa
						.getHeight());

				java.awt.Point pointNextToStartAnchor = new java.awt.Point(startPoint.x, startPoint.y);

				if (c instanceof FreeFormConnection) {
					FreeFormConnection ffc = (FreeFormConnection) c;
					List<Point> bendpoints = ffc.getBendpoints();
					if (!bendpoints.isEmpty()) {
						Point firstBendpoint = bendpoints.get(0);
						pointNextToStartAnchor.setLocation(firstBendpoint.getX(), firstBendpoint.getY());
					}
				}

				java.awt.Point chopboxLocationOnBox = getChopboxLocationOnBox(pointNextToStartAnchor, parentRect);

				startPoint.setLocation(chopboxLocationOnBox);
			}

			if (endAnchor instanceof ChopboxAnchor) {
				ChopboxAnchor cbEndAnchor = (ChopboxAnchor) endAnchor;
				GraphicsAlgorithm parentGa = cbEndAnchor.getParent().getGraphicsAlgorithm();
				Shape shape = (Shape) cbEndAnchor.getParent();
				ILocation location = getLocationRelativeToDiagram(shape);
				java.awt.Rectangle parentRect = new java.awt.Rectangle(location.getX(), location.getY(), parentGa.getWidth(), parentGa
						.getHeight());

				java.awt.Point pointNextToEndAnchor = new java.awt.Point(endPoint.x, endPoint.y);

				if (c instanceof FreeFormConnection) {
					FreeFormConnection ffc = (FreeFormConnection) c;
					List<Point> bendpoints = ffc.getBendpoints();
					if (!bendpoints.isEmpty()) {
						Point lastBendpoint = bendpoints.get(bendpoints.size() - 1);
						pointNextToEndAnchor.setLocation(lastBendpoint.getX(), lastBendpoint.getY());
					}
				}

				java.awt.Point chopboxLocationOnBox = getChopboxLocationOnBox(pointNextToEndAnchor, parentRect);

				endPoint.setLocation(chopboxLocationOnBox);
			}
		}

		if (c instanceof FreeFormConnection) {
			FreeFormConnection ffc = (FreeFormConnection) c;
			List<Point> bendpoints = ffc.getBendpoints();

			java.awt.Point[] awtPointsArray = new java.awt.Point[bendpoints.size() + 2];
			{
				awtPointsArray[0] = startPoint;
				int i = 1;
				for (Iterator<Point> iter = bendpoints.iterator(); iter.hasNext();) {
					Point pictogramsPoint = iter.next();
					awtPointsArray[i] = new java.awt.Point(pictogramsPoint.getX(), pictogramsPoint.getY());
					i++;
				}
				awtPointsArray[i] = endPoint;
			}

			double completeDistance = getDistance(awtPointsArray);
			double absDistanceToRelPoint = completeDistance * d;

			double distanceSum = 0;
			for (int i = 0; i < awtPointsArray.length - 1; i++) {
				double oldDistanceSum = distanceSum;
				java.awt.Point currentPoint = awtPointsArray[i];
				java.awt.Point nextPoint = awtPointsArray[i + 1];
				double additionalDistanceToNext = getDistance(currentPoint, nextPoint);
				distanceSum += additionalDistanceToNext;
				if (distanceSum >= absDistanceToRelPoint) {
					double thisRelative = ((completeDistance * d) - oldDistanceSum) / additionalDistanceToNext;
					ret = getMidpoint(currentPoint.x, currentPoint.y, nextPoint.x, nextPoint.y, thisRelative);
					break; // or return ret;
				}
			}
		} else {
			int midX = (int) Math.round((startPoint.x + d * (endPoint.x - startPoint.x)));
			int midY = (int) Math.round((startPoint.y + d * (endPoint.y - startPoint.y)));
			ret = new java.awt.Point(midX, midY);
		}
		return ret;
	}
	private static java.awt.Point getMidpoint(int startX, int startY, int endX, int endY, double d) {
		int midX = (int) Math.round((startX + d * (endX - startX)));
		int midY = (int) Math.round((startY + d * (endY - startY)));
		return new java.awt.Point(midX, midY);
	}

	private static double getDistance(java.awt.Point start, java.awt.Point end) {
		int xDist = end.x - start.x;
		int yDist = end.y - start.y;
		double ret = Math.sqrt((xDist * xDist) + (yDist * yDist));
		return ret;
	}

	private static double getDistance(java.awt.Point[] points) {
		double ret = 0;
		for (int i = 0; i < points.length - 1; i++) {
			java.awt.Point currentPoint = points[i];
			java.awt.Point nextPoint = points[i + 1];
			ret += getDistance(currentPoint, nextPoint);
		}
		return ret;
	}
	private static int getRelativeX(GraphicsAlgorithm ga, GraphicsAlgorithm referenceGA) {
		if (referenceGA == null || ga == null) {
			throw new IllegalArgumentException("ga and referenceGa must not be null, and ga must be a child of referenceGA"); //$NON-NLS-1$
		}
		if (ga.equals(referenceGA)) {
			return 0;
		}

		int ret = ga.getX();
		GraphicsAlgorithm parent = ga.getParentGraphicsAlgorithm();
		ret = ret + getRelativeX(parent, referenceGA);
		return ret;
	}

	private static int getRelativeY(GraphicsAlgorithm ga, GraphicsAlgorithm referenceGA) {
		if (referenceGA == null || ga == null) {
			throw new IllegalArgumentException("ga and referenceGa must not be null, and ga must be a child of referenceGA"); //$NON-NLS-1$
		}
		if (ga.equals(referenceGA)) {
			return 0;
		}

		int ret = ga.getY();
		GraphicsAlgorithm parent = ga.getParentGraphicsAlgorithm();
		ret = ret + getRelativeY(parent, referenceGA);
		return ret;
	}

}
