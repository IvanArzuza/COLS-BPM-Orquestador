package com.sap.glx.generator.api;

public interface IDimension {

    int getWidth();

    void setWidth(int width);

    int getHeight();

    void setHeight(int height);
}
