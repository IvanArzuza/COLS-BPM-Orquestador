package com.sap.glx.generator;

public class FlowConstants {
	/*
	 * Constants used for definition and retrieval of pictogram element properties
	 */
	public static final String CONTAINER_EXPANDED = "containerExpanded"; 			//$NON-NLS-1$
	
	public static final String CONTAINER_WIDTH = "containerWidth";					//$NON-NLS-1$
	
	public static final String CONTAINER_HEIGHT = "containerHeight";				//$NON-NLS-1$
	/*
	 * Used to store the width value for expanded EmbeddedSubProcess element 
	 */
	public static final String CONTAINER_EXPANDED_WIDTH = "containerExpanedWidth"; //$NON-NLS-1$
	
	/*
	 * Used to store the height value for expanded EmbeddedSubProcess element 
	 */
	public static final String CONTAINER_EXPANDED_HEIGHT = "containerExpanedHeight"; //$NON-NLS-1$
	
	public static final String CONTAINER_ORIENTATION = "containerOrientation";		//$NON-NLS-1$
	
	public static final String ORIENTATION_VERTICAL = "orientationVertical";		//$NON-NLS-1$
	
	public static final String ORIENTATION_HORIZONTAL = "orientationHorizontal";	//$NON-NLS-1$
	
	public static final String TRUE = "true";										//$NON-NLS-1$
	
	public static final String FALSE = "false";										//$NON-NLS-1$

	public static final String PROP_DATA_FLOW_VISIBLE = "dataFlowVisible";			//$NON-NLS-1$

	public static final String PROP_DATA_OBJECTS_VISIBLE = "dataObjectsVisible";	//$NON-NLS-1$

	public static final String PROP_ANNOTATIONS_VISIBLE = "annotationsFlowVisible"; //$NON-NLS-1$
	
	public static final String CREATE_NEW_POOL = "createNewPool";					//$NON-NLS-1$
	public static final String MAKE_NEW_POOL_ACTIVE = "true";						//$NON-NLS-1$
	public static final String CREATE_START_END_EVENTS = "createStartEndEvent";		//$NON-NLS-1$

}
