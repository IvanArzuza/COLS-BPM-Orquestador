package com.sap.glx.paradigmInterface.brms.compiler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ValidationResult {
	
	Map<String, List<ValidationMessage>> resNameVsMessages = new LinkedHashMap<String, List<ValidationMessage>>();
	
	Map<ValidationMessage.Type, List<ValidationMessage>> typeVsMessages = new LinkedHashMap<ValidationMessage.Type, List<ValidationMessage>>();
	
	public ValidationResult(){
		
	}
	
	public void addValidationMessage(ValidationMessage validationMessage){
		// null check
		if(validationMessage == null){
			throw new IllegalArgumentException("validationMessage can not be null"); //$NON-NLS-1$
		}
		
		String resName = validationMessage.getResourceName(); 
		List<ValidationMessage> validationMessages = resNameVsMessages.get(resName);
		if(validationMessages == null){
			validationMessages = new ArrayList<ValidationMessage>();
			resNameVsMessages.put(resName, validationMessages);
		}
		validationMessages.add(validationMessage);
		
		ValidationMessage.Type type = validationMessage.getType();
		
		List<ValidationMessage> validationMessagesByType = typeVsMessages.get(type);
		if(validationMessagesByType == null){
			validationMessagesByType = new ArrayList<ValidationMessage>();
			typeVsMessages.put(type, validationMessagesByType);
		}
		validationMessagesByType.add(validationMessage);
	}
	
	public Map<String, List<ValidationMessage>> getResNameVsValidationMessages(){
		return Collections.unmodifiableMap(resNameVsMessages);
	}
	
	public Map<ValidationMessage.Type, List<ValidationMessage>> getTypeVsValidationMessages(){
		return Collections.unmodifiableMap(typeVsMessages);
	}
	
}
