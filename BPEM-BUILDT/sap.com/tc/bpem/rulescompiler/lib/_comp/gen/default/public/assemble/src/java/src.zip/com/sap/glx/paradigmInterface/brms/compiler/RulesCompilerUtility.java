package com.sap.glx.paradigmInterface.brms.compiler;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.sap.glx.paradigmInterface.buildapi.RulesCompilationState;

/**
 * 
 * @author I047246
 *
 */
public class RulesCompilerUtility {

	private static final String ACTIVITY_TYPE_DECISIONTABLE = "decision-table";				//$NON-NLS-1$
	private static final String ACTIVITY_TYPE_FLOW = "flow";								//$NON-NLS-1$
	private static final String ACTIVITY_TYPE_RULE = "rule";								//$NON-NLS-1$
	private static final String ACTIVITY_TYPE_TASK = "task";								//$NON-NLS-1$

	private static final String ATTRIBUTE_DECISIONID = "decisionid";
	private static final String ATTRIBUTE_GUID = "guid"; 									//$NON-NLS-1$
	private static final String ATTRIBUTE_NAME = "name";									//$NON-NLS-1$
	private static final String ATTRIBUTE_REFID = "refid";									//$NON-NLS-1$
	private static final String ATTRIBUTE_RSGUID = "rsguid"; 								//$NON-NLS-1$
	private static final String ATTRIBUTE_TYPE = "type"; 									//$NON-NLS-1$
	private static final String ATTRIBUTE_VALUE = "value";									//$NON-NLS-1$
	private static final String ATTRIBUTE_MUTEX_LOWER = "rulelower";						//$NON-NLS-1$
	private static final String ATTRIBUTE_MUTEX_HIGHER = "rulehigher";						//$NON-NLS-1$

	private static final String DOT_RULESET = ".ruleset";									//$NON-NLS-1$

	private static final String ELEMENT_ACTIONRULE = "actionrule";							//$NON-NLS-1$
	private static final String ELEMENT_ACTIVITY = "activity";								//$NON-NLS-1$
	private static final String ELEMENT_APPLYRULE_TA = "applyrule-ta";						//$NON-NLS-1$
	private static final String ELEMENT_CONDITIONAL_TA = "conditional-ta";					//$NON-NLS-1$
	private static final String ELEMENT_DECISION = "decision";								//$NON-NLS-1$
	private static final String ELEMENT_DECISIONTABLE = "decisiontable";					//$NON-NLS-1$
	private static final String ELEMENT_ELSE_BLOCK_TA = "else-block-ta";					//$NON-NLS-1$
	private static final String ELEMENT_ELSEIF_BLOCK_TA = "elseif-block-ta";				//$NON-NLS-1$
	private static final String ELEMENT_ENTITYREFSLIST = "entityrefslist";					//$NON-NLS-1$
	private static final String ELEMENT_ENTITYREF = "entityref";							//$NON-NLS-1$
	private static final String ELEMENT_EVALUATETABLE_TA = "evaluatetable-ta";				//$NON-NLS-1$
	private static final String ELEMENT_FOREACH_TA = "foreach-ta";							//$NON-NLS-1$
	private static final String ELEMENT_GATEWAY = "gateway";								//$NON-NLS-1$
	private static final String ELEMENT_IF_BLOCK_TA = "if-block-ta";						//$NON-NLS-1$
	private static final String ELEMENT_PRECONDITION = "precondition";						//$NON-NLS-1$
	private static final String ELEMENT_REFACTION = "refaction";							//$NON-NLS-1$
	private static final String ELEMENT_REUSEDRESOURCES = "reusedresources"; 				//$NON-NLS-1$
	private static final String ELEMENT_RULEFLOW = "ruleflow";								//$NON-NLS-1$
	private static final String ELEMENT_RULESET = "ruleset";								//$NON-NLS-1$
	private static final String ELEMENT_TASK = "task";										//$NON-NLS-1$
	private static final String ELEMENT_TASKACTION = "taskaction";							//$NON-NLS-1$
	private static final String ELEMENT_NAME = "name";										//$NON-NLS-1$
	private static final String ELEMENT_WHILE_TA = "while-ta";								//$NON-NLS-1$
	private static final String ELEMENT_PROPERTYSET = "propertyset";						//$NON-NLS-1$
	private static final String ELEMENT_PROPERTY = "property";						        //$NON-NLS-1$
	private static final String ELEMENT_MUTEX_RULE = "mutexrule";						    //$NON-NLS-1$

	private static final String TYPE_DECISION = "Decision"; 								//$NON-NLS-1$	
	private static final String TYPE_DECISIONTABLE = "DecisionTable"; 						//$NON-NLS-1$
	private static final String TYPE_RULEFLOW = "RuleFlow";									//$NON-NLS-1$
	private static final String TYPE_RULESCRIPT = "RuleScript";								//$NON-NLS-1$
	private static final String TYPE_RULE = "Rule";											//$NON-NLS-1$

	private static final String PRIO_PROPERTY_NAME = "priority";							//$NON-NLS-1$
	private static final String MUTEX_RULE_NAME_GUID_PREFIX = "guid:";						//$NON-NLS-1$

	private static Map<String,String> rulesetGuidVsNameMap = new HashMap<String, String>();


	public static String getEntityName(String path, boolean retainExtension) {
		if (path == null) {
			throw new IllegalArgumentException("path cannot be null"); //$NON-NLS-1$
		}

		int index1 = path.lastIndexOf(File.separator);
		String fileName = path.substring(index1 + 1, path.length());

		int index2 = fileName.lastIndexOf("."); //$NON-NLS-1$
		if (index2 != -1 && !retainExtension) {
			return fileName.substring(0, index2);
		} else {
			return fileName;
		}
	}

	public static byte[] getBytesOfFile(String path) throws IOException{
		ByteArrayOutputStream out = null;
		try {
			InputStream in = new FileInputStream(path);
			out = new ByteArrayOutputStream();
			byte[] data = new byte[512];
			int size = 0;
			while ((size = in.read(data)) != -1) {
				out.write(data, 0, size);
			}
			out.flush();

			byte[] content = out.toByteArray();

			return content;

		} finally {
			if (out != null) {
				out.close();
			}
		}
	}

	//Rules Reuse feature built-time changes STARTS.

	/*
	 * Need to clear this static map so is called before for every project is
	 * build(compiled).
	 */
	public static void clearRulesetGuidVsNameMap(){
		rulesetGuidVsNameMap.clear();
	}

	/**
	 * This is the main method which is responsible for getting all the
	 * dependent entities being used by a ruleset and copying in the ruleset so
	 * as to make it executable at runtime.
	 * 
	 * 
	 * @param rulesetPath
	 *            - This is the location of the ruleset which has to be
	 *            compiled.
	 * @param compilationState
	 * @return - returns the bytes of the final ruleset document with its
	 *         dependent entities if any.
	 */
	public static byte[] mergeRulesetWithReusedRulesetResources(String rulesetPath,	RulesCompilationState compilationState) {

		if (rulesetGuidVsNameMap.isEmpty()) {
			String projectName = compilationState.getProjectName();
			String projectFilePath = buildArtifactPath(rulesetPath, projectName, RulesConstant.RUNTIME_PROJECT_EXT);
			createRulesetGuidVsNameMap(projectFilePath);
		}

		Document rulesetDocument = getDocumentFromLocation(rulesetPath);
		Map<String,String> reusableRuleGuidVsPriorityMap = new HashMap<String, String>();
		List<Node> reusedEnityNodeList = getReusedEnityNodeList(rulesetPath, rulesetDocument, reusableRuleGuidVsPriorityMap);
		List<Node> finalEntityNodeList = new ArrayList<Node>(reusedEnityNodeList);
		for (Node reusedEnityNode : reusedEnityNodeList) {
			List<Node> dependentEntitiesList = new ArrayList<Node>();
			populateDependentNodesListForThisNode(reusedEnityNode, rulesetPath, dependentEntitiesList);
			for (Node dependentNode : dependentEntitiesList) {
				if(!isExists(finalEntityNodeList, dependentNode) && !isOfSameRuleset(rulesetDocument, dependentNode)){
					finalEntityNodeList.add(dependentNode);
				}
			}
		}
		Node newReusedEntityNode = null;
		Node rootNode = null;
		for (Node reusedEnityNode : finalEntityNodeList) {
			newReusedEntityNode = reusedEnityNode.cloneNode(true);
			renameEntityName(newReusedEntityNode, reusedEnityNode.getParentNode());
			newReusedEntityNode = rulesetDocument.importNode(newReusedEntityNode, true);
			handleSetPriorityToReusableRule(newReusedEntityNode, reusableRuleGuidVsPriorityMap);
			rootNode = rulesetDocument.getDocumentElement();
			rootNode.appendChild(newReusedEntityNode);
		}

		if(rootNode != null){
			changeMutexRuleElement(rootNode);
		}

		byte[] rulesetExeBytes = convertDocumentToByte(rulesetDocument);
		return rulesetExeBytes;
	}

	private static void handleSetPriorityToReusableRule(Node reusedEntityNode, Map<String,String> reusableRuleGuidVsPriorityMap){
		String reusedEntityGUID = getAttributeNodeValueFromElementNode(reusedEntityNode, ATTRIBUTE_GUID);
		if(reusableRuleGuidVsPriorityMap.containsKey(reusedEntityGUID)){
			String priority = reusableRuleGuidVsPriorityMap.get(reusedEntityGUID);
			NamedNodeMap attributes = reusedEntityNode.getAttributes();
			Node attributeNode = attributes.getNamedItem(PRIO_PROPERTY_NAME);
			if(attributeNode != null){
				attributeNode.setNodeValue(priority);
			}
		}
	}

	private static void changeMutexRuleElement(Node rulesetNode){
		Document rulesetDocument = rulesetNode.getOwnerDocument();
		NodeList mutexRuleNodes =rulesetDocument.getElementsByTagName(ELEMENT_MUTEX_RULE);
		NodeList actionRules = null;
		if(mutexRuleNodes != null){
			int noOfMutexRules = mutexRuleNodes.getLength();
			for(int index=0; index < noOfMutexRules; ++index){
				Node mutexRuleNode = mutexRuleNodes.item(index);
				if(actionRules == null){
					actionRules = rulesetDocument.getElementsByTagName(ELEMENT_ACTIONRULE);
				}
				handleMutexRuleNameUpdate(mutexRuleNode, actionRules);
			}
		}
	}

	private static String getRuleNameWithGUID(NodeList ruleNodes, String ruleGUID){
		for(int index=0; index<ruleNodes.getLength(); ++index){
			Node ruleNode = ruleNodes.item(index);
			String guid = getAttributeNodeValueFromElementNode(ruleNode, ATTRIBUTE_GUID);
			if(guid.equals(ruleGUID)){
				return getAttributeNodeValueFromElementNode(ruleNode, ATTRIBUTE_NAME);
			}
		}
		return null;
	}

	private static void handleMutexRuleNameUpdate(Node mutexRuleNode, NodeList actionRules){
		String[] attributeNames = new String[]{ATTRIBUTE_MUTEX_LOWER, ATTRIBUTE_MUTEX_HIGHER};
		for(String attributeName: attributeNames){
			String ruleName = getAttributeNodeValueFromElementNode(mutexRuleNode, attributeName);
			String guidPrefix = MUTEX_RULE_NAME_GUID_PREFIX;
			if(ruleName.startsWith(guidPrefix)){
				ruleName = ruleName.replace(guidPrefix, "");//$NON-NLS-1$
				String lowerRuleName = getRuleNameWithGUID(actionRules, ruleName);
				if(lowerRuleName != null){
					NamedNodeMap attributes = mutexRuleNode.getAttributes();
					Node attributeNode = attributes.getNamedItem(attributeName);
					if(attributeNode != null){
						attributeNode.setNodeValue(lowerRuleName);
					}
				}
			}
		}
	}

	/**
	 * Builds a artifact path from the reference path , artifact name and
	 * artifact extension. In general terms it used to get ruleset path or
	 * project file path using other ruleset path, by passing the required
	 * parameters. As all the project files are present in the same parent
	 * folder (src).
	 * 
	 * @param referenceArtifactPath
	 *            - reference path of any file present in the src folder.
	 * @param artifactName
	 *            - name of the artifact for which the path has to be built
	 *            Ex:RULESET_NAME or PROJECT_NAME.
	 * @param artifactExtension
	 *            - file extension which can be .ruleprj for project file and
	 *            .ruleset for a ruleset.
	 * 
	 * @return
	 */
	private static String buildArtifactPath(String referenceArtifactPath,String artifactName,String artifactExtension){
		File referenceFile = new File(referenceArtifactPath);
		File parentFile= referenceFile.getParentFile();
		File artifactFile = new File(parentFile, artifactName + artifactExtension);
		String artifactPath = artifactFile.getAbsolutePath();
		return artifactPath;
	}

	/**
	 * Populates the <i>rulesetGuidVsNameMap</i> with ruleset guid as key and ruleset name as value using the project file.
	 * 
	 * @param projectFilePath
	 *            - Project file location i.e, .ruleprj location.
	 */
	public static void createRulesetGuidVsNameMap(String projectFilePath) {
		Document projectDocument = getDocumentFromLocation(projectFilePath);
		NodeList rulesetList = projectDocument.getElementsByTagName(ELEMENT_RULESET);
		for (int i = 0; i < rulesetList.getLength(); i++) {
			Node rulesetNode = rulesetList.item(i);
			Node rulesetNameNode = getChildNodesOfElement(rulesetNode,"ruleset-name").get(0); //$NON-NLS-1$
			String rulesetName = rulesetNameNode.getTextContent().trim();
			Node rulesetGuidNode = getChildNodesOfElement(rulesetNode,"ruleset-guid").get(0); //$NON-NLS-1$
			String rulesetGuid = rulesetGuidNode.getTextContent().trim();
			rulesetGuidVsNameMap.put(rulesetGuid, rulesetName);
		}
	}

	/**
	 * Method to build an XML Document of a file in xml format from a given
	 * location
	 * 
	 * @param location
	 *            - location of the file which needs to be converted to XML
	 *            Document.
	 * @return
	 */
	private static Document getDocumentFromLocation(String location) {
		DocumentBuilderFactory docBuiFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder docBuilder = null;
		Document document = null;
		try {
			docBuilder = docBuiFactory.newDocumentBuilder();
			// Modified docBuilder.parse(location) to resolve
			// java.net.MalformedURLException: unknown protocol: c
			// Which occurs if there are any white spaces in the file location
			// which is to be parsed.
			document = docBuilder.parse(new File(location).toURI().toString());
		} catch (ParserConfigurationException e) {
			throw new RuntimeException(e);
		} catch (SAXException e) {
			throw new RuntimeException(e);
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		return document;
	}

	/**
	 * Gets list of child nodes for an element. Will return an empty list if no
	 * such child nodes are present.
	 * 
	 * @param elementNode
	 *            - element node for which the child node has to be get.
	 * @param childNodeName
	 *            - name of the child node
	 * @return
	 */
	private static  List<Node> getChildNodesOfElement(Node elementNode, String childNodeName) {
		NodeList childNodesList = elementNode.getChildNodes();
		List<Node> childNodes = new ArrayList<Node>();
		for (int i = 0; i < childNodesList.getLength(); i++) {
			Node childNode = childNodesList.item(i);
			String nodeName = childNode.getNodeName();
			if (childNodeName.equals(nodeName)) {
				childNodes.add(childNode);
			}
		}
		return childNodes;
	}

	private static List<Node> getReusedEnityNodeList(String targetRulesetPath, Document rulesetDocument, Map<String,String> reusableRuleGuidVsPriorityMap){
		List<Node> allReusedEnityNodes = new ArrayList<Node>();
		List<Node> entityReferencesListNodes = getEntityReferencesLists(rulesetDocument);
		for (Node entityReferenceListNode : entityReferencesListNodes) {
			String rulesetGuid = getAttributeNodeValueFromElementNode(entityReferenceListNode, ATTRIBUTE_RSGUID);
			Document reusableRulesetDocument = getDocumentFromGuid(rulesetGuid, targetRulesetPath);
			List<Node> entityRefNodes = getChildNodesOfElement(entityReferenceListNode, ELEMENT_ENTITYREF);
			for (Node entityRefNode : entityRefNodes) {
				List<Node> propertysetNodes = getChildNodesOfElement(entityRefNode, ELEMENT_PROPERTYSET);
				Node reusedEntityNode = getReusedEnityNodeFromRuleset(reusableRulesetDocument, entityRefNode);

				// populate the map reusableRuleGuidVsPriorityMap
				if(propertysetNodes != null && !propertysetNodes.isEmpty()){
					Node propertysetNode = propertysetNodes.get(0);
					List<Node> propertyNodes = getChildNodesOfElement(propertysetNode, ELEMENT_PROPERTY);
					if(propertyNodes != null && !propertyNodes.isEmpty()){
						for(Node propNode: propertyNodes){
							String propName = getAttributeNodeValueFromElementNode(propNode, ATTRIBUTE_NAME);
							if(PRIO_PROPERTY_NAME.equals(propName)){
								String priorityValue = getAttributeNodeValueFromElementNode(propNode, ATTRIBUTE_VALUE);
								String entityGuid = getAttributeNodeValueFromElementNode(entityRefNode, ATTRIBUTE_GUID);
								reusableRuleGuidVsPriorityMap.put(entityGuid, priorityValue);
								break;
							}
						}
					}
				}

				allReusedEnityNodes.add(reusedEntityNode);
			}
		}
		return allReusedEnityNodes;
	}

	private static List<Node> getEntityReferencesLists(Document rulesetDocument){
		NodeList reusedResourcesList =rulesetDocument.getElementsByTagName(ELEMENT_REUSEDRESOURCES);
		List<Node> entityReferencesListNodes = new ArrayList<Node>();
		if(reusedResourcesList.getLength() > 0){
			//As there will be only one <reusedresources> node in a ruleset. 
			Node reusedResourcesNode = reusedResourcesList.item(0);
			entityReferencesListNodes.addAll(getChildNodesOfElement(reusedResourcesNode, ELEMENT_ENTITYREFSLIST));
		}
		return entityReferencesListNodes;
	}

	private static String getAttributeNodeValueFromElementNode(Node node,String attributeName){
		String nodeValue= null;
		NamedNodeMap attributes = node.getAttributes();
		Node attributeNode = attributes.getNamedItem(attributeName);
		if(attributeNode != null){
			nodeValue = attributeNode.getNodeValue();
		}
		return nodeValue;
	}

	private static Document getDocumentFromGuid(String rulesetGuid, String targetRulesetPath){
		String rulesetName = rulesetGuidVsNameMap.get(rulesetGuid);
		String reusableRulesetLocation = buildArtifactPath(targetRulesetPath, rulesetName, DOT_RULESET);
		Document reusableRulesetDocument = getDocumentFromLocation(reusableRulesetLocation);
		return reusableRulesetDocument;
	} 

	//Getting actual entity nodes from the reusable ruleset. 
	private static Node getReusedEnityNodeFromRuleset(Document reusableRulesetDocument, Node entityRefNode) {
		Node rulesetNode = reusableRulesetDocument.getElementsByTagName(ELEMENT_RULESET).item(0);
		String entityGuid = getAttributeNodeValueFromElementNode(entityRefNode, ATTRIBUTE_GUID);
		String entityType = getAttributeNodeValueFromElementNode(entityRefNode, ATTRIBUTE_TYPE);
		List<Node> entitiesList = getNodeListOfEnitiesByType(rulesetNode, entityType);
		Node reusedEntityNode =  getEntityNodeByGuid(entitiesList, entityGuid);
		return reusedEntityNode;
	}

	private static List<Node> getNodeListOfEnitiesByType(Node rulesetNode, String entityType){
		List<Node> childNodesOfElement = new ArrayList<Node>();
		if(TYPE_DECISIONTABLE.equals(entityType)){
			childNodesOfElement = getChildNodesOfElement(rulesetNode, ELEMENT_DECISIONTABLE);
		}else if(TYPE_RULE.equals(entityType)){
			childNodesOfElement = getChildNodesOfElement(rulesetNode, ELEMENT_ACTIONRULE);
		}else if(TYPE_RULESCRIPT.equals(entityType)){
			childNodesOfElement = getChildNodesOfElement(rulesetNode, ELEMENT_TASK);
		}else if(TYPE_RULEFLOW.equals(entityType)){
			childNodesOfElement = getChildNodesOfElement(rulesetNode, ELEMENT_RULEFLOW);
		}else if(TYPE_DECISION.equals(entityType)){
			childNodesOfElement = getChildNodesOfElement(rulesetNode, ELEMENT_DECISION);
		}
		return childNodesOfElement;
	}

	private static Node getEntityNodeByGuid(List<Node> entitiesList, String guid){
		for (Node entity : entitiesList) {
			String enityGuid  = getAttributeNodeValueFromElementNode(entity, ATTRIBUTE_GUID);
			if(guid.equals(enityGuid)){
				return entity;
			}
		}
		return null;
	} 

	private static boolean isExists(List<Node> nodeList, Node nodeToCheck){
		for (Node node : nodeList) {
			String nodeGuid = getAttributeNodeValueFromElementNode(node, ATTRIBUTE_GUID);
			String nodeToCheckGuid = getAttributeNodeValueFromElementNode(nodeToCheck, ATTRIBUTE_GUID);
			if(nodeGuid.equals(nodeToCheckGuid)){
				return true;
			}
		}
		return false;
	}

	private static boolean isOfSameRuleset(Document rulesetDocument, Node dependentNode){
		List<Node> nodesListOfRulesetEntities = null;
		String dependentNodeType = dependentNode.getNodeName();
		Node rulesetNode = rulesetDocument.getElementsByTagName(ELEMENT_RULESET).item(0);
		if(ELEMENT_ACTIONRULE.equals(dependentNodeType)){
			nodesListOfRulesetEntities = getNodeListOfEnitiesByType(rulesetNode, TYPE_RULE);
		}else if(ELEMENT_DECISIONTABLE.equals(dependentNodeType)){
			nodesListOfRulesetEntities = getNodeListOfEnitiesByType(rulesetNode, TYPE_DECISIONTABLE);
		}else if(ELEMENT_RULEFLOW.equals(dependentNodeType)){
			nodesListOfRulesetEntities = getNodeListOfEnitiesByType(rulesetNode, TYPE_RULEFLOW);
		}else if(ELEMENT_TASK.equals(dependentNodeType)){
			nodesListOfRulesetEntities = getNodeListOfEnitiesByType(rulesetNode, TYPE_RULESCRIPT);
		}else if(ELEMENT_DECISION.equals(dependentNodeType)){
			nodesListOfRulesetEntities = getNodeListOfEnitiesByType(rulesetNode, TYPE_DECISION);
		}
		return isExists(nodesListOfRulesetEntities, dependentNode);
	}

	private static byte[] convertDocumentToByte(Document document) {
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer = null;
		try {
			transformer = transformerFactory.newTransformer();
		} catch (TransformerConfigurationException e) {
			throw new RuntimeException(e);
		}
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");//$NON-NLS-1$

		StringWriter writer = new StringWriter();
		StreamResult result = new StreamResult(writer);
		DOMSource source = new DOMSource(document);
		try {
			transformer.transform(source, result);
		} catch (TransformerException e) {
			throw new RuntimeException(e);
		}
		String string = writer.toString();
		return RulesMergeUtility.getBytes(string);
		
	}

	/*
	  * As the entity(Ex: DT or Rule) name of reusable ruleset used in a
	  * ruleset can be similar to that of entity names of this ruleset, The
	  * entity name should be RULESET_NAME/ENTITY_NAME.
	  * 
	  * @param node, is the node which is to be renamed.
	  * @param parentNode, is the Parent ruleset node of the node.
	  */
	 private static void renameEntityName(Node node, Node parentNode){
		 String rulesetName = getAttributeNodeValueFromElementNode(parentNode, ATTRIBUTE_NAME);
		// Rename of this RuleFlow entity is different as from other entities
		// because "ruleflow" does not contain the attribute "name", instead it
		// contains an element "name" which has an attribute "value".This
		// attribute "value" holds name of the ruleflow. 
		 if(ELEMENT_RULEFLOW.equals(node.getNodeName()) || ELEMENT_TASK.equals(node.getNodeName()) || ELEMENT_DECISION.equals(node.getNodeName())){
			 //Getting the <name> element of <ruleflow>
			 Node nameNode = getChildNodesOfElement(node, ELEMENT_NAME).get(0);									
			 String nodeName = getAttributeNodeValueFromElementNode(nameNode, ATTRIBUTE_VALUE);							
			 String newNodeName = rulesetName + "/" + nodeName;													//$NON-NLS-1$
			 changeAttributeValueForNode(nameNode, ATTRIBUTE_VALUE, newNodeName);
		 }
		 else{
			 String nodeName = getAttributeNodeValueFromElementNode(node, ATTRIBUTE_NAME);
			 String newNodeName = rulesetName + "/" + nodeName;//$NON-NLS-1$
			 // Set the new entity name now.
			 changeAttributeValueForNode(node, ATTRIBUTE_NAME, newNodeName);
		 }
	 }

	private static Node changeAttributeValueForNode(Node node,String attributeName,String newValue){
		NamedNodeMap attributes = node.getAttributes();
		Node attributeNode = attributes.getNamedItem(attributeName);
		attributeNode.setTextContent(newValue);
		return node;
	} 

	//This only for action rule node as decision-table node cannot have any other dependencies.
	private static void populateDependentNodesListForThisNode(Node node,String targetRulesetLocation, List<Node> dependentEntitiesList){
		if(ELEMENT_ACTIONRULE.equals(node.getNodeName())){
			List<Node>  listOfPreconditionNodes = getChildNodesOfElement(node, ELEMENT_PRECONDITION);
			for (Node preconditionNode : listOfPreconditionNodes) {
				String preconditionGuid = getAttributeNodeValueFromElementNode(preconditionNode, ATTRIBUTE_GUID);
				Node preconditionRuleNode = getNodeFromReferenceId(preconditionGuid, node.getParentNode(), targetRulesetLocation, ELEMENT_ACTIONRULE);
				if(!isExists(dependentEntitiesList, preconditionRuleNode))  {
					dependentEntitiesList.add(preconditionRuleNode);
					//This is a recursive operation here
					populateDependentNodesListForThisNode(preconditionRuleNode, targetRulesetLocation,  dependentEntitiesList);
				}
			}
			List<Node> listOfRefActionNodes = getChildNodesOfElement(node, ELEMENT_REFACTION); 
			for (Node refactionNode : listOfRefActionNodes) {
				String refId = getAttributeNodeValueFromElementNode(refactionNode, ATTRIBUTE_REFID);
				//At this point of time it can be only a desiciontable node.
				Node decisionTableNode = getNodeFromReferenceId(refId, node.getParentNode(), targetRulesetLocation, ELEMENT_DECISIONTABLE);
				if(!isExists(dependentEntitiesList, decisionTableNode))  {
					dependentEntitiesList.add(decisionTableNode);
				}

			}
		}
		else if(ELEMENT_RULEFLOW.equals(node.getNodeName())){
			List<Node>  activityNodeList = getChildNodesOfElement(node, ELEMENT_ACTIVITY);
			List<Node>  gatewayNodeList = getChildNodesOfElement(node, ELEMENT_GATEWAY);
			for (Node activityNode : activityNodeList) {
				Node entityRefNode = getChildNodesOfElement(activityNode, ELEMENT_ENTITYREF).get(0);
				String entityGuid = getAttributeNodeValueFromElementNode(entityRefNode, ATTRIBUTE_GUID);
				String entityType = getAttributeNodeValueFromElementNode(entityRefNode, ATTRIBUTE_TYPE);
				Node dependentNode = null;
				if(ACTIVITY_TYPE_DECISIONTABLE.equals(entityType)){
					dependentNode = getNodeFromReferenceId(entityGuid, node.getParentNode(), targetRulesetLocation, ELEMENT_DECISIONTABLE);
				}
				else if(ACTIVITY_TYPE_FLOW.equals(entityType)){
					dependentNode = getNodeFromReferenceId(entityGuid, node.getParentNode(), targetRulesetLocation, ELEMENT_RULEFLOW);
				}
				else if(ACTIVITY_TYPE_RULE.equals(entityType)){
					dependentNode = getNodeFromReferenceId(entityGuid, node.getParentNode(), targetRulesetLocation, ELEMENT_ACTIONRULE);
				}
				else if(ACTIVITY_TYPE_TASK.equals(entityType)){
					dependentNode = getNodeFromReferenceId(entityGuid, node.getParentNode(), targetRulesetLocation, ELEMENT_TASK);
				}else{
					continue;
				}
				if(!isExists(dependentEntitiesList, dependentNode))  {
					dependentEntitiesList.add(dependentNode);
					//This is a recursive operation here
					populateDependentNodesListForThisNode(dependentNode, targetRulesetLocation,  dependentEntitiesList);
				}
			}
			//Added to support Gateways, as gateways can contain Actions like Execute Rule and Execute Decision Table.
			for(Node gatewayNode : gatewayNodeList){
				String decisionId = getAttributeNodeValueFromElementNode(gatewayNode, ATTRIBUTE_DECISIONID);
				Node dependentNode = getNodeFromReferenceId(decisionId, node.getParentNode(), targetRulesetLocation, ELEMENT_DECISION);
				if(!isExists(dependentEntitiesList, dependentNode))  {
					dependentEntitiesList.add(dependentNode);
					//This is a recursive operation here
					populateDependentNodesListForThisNode(dependentNode, targetRulesetLocation,  dependentEntitiesList);
				}
			}
		}
		// The element structure for Task and Decision are similar, hence using
		// the same logic even in case of decision element to populate the
		// enities being used in decision like applyrule-ta and
		// evaluatetable-ta.
		else if(ELEMENT_TASK.equals(node.getNodeName()) || ELEMENT_DECISION.equals(node.getNodeName())){
			List<Node> allTaskActionNodes = new ArrayList<Node>();
			//This list would contain <taskaction> elements only with child elements <applyrule-ta> or <evaluatetable-ta> if any. 
			populateAllTaskActionNodes(node, allTaskActionNodes);

			for (Node taskActionNode : allTaskActionNodes) {
				//For Apply Rule Task Action.
				//getting the child element <applyrule-ta> of <taskaction> element.
				List<Node> applyRuleTANodes = getChildNodesOfElement(taskActionNode, ELEMENT_APPLYRULE_TA);
				//If is empty that means <taskaction> does not contain <applyrule-ta> element. 
				if(!applyRuleTANodes.isEmpty()){
					Node applyRuleTANode = applyRuleTANodes.get(0);
					Node entityRefNode = getChildNodesOfElement(applyRuleTANode, ELEMENT_ENTITYREF).get(0);
					String actionRuleGuid = getAttributeNodeValueFromElementNode(entityRefNode, ATTRIBUTE_GUID);
					Node actionRuleNode = getNodeFromReferenceId(actionRuleGuid, node.getParentNode(), targetRulesetLocation, ELEMENT_ACTIONRULE);
					if(!isExists(dependentEntitiesList, actionRuleNode))  {
						dependentEntitiesList.add(actionRuleNode);
						//This is a recursive operation here
						populateDependentNodesListForThisNode(actionRuleNode, targetRulesetLocation,  dependentEntitiesList);
					}
				}

				//For Evaluate Table Task Action.
				//getting the child element <evaluatetable-ta> of <taskaction> element.
				List<Node> evaluateTableTANodes = getChildNodesOfElement(taskActionNode, ELEMENT_EVALUATETABLE_TA);
				//If is empty that means <taskaction> does not contain <evaluatetable-ta> element. 
				if(!evaluateTableTANodes.isEmpty()){
					Node evaluateTableTANode = evaluateTableTANodes.get(0);
					Node entityRefNode = getChildNodesOfElement(evaluateTableTANode, ELEMENT_ENTITYREF).get(0);
					String decisionTableGuid = getAttributeNodeValueFromElementNode(entityRefNode, ATTRIBUTE_GUID);
					Node decisionTableNode = getNodeFromReferenceId(decisionTableGuid, node.getParentNode(), targetRulesetLocation, ELEMENT_DECISIONTABLE);
					if(!isExists(dependentEntitiesList, decisionTableNode))  {
						//Recursive operation is not needed in case of decision table.
						dependentEntitiesList.add(decisionTableNode);
					}
				}
			}
		}
	}

	private static void populateAllTaskActionNodes(Node parentNode, List<Node> allTaskActionNodes){
		List<Node> taskActionNodes = getChildNodesOfElement(parentNode, ELEMENT_TASKACTION);
		for (Node taskActionNode : taskActionNodes) {
			List<Node> applyRuleTANodes = getChildNodesOfElement(taskActionNode, ELEMENT_APPLYRULE_TA);
			List<Node> evaluateTableTANodes = getChildNodesOfElement(taskActionNode, ELEMENT_EVALUATETABLE_TA);
			//Add <taskaction> Node only if it contains <applyrule-ta> or <evaluatetable-ta>.
			if (!applyRuleTANodes.isEmpty() || !evaluateTableTANodes.isEmpty()) {
				allTaskActionNodes.add(taskActionNode);
				// Because <taskaction> element will contain only one of these elements, hence continue after we get one of the element. 
				continue;
			}

			//<taskaction> element can contain <foreach-ta> element.
			List<Node> foreachTANodes = getChildNodesOfElement(taskActionNode, ELEMENT_FOREACH_TA);
			for (Node foreachTANode : foreachTANodes) {
				//recursive operation as <foreach-ta> can also contain <taskaction>.
				populateAllTaskActionNodes(foreachTANode, allTaskActionNodes);
			}


			//<taskaction> element can contain <while-ta> element.
			List<Node> whileTANodes = getChildNodesOfElement(taskActionNode, ELEMENT_WHILE_TA);
			for (Node whileTANode : whileTANodes) {
				//recursive operation as <while-ta> can also contain <taskaction>.
				populateAllTaskActionNodes(whileTANode, allTaskActionNodes);
			}


			//<taskaction> element can contain <conditional-ta> element.
			List<Node> conditionalTANodes = getChildNodesOfElement(taskActionNode, ELEMENT_CONDITIONAL_TA);
			for (Node conditionalTANode : conditionalTANodes) {

				//<conditional-ta> element can contain <if-block-ta> element.
				List<Node> ifBlockTANodes = getChildNodesOfElement(conditionalTANode, ELEMENT_IF_BLOCK_TA);
				for (Node ifBlockTANode : ifBlockTANodes) {
					//recursive operation as <while-ta> can also contain <taskaction>.
					populateAllTaskActionNodes(ifBlockTANode, allTaskActionNodes);
					// Not performing contiune because <conditional-ta> can
					// contain <if-block-ta>, <else-block-ta> and
					// <elseif-block-ta> under single <conditional-ta> node.
				}
				//<conditional-ta> element can contain <else-block-ta> element.
				List<Node> elseBlockTANodes = getChildNodesOfElement(conditionalTANode, ELEMENT_ELSE_BLOCK_TA);
				for (Node elseBlockTANode : elseBlockTANodes) {
					//recursive operation as <else-block-ta> can also contain <taskaction>.
					populateAllTaskActionNodes(elseBlockTANode, allTaskActionNodes);
				}
				//<conditional-ta> element can contain <elseif-block-ta> element.
				List<Node> elseifBlockTANodes = getChildNodesOfElement(conditionalTANode, ELEMENT_ELSEIF_BLOCK_TA);
				for (Node elseifBlockTANode : elseifBlockTANodes) {
					//recursive operation as <elseif-block-ta> can also contain <taskaction>.
					populateAllTaskActionNodes(elseifBlockTANode, allTaskActionNodes);
				}
			}
		}
	}

	private static Node getNodeFromReferenceId(String guid, Node rulesetNode, String targetRulesetLocation, String type) {
		Node entityNode = null;
		List<Node> entityNodes = getChildNodesOfElement(rulesetNode, type);
		entityNode = getEntityNodeByGuid(entityNodes, guid);
		//if true that means the entity it belongs to a reusable ruleset is not null then belongs to the same ruleset .
		if (entityNode == null) {
			List<Node> entityReferencesListNodes = getEntityReferencesLists(rulesetNode.getOwnerDocument());
			for (Node entityReferenceListNode : entityReferencesListNodes) {
				List<Node> entityRefNodes = getChildNodesOfElement(entityReferenceListNode, ELEMENT_ENTITYREF);
				Node entityRefNode = getEntityNodeByGuid(entityRefNodes, guid);
				if(entityRefNode!=null){
					String rulesetGuid = getAttributeNodeValueFromElementNode(entityReferenceListNode, ATTRIBUTE_RSGUID);
					entityNode = getEntityNodeFromReusableRuleset(targetRulesetLocation, entityRefNode, rulesetGuid);
					break;
				}
			}
		}
		return entityNode;
	}
	private static Node getEntityNodeFromReusableRuleset(String targetRulesetPath, Node entityRefNode, String reusableRulesetGuid) {
		Node node = null;
		Document reusableRulesetDocument =  getDocumentFromGuid(reusableRulesetGuid, targetRulesetPath);
		node = getReusedEnityNodeFromRuleset(reusableRulesetDocument, entityRefNode);
		return node;
	}

	////Rules Reuse feature built-time changes ENDS.
}
