package com.sap.glx.paradigmInterface.bpmn.compiler;

import java.util.ArrayList;
import java.util.Collection;

import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ISeedProvider;
import com.sap.glx.paradigmInterface.buildapi.TaskArtifact;
import com.sap.glx.paradigmInterface.util.ToolUtils;

public class TaskSeedProvider implements ISeedProvider<Task,TaskArtifact> {

    public Iterable<TaskArtifact> getSeed(IBuilderHost2 host) {
        ArrayList<TaskArtifact> ret = new ArrayList<TaskArtifact>();
        
        Collection<Task> resultSet = ToolUtils.getInstance().queryByType(host.getConnection(), 
                Task.class, new String[] { "Galaxy", "Task", "Task" }, true, host.getLocalDCIdentifier()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        for (Task task : resultSet) {
            TaskArtifact item = new TaskArtifact(task, host);
            ret.add(item);
        }
        return ret;
    }
}
