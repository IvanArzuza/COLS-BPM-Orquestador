package com.sap.glx.paradigmInterface.bpmn.compiler;

import java.util.ArrayList;
import java.util.Collection;

import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.paradigmInterface.buildapi.CollaborationArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ISeedProvider;
import com.sap.glx.paradigmInterface.util.ToolUtils;

public class CollaborationSeedProvider implements ISeedProvider<Collaboration,CollaborationArtifact> {

    public Iterable<CollaborationArtifact> getSeed(IBuilderHost2 host) {
        ArrayList<CollaborationArtifact> ret = new ArrayList<CollaborationArtifact>();
        
        Collection<Collaboration> resultSet = ToolUtils.getInstance().queryByType(host.getConnection(), 
                Collaboration.class, new String[] { "Galaxy", "Workflow", "Collaboration" }, true, host.getLocalDCIdentifier());   //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
        for (Collaboration collab : resultSet) {
            CollaborationArtifact item = new CollaborationArtifact(collab, host);
            ret.add(item);
        }
        return ret;
    }
}
