package com.sap.glx.paradigmInterface.bpmn.compiler.stage;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.LocalSource;
import com.sap.glx.ide.model.triggernet.Switch;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerState;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.BooleanLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Script;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;

/**
 * Generates the scenario library. The token and instance relevant stuff should be moved into a separate rule for a pool or inner task flow.
 * This rule then have to be the first in the compilation order.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * 
 */
public class GenerateScenarioLibraryStage implements CompilerStage {

    /*
     * @see
     * com.sap.glx.paradigmInterface.bpmn.compiler.stage.CompilerStage#execute(com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    public void execute(CompilerContext ctx) throws BPMNCompilerException {
        CompilerState state = ctx.getState();

        // suspend/resume support: instance.suspended=false
        ConstantFilter suspendedFilter = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(), "suspended", "0/1/3",
                "BOOLEAN:false", "==");
        NodeFactory.connectNodes(state.getTokenInstanceJoin(), 0, suspendedFilter, 0);

        // generate token switch and token switch without suspended filter
        int numberOfTokenLabels = state.getNumberOfTokenLabels();
        Switch tokenSwitch = ctx.getSwitchFactory().generateSwitch(ctx.getRootScope(), "token_state", "0/0/1");
        Switch tokenSwitchWithoutSuspend = ctx.getSwitchFactory().generateSwitch(ctx.getRootScope(), "token_state_wo_suspend", "0/0/1");
        for (int output = 0; output < numberOfTokenLabels; output++) {
            ctx.getSwitchFactory().addCase(tokenSwitch, "INTEGER:" + output);
            ctx.getSwitchFactory().addCase(tokenSwitchWithoutSuspend, "INTEGER:" + output);
        }
        state.setTokenSwitch(tokenSwitch);
        state.setTokenSwitchWithoutSuspend(tokenSwitchWithoutSuspend);

        NodeFactory.connectNodes(suspendedFilter, 0, tokenSwitch, 0);
        NodeFactory.connectNodes(state.getTokenInstanceJoin(), 0, tokenSwitchWithoutSuspend, 0);
        
        generateTaskClass(ctx);
        generateSubscriptionEventClasses(ctx);

        state.setBPMNRequest(ctx.getSourceFactory().generateSource(CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_REQUEST));
        state.setUCRequest(ctx.getSourceFactory().generateSource(CompilerConstants.ADAPTER_UC, CompilerConstants.GALAXY_REQUEST));
    }

    /**
     * Optionally (=if in a task flow) generates a task class and adds the respective configuration. Also creates a cleanup network to
     * remove the task once the instance has died.
     * 
     * @param ctx
     * @throws BPMNCompilerException
     */
    private void generateTaskClass(CompilerContext ctx) throws BPMNCompilerException {
        // create task class plus configuration if this is a task flow
        if (ctx.isTaskFlow()) {
            GalaxyClass clsTask = ctx.getReplicator().generateTaskClass((Task) ctx.getRootScope(),
                    ctx.getState().getInstanceSource().getGalaxyClass());
            ctx.getConfigFactory().generateTaskConfiguration(clsTask, (Task) ctx.getRootScope(),
                    (MessageEventDefinition) ctx.getState().getStartEvent().getTrigger());
            LocalSource srcTask = ctx.getSourceFactory().getSource4Class(clsTask);
            ctx.getState().setTaskSource(srcTask);

            // delete the task if the instance has gone

            // Instance=Task.owner
            Join instance_task_join = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "task_cleanup", "0/0/-1", "1/0/0");
            NodeFactory.connectNodes(ctx.getState().getInstanceSource(), 0, instance_task_join, 0);
            NodeFactory.connectNodes(ctx.getState().getTaskSource(), 0, instance_task_join, 1);
            NodeFactory.connectNodes(instance_task_join, 2, ctx.getReplicator().getDrain(), 0);
            ctx.getState().setInstanceTaskJoin(instance_task_join);

            // suspend/resume task if process is suspended/resumed
            ConstantFilter suspension_filter = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(), "suspension_filter");
            ctx.getConstantFilterFactory().addFilterTerm(suspension_filter, "0/0/3", "BOOLEAN:true", "==");
            NodeFactory.connectNodes(instance_task_join, 0, suspension_filter, 0);

            GenericOperator suspend_task_target = generateTaskSuspensionExecution(ctx);
            GenericOperator resume_task_target = createTaskResumeExecution(ctx);

            NodeFactory.connectNodes(suspension_filter, 0, suspend_task_target, 0);
            NodeFactory.connectNodes(suspension_filter, 1, resume_task_target, 0);

            // trigger the principal propagation in case the task is completed
            ConstantFilter taskCompletionFilter = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(), "task_completion",
                    "0/0/1", "INTEGER:" + CompilerConstants.CONSTANT_TASK_FINISHED, "==");
            GenericOperator propagatePrincipalTarget = generatePrincipalPropagationTransition(ctx, clsTask);
            NodeFactory.connectNodes(srcTask, 0, taskCompletionFilter, 0);
            NodeFactory.connectNodes(taskCompletionFilter, 0, propagatePrincipalTarget, 0);
        }
    }

    private GenericOperator createTaskResumeExecution(CompilerContext ctx) {
        Script script = new Script(ctx, ScriptName.RESUME_TASK, null);
        script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        ScriptVariable varTask = script.addParameter(ScriptVariable.TASK, ctx.getState().getTaskSource().getGalaxyClass());
        script.generateUpdateCommand(varTask, "suspended", BooleanLiteral.FALSE);
        return script.getExecution();
    }

    private GenericOperator generateTaskSuspensionExecution(CompilerContext ctx) {
        Script script = new Script(ctx, ScriptName.SUSPEND_TASK, null);
        script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());
        ScriptVariable varTask = script.addParameter(ScriptVariable.TASK, ctx.getState().getTaskSource().getGalaxyClass());
        script.generateUpdateCommand(varTask, "suspended", BooleanLiteral.TRUE);
        return script.getExecution();
    }

    private GenericOperator generatePrincipalPropagationTransition(CompilerContext ctx, GalaxyClass clsTask) throws BPMNCompilerException {
        Script script = new Script(ctx, ScriptName.PROPAGATE_PRINCIPAL_OF_TASK, null);
        ScriptVariable varTask = script.addParameter(ScriptVariable.TASK, clsTask);

        ScriptVariable varInstance = script.generateAssignCommand(ScriptVariable.INSTANCE, varTask, CompilerConstants.ATTRIBUTE_OWNER);
        script.generateInvocationCommand(varInstance, "propagatePrincipalToParent");

        GenericOperator propagatePrincipalTarget = ctx.getExecutionFactory().generateExecution(ctx.getRootScope(),
                ScriptName.PROPAGATE_PRINCIPAL_OF_TASK.toString());
        ctx.getExecutionFactory().setScript(propagatePrincipalTarget, script);
        return propagatePrincipalTarget;
    }

    /**
     * Generate implicitly defined subscription and event classes from {starting, intermediate} message receipts' correlation mappings and
     * outbound mappings (c.f. "Compiler Design" document).
     */
    private void generateSubscriptionEventClasses(CompilerContext ctx) throws BPMNCompilerException {

        /*
         * This part is only for tasks. The creating of subscriptions for intermediate message events in regular flows is part of the
         * CatchEventDispatcherRule and the task stuff will sometime end up there as well.
         */
        // TODO: refactoring of stages is still an open task -ps-
        if (ctx.isTaskFlow()) {
            if (ctx.getArtifacts(IntermediateCatchEvent.class) != null) {
                for (IntermediateCatchEvent event : ctx.getArtifacts(IntermediateCatchEvent.class)) {
                    if (event.getEventDefinition() instanceof MessageEventDefinition) {

                        // each intermediate control object implies exactly one event and subscription class
                        GalaxyClass clsSubscription = ctx.getReplicator().generateSubscriptionClass(event);
                        GalaxyClass clsEvent = ctx.getReplicator().generateEventClass(event);

                        // TODO: find out for what these methods are used.
                        ctx.getClassFactory().addMethod(clsEvent, "getData", ctx.getSimpleTypes().SDO);
                        ctx.getClassFactory().addMethod(clsEvent, "setData", ctx.getSimpleTypes().VOID, ctx.getSimpleTypes().SDO);

                        ctx.getState().control2subscription_event.put(event, new Pair<GalaxyClass, GalaxyClass>(clsSubscription, clsEvent));
                    }
                }
            }
        }
    }
}
