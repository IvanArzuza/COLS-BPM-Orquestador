package com.sap.glx.paradigmInterface.bpmn.compiler.stage;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;

import com.sap.glx.ide.model.galaxy.processsupplements.NotificationActivity;
import com.sap.glx.ide.model.galaxy.processsupplements.ReportingActivity;
import com.sap.glx.ide.model.galaxy.workflow.Activity;
import com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity;
import com.sap.glx.ide.model.galaxy.workflow.BoundaryEvent;
import com.sap.glx.ide.model.galaxy.workflow.ConditionalSequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.ExclusiveDataSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.ExclusiveEventSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.HumanActivity;
import com.sap.glx.ide.model.galaxy.workflow.InclusiveDataSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.Lane;
import com.sap.glx.ide.model.galaxy.workflow.LoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.MappingActivity;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.MessageFlowObject;
import com.sap.glx.ide.model.galaxy.workflow.MultiInstanceLoopCharacteristics;
import com.sap.glx.ide.model.galaxy.workflow.ParallelJoinGateway;
import com.sap.glx.ide.model.galaxy.workflow.ParallelSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.PoolReference;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.ide.model.galaxy.workflow.ThrowEvent;
import com.sap.glx.ide.model.galaxy.workflow.UncontrolledJoinGateway;
import com.sap.glx.ide.model.galaxy.workflow.View;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.tc.esmp.mm.wsdl2.Operation;

/**
 * A compiler stage that collects the relevant artifacts of the root scope, 
 * partitions them and enters them into the compiler context.
 * 
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 * @version $Id: //bpem/bpem.bp/NW750EXT_12_REL/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface/bpmn/compiler/stage/CollectArtifactsStage.java#1 $
 */
public class CollectArtifactsStage implements CompilerStage {

    @SuppressWarnings("unchecked")
    private static final Class<? extends MessageFlowObject>[] ARTIFACT_ORDER = new Class[] {
        View.class, DataObject.class,
        ThrowEvent.class, BoundaryEvent.class, IntermediateCatchEvent.class, StartEvent.class, 
        EmbeddedScope.class, PoolReference.class, HumanActivity.class, AutomatedActivity.class, 
        MappingActivity.class, ReportingActivity.class, NotificationActivity.class, 
        Lane.class, Pool.class, ConditionalSequenceConnector.class, SequenceConnector.class, 
        ExclusiveDataSplitGateway.class, InclusiveDataSplitGateway.class, ExclusiveEventSplitGateway.class,
        ParallelSplitGateway.class, UncontrolledJoinGateway.class, ParallelJoinGateway.class};

	
	public void execute(CompilerContext ctx) throws BPMNCompilerException {

	    // crawl through the the pool and collect artifacts
	    FrameNode rootFrameNode = new FrameNode(ctx.getRootScope(), null);
		crawl(ctx.getRootScope(), ctx, rootFrameNode);
		DonFrame donFrame = new DonFrame(rootFrameNode, ctx);
		ctx.getState().setDonFrame(donFrame);
		
		// basic validation of contained start events (exactly one with message trigger).
		StartEvent startEvent = null;
		for(StartEvent event : ctx.getArtifacts(StartEvent.class)) {
			if (event.getEventDefinition() instanceof MessageEventDefinition) {
                ctx.getValidator().validate(startEvent == null, "BPM.rt_c_bpmn.000063", //$NON-NLS-1$
                        "More than one start events with a message trigger were found.");//$NON-NLS-1$
				startEvent = event;
			}
		}
		ctx.getValidator().validate(startEvent != null, "BPM.rt_c_bpmn.000064", //$NON-NLS-1$
		        "Expected start event with a message trigger in the scope '%s' not found.", ctx.getRootScope().getOriginalName()); //$NON-NLS-1$
		Pair<String, Operation> startEndpoint = OperationHelper.getBPMNEndpoint(ctx, startEvent);

		// check whether start event is shared
        boolean isShared = false;
        if (OperationHelper.isModelledEndpoint(startEvent.getTrigger())) {
            LinkedHashSet<IntermediateCatchEvent> intermediateEvents = ctx.getArtifacts(IntermediateCatchEvent.class);
            if (intermediateEvents != null) {
                for (IntermediateCatchEvent intermediateEvent : intermediateEvents) {
                    if (intermediateEvent.getTrigger() == startEvent.getTrigger()) {
                        isShared = true;
                        break;
                    }
                }
            }
        }

        // create the result of the stage and store it in the compiler state.
        CollectArtifactsResult result = new CollectArtifactsResult(startEvent, isShared);
		ctx.getState().setCollectArtifactsResult(result);
		
		
		// basic validation of contained end events with message triggers (must refer to the same operation as the start event).
		for(ThrowEvent event : ctx.getArtifacts(ThrowEvent.class)) {
			if (event instanceof EndEvent && event.getResult() instanceof MessageEventDefinition) {
			    MessageEventDefinition endEndpoint = (MessageEventDefinition) event.getResult();
			    if (endEndpoint.getOperation() != null) {
			        if (WSDLHelper.isSynchronous(endEndpoint.getOperation()) || WSDLHelper.isSynchronous(startEndpoint.second)) {
    			        if (OperationHelper.isModelledEndpoint(startEvent.getTrigger())) {
    			            ctx.getValidator().validate(startEvent.getTrigger().equals(endEndpoint), "BPM.rt_c_bpmn.000065", //$NON-NLS-1$
                                    "The trigger on the end event '%s' is not the same as on the start event '%s'.", //$NON-NLS-1$
                                    event.getOriginalName(), startEvent.getOriginalName());
    			        } else {
    			            ctx.getValidator().validate(startEndpoint.second.equals(endEndpoint.getOperation()), "BPM.rt_c_bpmn.000066", //$NON-NLS-1$
    	                            "The operation on the end event '%s' is not the same as on the start event '%s'", //$NON-NLS-1$
    	                            event.getOriginalName(), startEvent.getOriginalName());
    	                }
    			        result.addSychronousEndEvent((EndEvent) event);
			        }
			    }
			}
		}
	}
	
    private void crawl(Scope scope, CompilerContext ctx, FrameNode frame){
        for (MessageFlowObject flowObject : getFlowObjects(scope)) {
            Class<? extends MessageFlowObject> clazz = getArtifactClass(flowObject);
            if (clazz != null) {
                LinkedHashSet<MessageFlowObject> classifiedArtifacts = ctx.getArtifacts().get(clazz);
                if (classifiedArtifacts == null) {
                    classifiedArtifacts = new LinkedHashSet<MessageFlowObject>();
                    ctx.getArtifacts().put(clazz, classifiedArtifacts);
                }
                classifiedArtifacts.add(flowObject);
                if (flowObject instanceof EmbeddedScope){
                    EmbeddedScope embeddedScope = (EmbeddedScope)flowObject;
                    FrameNode child;
                    LoopCharacteristics loopCharacteristics = embeddedScope.getLoopCharacteristics();
                    if(loopCharacteristics != null && (loopCharacteristics instanceof MultiInstanceLoopCharacteristics)){
                        //it is a loop, we have to insert a loop Admiral frame as parent
                        FrameNode loopAdmiral = frame.addChild(null);
                        child = loopAdmiral.addChild(embeddedScope);
                        
                    }else{
                        child = frame.addChild(embeddedScope);
                    }
                    this.crawl(embeddedScope, ctx, child);
                }
            }
        }   
    }
	
	/**
	 * Retrieve the metamodel class of the artifact.
	 * 
	 * @param flowObject
	 * 		a BPMN artifact 
	 * @return
	 * 		the artifact class
	 */
	private Class<? extends MessageFlowObject> getArtifactClass(MessageFlowObject flowObject) {
        for (Class<? extends MessageFlowObject> checkClazz : ARTIFACT_ORDER) {
            if (checkClazz.isAssignableFrom(flowObject.getClass())) {
                return checkClazz;
            }
        }
        return null;
    }
	
	
    /**
     * Retrieves all flow objects associated with a scope.
     * 
     * @param scope
     *            the scope to retrieve the flow objects from
     * @return a collection of those flow objects
     */
	private Collection<MessageFlowObject> getFlowObjects(Scope scope) {
        if (scope != null) {
            Collection<MessageFlowObject> flowObjects = new HashSet<MessageFlowObject>();
            for (MessageFlowObject flowObject: scope.getScopeObjects()) {
            	flowObjects.add(flowObject);

                if (flowObject instanceof Activity) {
                    Activity activity = (Activity) flowObject;
                    if (activity.getBoundaryEvents() != null) {
                    	flowObjects.addAll(activity.getBoundaryEvents());
                    }
                }
            }
            return flowObjects;
        } else {
            return new ArrayList<MessageFlowObject>();
        }
    }
   
    public class CollectArtifactsResult {

        private StartEvent startEvent;
        private boolean isSharedStart;
        private List<EndEvent> endEvents;

        private CollectArtifactsResult(StartEvent startEvent, boolean isSharedStart) {
            this.startEvent = startEvent;
            this.isSharedStart = isSharedStart;
            this.endEvents = null;
        }

        private void addSychronousEndEvent(EndEvent endEvent) {
            if (endEvents == null) {
                endEvents = new ArrayList<EndEvent>(2);
            }
            endEvents.add(endEvent);
        }

        public boolean isSharedStart() {
            return isSharedStart;
        }

        public StartEvent getStartEvent() {
            return startEvent;
        }

        public boolean isSynchronouslyProvisioned() {
            if (endEvents != null) {
                return true;
            } else {
                return false;
            }
        }

        public boolean isSynchronousEndEvent(EndEvent endEvent) {
            if (endEvents != null && endEvents.contains(endEvent)) {
                return true;
            } else {
                return false;
            }
        }
    }
}
