package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.Set;

import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.TimerEventDefinition;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * Simple rule to dispatch the compilation of intermediate catch events to further rules.
 * 
 * @see IntermediateControlRule
 * @see TimerControlRule
 * 
 * @author Philipp Sommer
 * 
 */

public class IntermediateCatchEventRule extends BaseCompilerRule<IntermediateCatchEvent> {
    private CatchEventMessageRule<IntermediateCatchEvent> intermediateCatchEventMessageRule = null;
    private TimerControlRule intermediateCatchEventTimerRule = null;

    public Class<IntermediateCatchEvent> getSupportedArtifact() {
        return IntermediateCatchEvent.class;
    }

    @Override
    public void preprocess(CompilerContext ctx) throws BPMNCompilerException {
        boolean containsMessageEvents = false;
        boolean containsTimerEvents = false;

        // find out which type of events exist
        Set<IntermediateCatchEvent> events = ctx.getArtifacts(IntermediateCatchEvent.class);
        for (IntermediateCatchEvent event : events) {
            if (event.getEventDefinition() instanceof MessageEventDefinition) {
                containsMessageEvents = true;
            } else if (event.getEventDefinition() instanceof TimerEventDefinition) {
                containsTimerEvents = true;
            }
        }

        // create rules in case there is an according artifact
        if (containsMessageEvents) {
            // When Sunbeam compiler switch is on, compile Sunbeam processes, otherwise use the old Correlation mechanism
            if ((ctx.useSunbeamNonConditionalStart() || ctx.useSunbeamConditionalStart()) && ctx.isTaskFlow() == false) {
                intermediateCatchEventMessageRule = new IntermediateSunbeamRule();
            } else {
                intermediateCatchEventMessageRule = new IntermediateControlRule();
            }
            intermediateCatchEventMessageRule.preprocess(ctx);
        }
        if (containsTimerEvents) {
            intermediateCatchEventTimerRule = new TimerControlRule();
            intermediateCatchEventTimerRule.preprocess(ctx);
        }
    }

    public void compile(IntermediateCatchEvent event, CompilerContext ctx) throws BPMNCompilerException {
        if (event.getEventDefinition() instanceof MessageEventDefinition)
            intermediateCatchEventMessageRule.compile(event, ctx);
        else if (event.getEventDefinition() instanceof TimerEventDefinition)
            intermediateCatchEventTimerRule.compile(event, ctx);
        else
            throw ctx.getValidator().error("BPM.rt_c_bpmn.000031", "Trigger for intermediate event '%s' is not supported.",
                    event.getOriginalName());
    }

    @Override
    public void postprocess(CompilerContext ctx) throws BPMNCompilerException {
        if (intermediateCatchEventMessageRule != null)
            intermediateCatchEventMessageRule.postprocess(ctx);
        if (intermediateCatchEventTimerRule != null)
            intermediateCatchEventTimerRule.postprocess(ctx);
    }
}