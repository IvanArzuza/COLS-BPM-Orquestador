package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.processsupplements.ReportingActivity;
import com.sap.glx.ide.model.galaxy.processsupplements.ReportingDefinition;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventLogHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * A compiler rule for reporting activity artifacts.
 * 
 * @author Philipp Sommer
 * 
 * @version $Id:
 *          //bpem/bpem.tools/dev/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/rules/AutomatedActivityRule.
 *          java#6 $
 */
public class ReportingActivityRule extends BaseCompilerRule<ReportingActivity> implements CompilerRule<ReportingActivity> {

    private static Pair<String, String> clsReporter = new Pair<String, String>(CompilerConstants.ADAPTER_REPORTING,
            CompilerConstants.GALAXY_REPORTER);

    public Class<ReportingActivity> getSupportedArtifact() {
        return ReportingActivity.class;
    }

    public void compile(ReportingActivity activity, CompilerContext ctx) throws BPMNCompilerException {
        // validation of the activity
        ctx.getValidator().validateConnectors(activity, 1, 1);
        ctx.getValidator().validate(activity.getReportingDefinition() != null, "BPM.rt_c_bpmn.000050", //$NON-NLS-1$
                "Reporting activity '%s' does not have a reporting data source assigned.", activity.getOriginalName()); //$NON-NLS-1$

        // retrieve galaxy class for this scope
        GalaxyClass clsScope = ctx.getDependencyHelper().getScopeClassOld(
                ctx.getDependencyHelper().getScopeOld(activity.getReportingDefinition()));

        // compile the input mapping
        Pair<IMappingCompiler.Summary, String> inputMapping = ctx.getMappingHelper().compile(activity.getInputMapping());
        Set<DataContainer> usedContext = identifySourceDataObjects(ctx, inputMapping.first);

        // handling for depending views
        SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(usedContext);
        usedContext.addAll(allViewDependencies);

        // create transition
        Target target = ctx.getTargetFactory().generateTarget(activity, activity.getOriginalName());
        ctx.getTargetFactory().setScript(target, generateScriptHeader(ctx, activity, usedContext),
                generateScriptBody(ctx, activity, inputMapping.second, usedContext, clsScope));

        if (usedContext.isEmpty()) {
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), ctx.getState().getBeforeTokenSwitchExit(activity), target, 0);
        } else {
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, activity.getScope(), activity, null, usedContext);
            if (ctx.getRootScope().equals(activity.getScope())) {
                // is root scope, projection only contains data objects
                Join contextJoin = ctx.getJoinFactory().generateJoin(activity, "context_join", "0/1/-1", "1/0/0");
                NodeFactory
                        .connectNodes(ctx.getState().getTokenSwitch(), ctx.getState().getBeforeTokenSwitchExit(activity), contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                NodeFactory.connectNodes(contextJoin, 0, target, 0);
            } else {
                // is in embedded scope, projection contains frame object as first element
                // token.frame=frame
                Join contextJoin = ctx.getJoinFactory().generateJoin(activity, "context_join", "0/0/2", "1/0/-1");
                NodeFactory
                        .connectNodes(ctx.getState().getTokenSwitch(), ctx.getState().getBeforeTokenSwitchExit(activity), contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);

                // for the target node the frame has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                // token and instance
                usedIndexes.add(0);
                usedIndexes.add(1);
                // ignore frame
                int runningIndex = 3;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(activity, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(contextJoin, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, target, 0);
            }
        }
    }

    private String generateScriptHeader(CompilerContext ctx, ReportingActivity activity, Set<DataContainer> used_context) {
        return generateSimpleScriptHeader(ctx, CompilerConstants.TARGET_REPORTING_ACTIVITY, activity, used_context);
    }

    private String generateScriptBody(CompilerContext ctx, ReportingActivity activity, String mappingId, Set<DataContainer> usedContext,
            GalaxyClass clsScope) throws BPMNCompilerException {

        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(activity));
        sb.append(ScriptHelper
                .generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        ReportingDefinition definition = activity.getReportingDefinition();
        String reportId = ctx.getHost().getVersionId(definition, CompilerType.REPORTINGDEFINITIONCOMPILER);
        String elementId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(definition), CompilerType.TYPECOMPILER);

        XsdElementDeclaration requestElement = definition.getParameter(); // $JL-SUSPICIOUSFUNCTIONS$
        QName requestType = SDOHelper.generateSDOName(WSDLHelper.getElementType(requestElement)); // $JL-SUSPICIOUSFUNCTIONS$

        // create scope instance
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CALLSCOPE), clsScope, new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        // create reporter instance
        sb.append(ScriptHelper.generateNewCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_REPORTER), clsReporter));

        // request=scope:instantiate(<ns>,<name>);
        sb.append(ScriptHelper.generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_CALLSCOPE), "instantiate", new StringLiteral(requestType.getNamespaceURI()),
                new StringLiteral(requestType.getLocalPart())));

        Triple<XsdElementDeclaration, Variable, StringLiteral> request = new Triple<XsdElementDeclaration, Variable, StringLiteral>(
                requestElement, new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST), new StringLiteral(elementId));

        // generic input mapping script
        sb.append(ScriptHelper.generateMappingCode(ctx, mappingId, usedContext, null, null, request));

        // report the data
        sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_REPORTER), "reportData",
                new StringLiteral(reportId), new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST)));

        // delete the reporter
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_REPORTER)));

        // delete scope
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CALLSCOPE)));

        // token:state=<next>;
        int nextState = ctx.getState().getAfterTokenLabel(activity);
        sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), "state", new IntegerLiteral(
                nextState)));

        // event log of rds persisted
        sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT), CompilerConstants.SCRIPT_VARIABLE_KICKER));
        EventLogHelper.addRDSEvent(sb, ctx.getState().getEventLoggerClass(), ((Pool) ctx.getRootScope()).refMofId(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT), activity.refMofId(), new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER),
                definition.refMofId(), new Variable(CompilerConstants.SCRIPT_VARIABLE_REQUEST));

        sb.append("}");
        return sb.toString();
    }
}
