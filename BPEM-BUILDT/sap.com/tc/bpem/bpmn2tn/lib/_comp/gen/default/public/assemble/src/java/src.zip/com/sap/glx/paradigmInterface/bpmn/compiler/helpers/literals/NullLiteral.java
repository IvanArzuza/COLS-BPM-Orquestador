package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;

import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Parameter;

public class NullLiteral extends AbstractLiteral<Object> implements Parameter{

	public static NullLiteral NULL = new NullLiteral();
	
    private NullLiteral() {
        super(null);
    }
    
    public String toString() {
        return CompilerConstants.SCRIPT_VALUE_NULL;
    }

}
