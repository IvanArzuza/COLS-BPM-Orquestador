package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.mapping.Mapping;
import com.sap.glx.ide.model.galaxy.rule.Expression;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.mapping.base.compiler.ICompilerContext;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.mapping.base.compiler.IMappingCompiler.Summary;
import com.sap.mapping.lib.definition.api.rule.Literal;
import com.sap.mapping.lib.definition.implementation.Transporter;
import com.sap.mapping.lib.definition.implementation.rule.StandardExpression;
import com.sap.mapping.lib.definition.implementation.rule.StandardLiteral;

public class MappingHelper {
    CompilerContext ctx;

    public MappingHelper(CompilerContext ctx) {
        this.ctx = ctx;
    }

    /**
     * Generates mapping XML, adds Transformer configuration for "Mapper".
     * 
     * @param mapping
     *            is the Mapping entity from the flow model.
     * @return a pair of (1) the mapping summary as reported by the mapping compiler and (2) the mapping id (prepared
     *         for versioning in scripts).
     * @throws BPMNCompilerException
     */
    public Pair<IMappingCompiler.Summary, String> compile(Mapping mapping) throws BPMNCompilerException {
        Pair<IMappingCompiler.Summary, String> summary_xml = compileMapping(mapping);

        String mapping_id = mapping.refMofId(); // flow version will be added later
        ctx.getConfigFactory().generateMapperConfiguration(mapping_id, summary_xml.second);

        return new Pair<IMappingCompiler.Summary, String>(summary_xml.first, mapping_id + "_" + CompilerConstants.SCRIPT_VALUE_VERSION);
    }
    
    /**
     * Generates mapping XML, WITHOUT adding Transformer configuration for "Mapper".
     * 
     * @param mapping
     *            is the Mapping entity from the flow model.
     * @return a pair of (1) the mapping summary as reported by the mapping compiler and (2) the mapping id (prepared
     *         for versioning in scripts).
     * @throws BPMNCompilerException
     */
    public Pair<IMappingCompiler.Summary, String> getCompiledMapping(Mapping mapping) throws BPMNCompilerException {
        Pair<IMappingCompiler.Summary, String> summary_xml = compileMapping(mapping);
        String mapping_id = mapping.refMofId(); // flow version will be added later
        return new Pair<IMappingCompiler.Summary, String>(summary_xml.first, mapping_id + "_" + CompilerConstants.SCRIPT_VALUE_VERSION);
    } 
    
	private Pair<Summary, String> compileMapping(final Mapping mapping)
	{
		final com.sap.mapping.base.compiler.helpers.Pair<Summary, String> compilationResult = getCompiler().compile(mapping, new MappingCompilerContext(ctx.getHost()));
		return pairsAdapter().toBpmnPair(compilationResult);
	}

	private IMappingCompiler getCompiler()
	{
		return this.ctx.getMappingCompiler();
	}
	
	/**
     * Generates expression XML, adds Transformer configuration for "Extractor".
     * 
     * @param expression
     *            is the Expression entity from the flow model.
     * @return a pair of (1) the mapping summary as reported by the mapping compiler and (2) the expression id (prepared
     *         for versioning in scripts).
     * @throws BPMNCompilerException
     */
    public Pair<IMappingCompiler.Summary, String> compile(Expression expression) throws BPMNCompilerException {
        Pair<IMappingCompiler.Summary, String> summary_xml = compileExpression(expression);

        String expression_id = expression.refMofId();
        ctx.getConfigFactory().generateExtractorConfiguration(expression_id, summary_xml.second);

        return new Pair<IMappingCompiler.Summary, String>(summary_xml.first, expression_id + "_" + CompilerConstants.SCRIPT_VALUE_VERSION);
    }
    
	private Pair<Summary, String> compileExpression(final Expression expression)
	{
		final com.sap.mapping.base.compiler.helpers.Pair<Summary, String> compilationResult = getCompiler().compile(expression, new MappingCompilerContext(ctx.getHost()));
		return pairsAdapter().toBpmnPair(compilationResult);
	}

	/**
     * Generates expression XML; adds Transformation configuration for "Generator"
     * 
     * @param bpmnService
     *            versioned service identifier for the BPMN adapter
     * @param ucService
     *            versioned service identifier for the UC adapter
     * @param operation
     *            operation of the request
     * @param cls
     *            is the GalaxyClass to be instantiated.
     * @param attribute
     *            is an attribute of that class.
     * @param expression
     *            is the expression determining the value of that attribute.
     * @throws BPMNCompilerException
     */
    public void generate(String bpmnService, String ucService, String operation, GalaxyClass cls, Attribute attribute, Expression expression)
            throws BPMNCompilerException {
    	String compiledExpression = compileExpression(expression).second;
    	ctx.getConfigFactory().generateGeneratorConfiguration(bpmnService, ucService, operation, cls, attribute, compiledExpression);
    }

    /**
     * Generates expression XML for a null value; adds Transformation configuration for "Generator"
     * 
     * @param bpmnService
     *            versioned service identifier for the BPMN adapter
     * @param ucService
     *            versioned service identifier for the UC adapter
     * @param operation
     *            operation of the request
     * @param cls
     *            is the GalaxyClass to be instantiated.
     * @param attribute
     *            is an attribute of that class.
     * @throws BPMNCompilerException
     */
    public void generate(String bpmnService, String ucService, String operation, GalaxyClass cls, Attribute attribute)
            throws BPMNCompilerException {
		StandardExpression nullExpression = new StandardExpression();
		StandardLiteral nullLiteral = new StandardLiteral();
		nullLiteral.setType(Literal.Type.STRING);
		nullLiteral.setPayload(null);
		nullExpression.getStepList().add(nullLiteral);
		String compiledExpression = new Transporter().packExpression(nullExpression);
    	ctx.getConfigFactory().generateGeneratorConfiguration(bpmnService, ucService, operation, cls, attribute, compiledExpression);
    }
    
    private PairsAdapter<IMappingCompiler.Summary, String> pairsAdapter()
    {
    	return new PairsAdapter<IMappingCompiler.Summary, String>();
    }
    
    private class MappingCompilerContext implements ICompilerContext
    {
    	private final IBuilderHost host;

		public MappingCompilerContext(final IBuilderHost host)
    	{
    		this.host = host;
    	}
		
		@Override
		public String getRulesBuildId()
		{
			return host.getRulesBuildId();
		}

		@Override
		public String getVersionId(Object arg0)
		{
			return host.getVersionId(arg0, CompilerType.TYPECOMPILER);
		}
    }    
}
