package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.triggernet.Join;

/**
 * <p>
 * An intermediate message event context contains various information related to an intermediate message event.
 * </p>
 * 
 * <p>
 * <ul>
 * <li>Intermediate Message Event</li>
 * <li>(Triggernet) Join Node <code>&lt;&lt;Token, Instance&gt;, &lt;Subscription, CorrelationTrigger&gt;&gt;</code> with
 * <code>subscription.parent = instance</code></li>
 * </ul>
 * </p>
 */
public class IntermediateMessageEventContext {

    private final IntermediateCatchEvent event;
    private Join subscriptionInstanceJoin;

    public IntermediateMessageEventContext(final IntermediateCatchEvent event) {
        if (event == null) {
            throw new NullPointerException("Event must not be null.");
        }
        this.event = event;
    }

    public IntermediateCatchEvent getIntermediateMessageEvent() {
        return event;
    }

    public void setSubscriptionInstanceJoin(final Join subscriptionInstanceJoin) {
        this.subscriptionInstanceJoin = subscriptionInstanceJoin;
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public Join getSubscriptionInstanceJoin() {
        if (subscriptionInstanceJoin == null) {
            throw new IllegalStateException("SubscriptionInstanceJoin is unset.");
        }
        return subscriptionInstanceJoin;
    }
}
