package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class ModificationsComparatorFactory extends NodeFactory {

    private static final String JAVA_CLASS = "com.sap.glx.core.kernel.trigger.node.ModificationsComparatorNode"; //$NON-NLS-1$

    public ModificationsComparatorFactory(ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
    }

    @Override
    protected String getNodePrefix() {
        return "MODIFICATIONS_COMPARATOR"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 2;
    }

    public GenericOperator generateModificationsComparator(ModelElement artifact, String name, String leftAttributes, String rightAttributes) {
        GenericOperator generic = createElement(GenericOperator.class);
        prepareNode(generic, artifact, name);
        generic.getParameters().add(leftAttributes);
        generic.getParameters().add(rightAttributes);
        generic.setImplementationClass(JAVA_CLASS);
        return generic;
    }
}
