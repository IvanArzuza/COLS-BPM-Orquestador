package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

public abstract class AbstractVersioningCallback<T> implements VersioningCallback {
	protected CompilerContext ctx;
	protected T anchor;
	
	public AbstractVersioningCallback(CompilerContext ctx, T anchor) {
		this.anchor = anchor;
		this.ctx = ctx;
	}
}
