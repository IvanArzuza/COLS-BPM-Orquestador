package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import com.sap.glx.constants.SharedCompilerConstants;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.configuration.ConfigurationString;
import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeReference;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.triggernet.assembler.AssemblerException;
import com.sap.glx.paradigmInterface.triggernet.assembler.GalaxyAssembler;
import com.sap.tc.moin.util.properties.Property;

public class VersioningHelper {
    
    public final static String CONFIG_OFFER = "OFFER"; //$NON-NLS-1$
    public final static String CONFIG_REQUIRE = "REQUIRE"; //$NON-NLS-1$
    private static final String SEMANTIC_VERSION_OFFER = "SEMANTIC_VERSION_OFFER"; //$NON-NLS-1$
    private static final String SEMANTIC_VERSION_INTERESTED = "SEMANTIC_VERSION_INTERESTED"; //$NON-NLS-1$

    private Collection<VersioningCallback> callbacks = new LinkedList<VersioningCallback>();

    public void registerVersioningCallback(VersioningCallback callback) {
        callbacks.add(callback);
    }

    public void registerClassVersioningCallback(GalaxyClass clazz) {
        callbacks.add(new ClassVersioningCallback(clazz));
    }

    public void registerAppendVersioningCallback(ConfigurationString string) {
        callbacks.add(new AppendVersioningCallback(string));
    }

    public void versionTriggerNetwork(String version_id) {
        for (VersioningCallback callback : callbacks)
            callback.incorporateVersionIdentifier(version_id);
    }

    /**
     * Computes an (almost) unique version identifier (MD5 hash) from an intermediate (i.e., incomplete) trigger network).
     * 
     * @param ctx is the compiler context
     * @param subnet is the root object in the MOIN representation of the trigger network
     * @return the MD5 hash (in hex encoding) of the intermediate trigger network CSV
     * @throws BPMNCompilerException in case the assemble find inconsistencies in the model
     */
    public static String computeTriggernetVersion(CompilerContext ctx, Subnet subnet) throws BPMNCompilerException {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(out, SharedCompilerConstants.UTF_8));
            (new GalaxyAssembler(ctx.getHost())).generateCSV(subnet, writer);
            return computeVersion(out.toByteArray());
        } catch (AssemblerException e) {
            throw new BPMNCompilerException("Assembler error for intermediate build result (faulty target model).", e);
        } catch (UnsupportedEncodingException e) {
            throw new UnsupportedOperationException("Failed to compute version id (UTF-8 not supported).", e);
        }
    }

    /**
     * Compute an MD5 hash over the UTF-8 representation of the string
     * @param input string
     * @return the MD5 hash (in hex encoding) of the input string
     */
    public static String computeVersion(String input) {
        try {
            return computeVersion(input.getBytes(SharedCompilerConstants.UTF_8));
        } catch (UnsupportedEncodingException e) {
            throw new UnsupportedOperationException("Failed to compute version id (UTF-8 not supported).", e);
        }
    }

    private static String computeVersion(byte[] input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] hash = digest.digest(input);
            StringBuilder version = new StringBuilder();
            for (byte b : hash) {
                // converts the signed byte [-128, 127] into a corresponding unsigned int [0, 255]
                String hex = Integer.toHexString(b & 0x00ff);
                if (hex.length() < 2) {
                    version.append('0');
                }
                version.append(hex);
            }
            return version.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new UnsupportedOperationException("Failed to compute version id (MD5 not available).", e);
        }
    }

    /**
     * Do not change it as it affects the primary keys of glx_c_sv_sov table(it is created from the 3contained fieleds-service, operation,
     * version)
     * 
     * @param service
     * @param operation
     * @param semanticVersion
     * @return
     */
    public static String computeServiceOperationVersionMD5(final String service, final String operation, final int semanticVersion) {
        if (service == null || operation == null) {
            throw new IllegalArgumentException();
        }
        StringBuilder stringBuilder = new StringBuilder(service);
        stringBuilder.append(operation);
        stringBuilder.append(semanticVersion);
        String sovid = VersioningHelper.computeVersion(stringBuilder.toString());
        return sovid;
    }

    public static boolean isInterestedFromSemanticVersion(final ScopeReference scopeReference) {
        boolean interested = false;
        if (scopeReference != null) {
            List<Property> listProperties = scopeReference.getProperties();
            if (listProperties != null && !listProperties.isEmpty()) {
                for (Property property : listProperties) {
                    if (property != null && SEMANTIC_VERSION_INTERESTED.equals(property.getKey())) {
                        String value = property.getValue();
                        if (value != null && value.trim().length() > 0) {
                            interested = Boolean.parseBoolean(value);
                            return interested;
                        }
                    }
                }
            }
        }
        return interested;
    }

    public static Integer getBPMNEndpointSemanticVersionOffer(final CompilerContext ctx, final ScopeReference scopeReference)
            throws BPMNCompilerException {
        // get message trigger of the inner start event
        Scope scope = scopeReference.getReferencedScope();
        Integer semanticVersion = getBPMNEndpointSemanticVersionOffer(ctx, scope);
        return semanticVersion;
    }

    public static Integer getBPMNEndpointSemanticVersionOffer(final CompilerContext ctx, final StartEvent startEvent)
            throws BPMNCompilerException {
        // get message trigger of the inner start event
        return getBPMNEndpointSemanticVersionOffer(ctx, startEvent.getScope());
    }

    private static Integer getBPMNEndpointSemanticVersionOffer(final CompilerContext ctx, final Scope scope) throws BPMNCompilerException {
        if (scope != null) {
            if ((scope instanceof Pool && scope.isActive()) || scope instanceof Task) {
                List<Property> listProperties = scope.getProperties();
                if (listProperties != null && !listProperties.isEmpty()) {
                    for (Property property : listProperties) {
                        if (property != null && SEMANTIC_VERSION_OFFER.equals(property.getKey())) {
                            String value = property.getValue();
                            if (value != null && value.trim().length() > 0) {
                                try {
                                    Integer intValue = Integer.valueOf(value);
                                    return intValue;
                                } catch (NumberFormatException nfe) {
                                    ctx.getValidator().validate(false, "BPM.rt_c_bpmn.000016",
                                            "SEMANTIC_VERSION_OFFER value '%s' must be integer in scope(Process/Task) '%s'.", value,
                                            scope.getOriginalName());
                                }
                            }
                        }
                    }
                }
            }
        }
        return null;
    }
}
