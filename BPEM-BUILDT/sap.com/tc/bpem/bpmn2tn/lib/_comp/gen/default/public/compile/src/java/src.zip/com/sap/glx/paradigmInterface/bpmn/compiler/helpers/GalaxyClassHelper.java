package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;

public class GalaxyClassHelper {
    private final GalaxyClass galaxyClass;
    private final Map<String, Integer> nameToIndex = new HashMap<String, Integer>();
    private boolean initialized = false;

    public GalaxyClassHelper(final GalaxyClass galaxyClass) {
        if (galaxyClass == null) {
            throw new IllegalArgumentException("Parameter 'galaxyClass' must not be null");
        }
        this.galaxyClass = galaxyClass;
    }

    public int getAttributeIndex(final String attributeName) {
        if (attributeName == null) {
            throw new IllegalArgumentException("Parameter 'attributeName' must not be null");
        }
        initialize();
        final Integer index = nameToIndex.get(attributeName);
        if (index == null) {
            throw new IllegalArgumentException("Attribute name '" + attributeName + "' not found on GalaxyClass '" + galaxyClass + "'");
        }
        return index;
    }

    private void initialize() {
        if (!initialized) {
            initializeAttributes();
        }
        initialized = true;
    }

    private void initializeAttributes() {
        final List<Attribute> attributes = galaxyClass.getAttribute();
        for (int i = 0; i < attributes.size(); i++) {
            final Attribute attribute = attributes.get(i);
            nameToIndex.put(attribute.getName(), i);
        }
    }

}
