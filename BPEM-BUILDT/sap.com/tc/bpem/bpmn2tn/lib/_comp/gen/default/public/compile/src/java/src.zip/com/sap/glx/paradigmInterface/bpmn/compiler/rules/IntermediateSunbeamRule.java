package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.rule.Expression;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.ParameterFilter;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Switch;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.GalaxyClassHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.IntermediateMessageEventContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.MessageTriggerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.NormalizationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SunbeamHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventLogHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventTypeIds;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.BooleanLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

public class IntermediateSunbeamRule extends CatchEventMessageRule<IntermediateCatchEvent> implements CompilerRule<IntermediateCatchEvent> {

    private static Pair<String, String> ucRequest = new Pair<String, String>(CompilerConstants.ADAPTER_UC, CompilerConstants.GALAXY_REQUEST);
    private static final Pair<String, String> transformerData = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER,
            CompilerConstants.GALAXY_DATA);
    private static final Pair<String, String> transformerDataGenerator = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER,
            CompilerConstants.GALAXY_DATAGENERATOR);

    @Override
    public Class<IntermediateCatchEvent> getSupportedArtifact() {
        throw new IllegalStateException("Should be never called. Creation through dispather rule.");
    }

    @Override
    public void preprocess(final CompilerContext ctx) throws BPMNCompilerException {
        final SunbeamHelper sunbeamHelper = ctx.getState().getSunbeamHelper();

        // Add copyPrincipalFromCorrelationTrigger() method to the Token class
        ctx.getReplicator().enrichTokenClassWithSunbeamMethod(ctx.getState().getTokenClass());

        final Set<IntermediateCatchEvent> events = ctx.getArtifacts(IntermediateCatchEvent.class);
        for (final IntermediateCatchEvent event : events) {
            if (event.getTrigger() instanceof MessageEventDefinition) {

                // get validated endpoint and compare it to the one of the start event
                final Triple<String, String, Operation> endpoint = getEndpoint(ctx, event);
                final String qualifiedTriggerName = endpoint.second;
                final Operation operation = endpoint.third;

                ctx.getValidator().validate(!WSDLHelper.isSynchronous(operation), "BPM.rt_c_bpmn.000044", //$NON-NLS-1$
                        "Synchronous operation is not allowed on intermediate message event '%s'.", event.getOriginalName()); //$NON-NLS-1$
                ctx.getValidator().validate(OperationHelper.isModelledEndpoint(event.getTrigger()), "BPM.rt_c_bpmn.000085", //$NON-NLS-1$
                        "Intermediate message event '%s' must refer to an explicitly modeled message trigger.", event.getOriginalName());//$NON-NLS-1$

                // Build up the message trigger context that is used in compile()
                MessageTriggerContext messageTriggerContext = sunbeamHelper.getMessageTriggerContext(qualifiedTriggerName);
                if (messageTriggerContext == null) {
                    messageTriggerContext = new MessageTriggerContext(qualifiedTriggerName, operation);
                    sunbeamHelper.addMessageTriggerContext(messageTriggerContext);

                    // create class: CorrelationKey
                    final GalaxyClass correlationKeyClass = ctx.getReplicator().generateCorrelationKeyClass(event);

                    // create class: Subscription
                    final GalaxyClass subscriptionClass = ctx.getReplicator().generateSubscriptionClass(event);

                    messageTriggerContext.setCorrelationKeyClass(correlationKeyClass);
                    messageTriggerContext.setSubscriptionClass(subscriptionClass);

                    if (isShared(ctx, event)) {
                        messageTriggerContext.markAsConditionalStartEndpoint();

                        // create class: ResendRequest
                        final GalaxyClass resendRequestClass = ctx.getReplicator().generateResendRequestClass(event);
                        ctx.getState().setResendRequest(resendRequestClass);

                        // create class: ConditionalStarter
                        final GalaxyClass conditionalStarterClass = ctx.getReplicator().generateConditionalStarterClass(event);
                        messageTriggerContext.setConditionalStarterClass(conditionalStarterClass);

                        // create class: ConditionalStartCorrelationTrigger
                        final GalaxyClass conditionalStartCorrelationTriggerClass = ctx.getReplicator()
                                .generateConditionalStartCorrelationTriggerClass(event);
                        messageTriggerContext.setCorrelationTriggerClass(conditionalStartCorrelationTriggerClass);

                    } else {
                        // create class: CorrelationTrigger
                        final GalaxyClass correlationTriggerClass = ctx.getReplicator().generateCorrelationTriggerClass(event);
                        messageTriggerContext.setCorrelationTriggerClass(correlationTriggerClass);
                    }

                    // configuration of generator rules for ppUsername and ppHash
                    configureSunbeamEndpoint(ctx, event, correlationKeyClass);
                }

                final IntermediateMessageEventContext intermediateMessageEventContext = new IntermediateMessageEventContext(event);
                messageTriggerContext.addIntermediateMessageEventContext(intermediateMessageEventContext);
            }
        }
        sunbeamHelper.finishPreprocess();
    }

    @Override
    public void compile(final IntermediateCatchEvent intermediateMessageEvent, final CompilerContext ctx) throws BPMNCompilerException {
        final SunbeamHelper sunbeamHelper = ctx.getState().getSunbeamHelper();
        final MessageTriggerContext messageTriggerContext = sunbeamHelper.getMessageTriggerContext(intermediateMessageEvent);

        if (messageTriggerContext == null) {
            throw new BPMNCompilerException(String.format("Message trigger context for %s not available.", intermediateMessageEvent
                    .getName().getOriginalText()));
        }

        /**
         * Compilation must not start before all intermediate message events are known to the message trigger context.
         */
        messageTriggerContext.introduce(intermediateMessageEvent);

        if (messageTriggerContext.knowsAllIntermediateMessageEvents()) {
            compileMessageTrigger(ctx, messageTriggerContext);
        }
    }

    private void compileMessageTrigger(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext)
            throws BPMNCompilerException {
        // delete correlation key asynchronously
        final Source correlationKeySource = ctx.getSourceFactory().getSource4Class(messageTriggerContext.getCorrelationKeyClass());
        NodeFactory.connectNodes(correlationKeySource, 0, ctx.getReplicator().getBlackHole(), 0);

        // Join Subscription and CorrelationTrigger. If there is no Subscription, delete the CorrelationTrigger via the BlackHole
        final Source subscriptionSource = ctx.getSourceFactory().getSource4Class(messageTriggerContext.getSubscriptionClass());
        final Source correlationTriggerSource = ctx.getSourceFactory().getSource4Class(messageTriggerContext.getCorrelationTriggerClass());
        final Join subscriptionCorrelationTriggerJoin = createSubscriptionCorrelationTriggerJoinNode(ctx, subscriptionSource,
                correlationTriggerSource);
        messageTriggerContext.setSubscriptionCorrelationTriggerJoin(subscriptionCorrelationTriggerJoin);

        for (final IntermediateCatchEvent knownIntermediateMessageEvent : messageTriggerContext.getKnownIntermediateMessageEvents()) {
            compileIntermediateMessageEvent(ctx, messageTriggerContext, knownIntermediateMessageEvent);
        }

        // Once all events are processed the fingerprint attributes can be appended & the filter nodes compiled.
        compileFingerprintsForSubscriptionAndCorrelationTrigger(ctx, messageTriggerContext);

        // Finally generate the remaining configuration (All events need to be processed first!)
        generateCorrelationKeyConfiguration(ctx, messageTriggerContext);
        generateSubscriptionConfiguration(ctx, messageTriggerContext);

        if (messageTriggerContext.isConditionalStartEndpoint()) {
            generateResendRequestConfiguration(ctx);
            compileConditionalStart(ctx, messageTriggerContext);
        }
    }

    private void compileConditionalStart(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext)
            throws BPMNCompilerException {
        if (messageTriggerContext.getKnownIntermediateMessageEvents().isEmpty()) {
            throw new BPMNCompilerException("There are no intermediate message events for this message trigger");
        }
        final IntermediateCatchEvent intermediateEvent = messageTriggerContext.getKnownIntermediateMessageEvents().get(0);

        final GalaxyClass eventClass = ctx.getState().getEvent(ctx.getState().getStartEvent());
        ctx.getConfigFactory().generateIntermediateEventConfigurationAddition(eventClass, intermediateEvent);

        final GalaxyClass conditionalStarterClass = messageTriggerContext.getConditionalStarterClass();
        final Source conditionalStarter = ctx.getSourceFactory().getSource4Class(conditionalStarterClass);

        final Source ucRequest = ctx.getState().getUCRequest();
        final GenericOperator extractEventTargetUCRequest = createExtractEventTargetUC(ctx, messageTriggerContext, intermediateEvent);
        createRequestConditionalStarterJoin(ctx, ucRequest, conditionalStarter, extractEventTargetUCRequest);

        final GalaxyClass resendRequestGalaxyClass = ctx.getState().getResendRequest();
        final Source resendRequest = ctx.getSourceFactory().getSource4Class(resendRequestGalaxyClass);
        final GenericOperator extractEventTargetResendRequest = createExtractEventTargetResend(ctx, messageTriggerContext,
                intermediateEvent);
        createRequestConditionalStarterJoin(ctx, resendRequest, conditionalStarter, extractEventTargetResendRequest);

        // clean up ResendRequest and ConditionalStarter
        NodeFactory.connectNodes(resendRequest, 0, ctx.getReplicator().getBlackHole(), 0);
        NodeFactory.connectNodes(conditionalStarter, 0, ctx.getReplicator().getBlackHole(), 0);
    }

    private GenericOperator createExtractEventTargetUC(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext,
            final IntermediateCatchEvent intermediateEvent) {
        final AdvancedScript script = new AdvancedScript(ctx, ScriptName.EXTRACT_EVENT_CLASS, intermediateEvent);

        final ScriptVariable requestParam = script.addParameter(ScriptVariable.REQUEST, IntermediateSunbeamRule.ucRequest);
        final ScriptVariable conditionalStarter = script.addParameter(ScriptVariable.CONDITIONAL_STARTER, messageTriggerContext
                .getConditionalStarterClass());

        final ScriptVariable service = script.generateAssignCommand(ScriptVariable.SERVICE, requestParam, "service");
        final ScriptVariable operation = script.generateAssignCommand(ScriptVariable.OPERATION, conditionalStarter, "startOperation");

        final ScriptVariable name = script.generateInvocationCommand(ScriptVariable.NAME, requestParam, "getName");
        final ScriptVariable namespace = script.generateInvocationCommand(ScriptVariable.NAMESPACE, requestParam, "getNamespace");
        final ScriptVariable document = script.generateInvocationCommand(ScriptVariable.DOCUMENT, requestParam, "getData");
        final ScriptVariable scope = script.generateInvocationCommand(ScriptVariable.SCOPE, requestParam, "getScopeId");

        final ScriptVariable yves_in = script.generateNewCommand(ScriptVariable.YVES_IN, transformerData);
        script.generateInvocationCommand(yves_in, "setData", namespace, name, document, scope);
        final ScriptVariable generator = script.generateNewCommand(ScriptVariable.GENERATOR, transformerDataGenerator);

        script.generateInvocationCommand(generator, "generate", service, operation, requestParam, yves_in);

        script.generateDeleteCommand(generator);
        script.generateDeleteCommand(yves_in);
        return script.getExecution();
    }

    private GenericOperator createExtractEventTargetResend(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext,
            final IntermediateCatchEvent intermediateEvent) {
        final AdvancedScript script = new AdvancedScript(ctx, ScriptName.EXTRACT_EVENT_CLASS, intermediateEvent);

        final ScriptVariable requestParam = script.addParameter(ScriptVariable.REQUEST, ctx.getState().getResendRequest());
        final ScriptVariable conditionalStarter = script.addParameter(ScriptVariable.CONDITIONAL_STARTER, messageTriggerContext
                .getConditionalStarterClass());

        final ScriptVariable service = script.generateAssignCommand(ScriptVariable.SERVICE, requestParam, "service");
        final ScriptVariable operation = script.generateAssignCommand(ScriptVariable.OPERATION, conditionalStarter, "startOperation");
        final ScriptVariable sdoRootElementName = script.generateAssignCommand(ScriptVariable.NAME, requestParam, "sdoRootElementName");
        final ScriptVariable sdoRootElementNamespace = script.generateAssignCommand(ScriptVariable.NAMESPACE, requestParam,
                "sdoRootElementNamespace");
        final ScriptVariable sdoScopeId = script.generateAssignCommand(ScriptVariable.SCOPE, requestParam, "sdoScopeId");

        final ScriptVariable document = script.generateInvocationCommand(ScriptVariable.DOCUMENT, requestParam, "getData");

        final ScriptVariable yves_in = script.generateNewCommand(ScriptVariable.YVES_IN, transformerData);
        script.generateInvocationCommand(yves_in, "setData", sdoRootElementNamespace, sdoRootElementName, document, sdoScopeId);
        final ScriptVariable generator = script.generateNewCommand(ScriptVariable.GENERATOR, transformerDataGenerator);

        script.generateInvocationCommand(generator, "generate", service, operation, requestParam, yves_in);

        script.generateDeleteCommand(generator);
        script.generateDeleteCommand(yves_in);
        return script.getExecution();
    }

    private void createRequestConditionalStarterJoin(final CompilerContext ctx, final Source ucRequest, final Source conditionalStarter,
            final GenericOperator extractEventTarget) {
        final Join requestConditionalStarterJoin = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "request_conditionalstarter_join",
                "0/0/-1", "1/0/0");
        NodeFactory.connectNodes(ucRequest, 0, requestConditionalStarterJoin, 0);
        NodeFactory.connectNodes(conditionalStarter, 0, requestConditionalStarterJoin, 1);
        NodeFactory.connectNodes(requestConditionalStarterJoin, 0, extractEventTarget, 0);
    }

    private Join createSubscriptionCorrelationTriggerJoinNode(final CompilerContext ctx, final Source subscriptionSource,
            final Source correlationTriggerSource) {
        final Join subscriptionCorrelationTriggerJoin = ctx.getJoinFactory().generateJoin(ctx.getRootScope(),
                "subscription_correlationtrigger_join", "0/0/-1", "1/0/0");
        NodeFactory.connectNodes(subscriptionSource, 0, subscriptionCorrelationTriggerJoin, 0);
        NodeFactory.connectNodes(correlationTriggerSource, 0, subscriptionCorrelationTriggerJoin, 1);
        NodeFactory.connectNodes(subscriptionCorrelationTriggerJoin, 2, ctx.getReplicator().getBlackHole(), 0);

        return subscriptionCorrelationTriggerJoin;
    }

    private void compileIntermediateMessageEvent(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext,
            final IntermediateCatchEvent intermediateMessageEvent) throws BPMNCompilerException {

        // For Subscription & CorrelationKey
        generateCorrelationConditionAttributesAndConfiguration(ctx, intermediateMessageEvent, messageTriggerContext);

        // Configuration: Text ID, Original Text, Endpoint Alias
        generateSubscriptionTextConfiguration(ctx, messageTriggerContext, intermediateMessageEvent);
        generateEndpointAliasForCorrelationKey(ctx, messageTriggerContext, intermediateMessageEvent);

        compileSubnetForMessageConsumption(ctx, messageTriggerContext, intermediateMessageEvent);
    }

    private void generateCorrelationConditionAttributesAndConfiguration(final CompilerContext ctx,
            final IntermediateCatchEvent intermediateMessageEvent, final MessageTriggerContext messageTriggerContext)
            throws BPMNCompilerException {
        // Set bpmnService = null to avoid generation of unnecessary Generator configuration (endpoint.first stands for the name of the
        // bpmnService)
        final String bpmnService = null;
        final String qualifiedTriggerName = messageTriggerContext.getQualifiedTriggerName();
        final Operation operation = messageTriggerContext.getOperation();

        final GalaxyClass correlationKeyClass = messageTriggerContext.getCorrelationKeyClass();
        final GalaxyClass subscriptionClass = messageTriggerContext.getSubscriptionClass();

        final XsdElementDeclaration requestElement = WSDLHelper.getRequestElement(operation);
        final Expression expression = intermediateMessageEvent.getExpression();

        // normalize the correlation expressions into a conjunction of equality operations
        final NormalizationHelper helper = new NormalizationHelper(ctx);
        final List<Triple<String, Expression, Expression>> equalities = helper.normalize(expression, requestElement);

        // create CorrelationKey and Subscription attribute and its triggernet for updating
        final ArrayList<Pair<Attribute, Attribute>> conjunction = new ArrayList<Pair<Attribute, Attribute>>(equalities.size());
        for (final Triple<String, Expression, Expression> equality : equalities) {
            // for each equality comparison add an attribute to the message and event and create the update mechanism
            final Attribute correlationKeyAttribute = addEventAttribute(bpmnService, qualifiedTriggerName, operation, correlationKeyClass,
                    equality, ctx);
            final Attribute subscriptionAttribute = addSubscriptionAttribute(intermediateMessageEvent, subscriptionClass, equality, ctx);
            conjunction.add(new Pair<Attribute, Attribute>(correlationKeyAttribute, subscriptionAttribute));
        }

        // Now create the correlationKeyCorrelationCondition and fingerprintCorrelationcondition configs and create the configuration for
        // Subscription and CorrelationKey
        final Pair<String, String> correlationConditionConfig = generateCorrelationConditionsForConfiguration(conjunction,
                correlationKeyClass, subscriptionClass);

        messageTriggerContext.appendCorrelationConditionConfiguration(correlationConditionConfig.first, correlationConditionConfig.second);
    }

    private void generateSubscriptionTextConfiguration(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext,
            final IntermediateCatchEvent intermediateMessageEvent) {
        final GalaxyClass subscriptionClass = messageTriggerContext.getSubscriptionClass();
        ctx.getConfigFactory().generateSubscriptionConfigurationPerIntermediateMessageEvent(subscriptionClass, intermediateMessageEvent);
    }

    private void generateEndpointAliasForCorrelationKey(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext,
            final IntermediateCatchEvent intermediateMessageEvent) {
        ctx.getConfigFactory().generateEventConfigurationAddition(messageTriggerContext.getCorrelationKeyClass(), intermediateMessageEvent);
    }

    private void compileSubnetForMessageConsumption(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext,
            final IntermediateCatchEvent compiledIntermediateMessageEvent) throws BPMNCompilerException {

        final GalaxyClass tokenClass = ctx.getState().getTokenClass();
        final GalaxyClass instanceClass = ctx.getState().getInstanceClass();

        final Operation operation = messageTriggerContext.getOperation();
        final GalaxyClass correlationTriggerClass = messageTriggerContext.getCorrelationTriggerClass();
        final GalaxyClass subscriptionClass = messageTriggerContext.getSubscriptionClass();

        // collect the data objects needed for mapping
        final Pair<IMappingCompiler.Summary, String> outputMapping = ctx.getMappingHelper().compile(
                compiledIntermediateMessageEvent.getOutputMapping());
        final String mappingId = outputMapping.second;
        final Pair<Set<DataContainer>, Set<DataContainer>> context = identifyInOutDataObjects(ctx, outputMapping.first, Direction.INOUT);
        final Set<DataContainer> sourceContext = context.first;
        final Set<DataContainer> targetContext = context.second;
        // add depending views and their dependencies to script header (for optimized view update)
        final SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(targetContext);
        final Set<DataContainer> usedContext = new LinkedHashSet<DataContainer>();
        usedContext.addAll(sourceContext);
        usedContext.addAll(targetContext);
        usedContext.addAll(allViewDependencies);

        // Create target script to switch the token state to the next state
        final Target consumeIntermediateEventTarget = ctx.getTargetFactory().generateTarget(compiledIntermediateMessageEvent,
                "consume_intermediate_event");
        final String generateSunbeamConsumeEventScriptHeader = generateSunbeamConsumeEventScriptHeader(compiledIntermediateMessageEvent,
                tokenClass, instanceClass, subscriptionClass, correlationTriggerClass, usedContext, ctx);
        final String generateSunbeamConsumeEventScriptBody = generateSunbeamConsumeEventScriptBody(compiledIntermediateMessageEvent,
                consumeIntermediateEventTarget, usedContext, operation, mappingId, sourceContext, targetContext, ctx, messageTriggerContext);
        ctx.getTargetFactory().setScript(consumeIntermediateEventTarget, generateSunbeamConsumeEventScriptHeader,
                generateSunbeamConsumeEventScriptBody);

        final int beforeTokenState = ctx.getState().getBeforeTokenSwitchExit(compiledIntermediateMessageEvent);
        final Switch tokenStateSwitch = ctx.getState().getTokenSwitch();
        // Join <Subscription,CorrelationTrigger> with <Token,Instance> after the token state switch
        final Join subscriptionInstanceJoin = createSubscriptionInstanceJoinNode(ctx, beforeTokenState, tokenStateSwitch);

        final IntermediateMessageEventContext intermediateMessageEventContext = messageTriggerContext
                .getIntermediateMessageEventContext(compiledIntermediateMessageEvent);
        intermediateMessageEventContext.setSubscriptionInstanceJoin(subscriptionInstanceJoin);

        // connect context join cascade
        if (usedContext.isEmpty()) {
            NodeFactory.connectNodes(subscriptionInstanceJoin, 0, consumeIntermediateEventTarget, 0);
        } else {
            final ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, compiledIntermediateMessageEvent.getScope(),
                    compiledIntermediateMessageEvent, null, usedContext);
            if (ctx.getRootScope().equals(compiledIntermediateMessageEvent.getScope())) {
                // is root scope, projection only contains data objects
                // instance = context.owner
                final Join contextJoin = ctx.getJoinFactory().generateJoin(compiledIntermediateMessageEvent, "context", "0/1/-1", "1/0/0");
                // token, instance, subscription, trigger
                NodeFactory.connectNodes(subscriptionInstanceJoin, 0, contextJoin, 0);
                // context
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                NodeFactory.connectNodes(contextJoin, 0, consumeIntermediateEventTarget, 0);
            } else {
                // is in embedded scope, projection contains frame object as first element
                // token.frame=context.owner
                final Join contextJoin = ctx.getJoinFactory().generateJoin(compiledIntermediateMessageEvent, "context", "0/0/2", "1/0/-1");
                // token, instance, subscription, trigger
                NodeFactory.connectNodes(subscriptionInstanceJoin, 0, contextJoin, 0);
                // context
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                // for the target node the frame has to be removed now
                final List<Integer> usedIndexes = new ArrayList<Integer>();
                // token,instance,subscription, trigger
                usedIndexes.add(0);
                usedIndexes.add(1);
                usedIndexes.add(2);
                usedIndexes.add(3);
                // ignore frame (4)
                int runningIndex = 5;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                final Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(compiledIntermediateMessageEvent,
                        "context_no_frame_projection", usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(contextJoin, 0, noFrameSwizzle, 0);
                // connect no frame swizzle to target
                NodeFactory.connectNodes(noFrameSwizzle, 0, consumeIntermediateEventTarget, 0);
            }
        }
    }

    private Join createSubscriptionInstanceJoinNode(final CompilerContext ctx, final int beforeTokenState, final Switch tokenStateSwitch) {
        final Join subscriptionInstanceJoin = ctx.getJoinFactory().generateJoin(ctx.getRootScope(), "subscription_instance_join", "0/1/-1",
                "1/0/0");
        NodeFactory.connectNodes(tokenStateSwitch, beforeTokenState, subscriptionInstanceJoin, 0);
        return subscriptionInstanceJoin;
    }

    private void compileFingerprintsForSubscriptionAndCorrelationTrigger(final CompilerContext ctx,
            final MessageTriggerContext messageTriggerContext) {
        int fingerprintNameIndex = 0;
        for (final IntermediateCatchEvent intermediateMessageEvent : messageTriggerContext.getKnownIntermediateMessageEvents()) {
            final int subscriptionFingerprintIndex = addFingerprintAttributeToSubscription(ctx, messageTriggerContext, fingerprintNameIndex);
            messageTriggerContext.appendFingerprintConfiguration(String.valueOf(subscriptionFingerprintIndex));
            final int correlationTriggerFingerprintIndex = addFingerprintAttributeToCorrelationTrigger(ctx, messageTriggerContext,
                    fingerprintNameIndex);

            // Check whether the fingerprints still match (subscription.fingerprint = correlationTrigger.fingerprint)
            final ParameterFilter fingerprintFilter = createFingerprintFilterNode(ctx, subscriptionFingerprintIndex,
                    correlationTriggerFingerprintIndex);
            NodeFactory.connectNodes(messageTriggerContext.getSubscriptionCorrelationTriggerJoin(), 0, fingerprintFilter, 0);

            // Connect fingerprint filter to Node joining token, instance with subscription and correlation trigger
            final IntermediateMessageEventContext intermediateMessageEventContext = messageTriggerContext
                    .getIntermediateMessageEventContext(intermediateMessageEvent);
            NodeFactory.connectNodes(fingerprintFilter, 0, intermediateMessageEventContext.getSubscriptionInstanceJoin(), 1);

            fingerprintNameIndex++;
        }
    }

    private int addFingerprintAttributeToCorrelationTrigger(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext,
            final int fingerprintNameIndex) {
        final GalaxyClass correlationTriggerClass = messageTriggerContext.getCorrelationTriggerClass();
        return addFingerprintAttributeToGalaxyClass(ctx, correlationTriggerClass, fingerprintNameIndex);
    }

    private int addFingerprintAttributeToSubscription(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext,
            final int fingerprintNameIndex) {
        final GalaxyClass subscriptionClass = messageTriggerContext.getSubscriptionClass();
        return addFingerprintAttributeToGalaxyClass(ctx, subscriptionClass, fingerprintNameIndex);
    }

    private int addFingerprintAttributeToGalaxyClass(final CompilerContext ctx, final GalaxyClass galaxyClass,
            final int fingerprintNameIndex) {
        final int fingerprintIndex = galaxyClass.getAttribute().size();
        ctx.getClassFactory().addAttribute(galaxyClass, ATTRIBUTE_FINGERPRINT + fingerprintNameIndex, ctx.getSimpleTypes().STRING);
        return fingerprintIndex;

    }

    private ParameterFilter createFingerprintFilterNode(final CompilerContext ctx, final int subscriptionFingerprintIndex,
            final int correlationTriggerFingerprintIndex) {
        final ParameterFilter fingerprintFilter = ctx.getParameterFilterFactory().generateFilter(ctx.getRootScope(), "fingerprint filter",
                "0/0/" + subscriptionFingerprintIndex, "0/1/" + correlationTriggerFingerprintIndex, "==");
        return fingerprintFilter;
    }

    private void generateCorrelationKeyConfiguration(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext) {
        ctx.getConfigFactory().generateCorrelationKeyConfiguration(messageTriggerContext);
    }

    private void generateResendRequestConfiguration(final CompilerContext ctx) {
        ctx.getConfigFactory().generateResendRequestConfiguration(ctx.getState().getResendRequest());
    }

    private void generateSubscriptionConfiguration(final CompilerContext ctx, final MessageTriggerContext messageTriggerContext) {
        final String endpointId = messageTriggerContext.getEndpointId();
        final GalaxyClass correlationTriggerClass = messageTriggerContext.getCorrelationTriggerClass();
        final GalaxyClass subscriptionClass = messageTriggerContext.getSubscriptionClass();

        ctx.getConfigFactory().generateSubscriptionConfiguration(subscriptionClass, endpointId, correlationTriggerClass.getName(),
                messageTriggerContext.getCorrelationConditionConfigurationForSubscription(),
                messageTriggerContext.getFingerprintConfiguration());
    }

    /**
     * Creates the configuration for the correlation condition (which correlation attributes are needed to calculate fingerprints in the
     * runtime).
     * 
     * @param conjunction
     *            A list of conjunction of which the correlation conditions will be extracted
     * @return A Pair of Strings. <b>Pair.first</b> is the configuration for the CorrelationKey, <b>Pair.second</b> the configuration for
     *         the Subscription
     */
    private Pair<String, String> generateCorrelationConditionsForConfiguration(final ArrayList<Pair<Attribute, Attribute>> conjunction,
            final GalaxyClass correlationKey, final GalaxyClass subscription) {
        final StringBuilder correlationKeyFingerprintConfigBuilder = new StringBuilder();
        final StringBuilder subscriptionFingerprintConfigBuilder = new StringBuilder();

        final GalaxyClassHelper correlationKeyHelper = new GalaxyClassHelper(correlationKey);
        final GalaxyClassHelper subscriptionHelper = new GalaxyClassHelper(subscription);

        final Iterator<Pair<Attribute, Attribute>> conjunctionIterator = conjunction.iterator();
        while (conjunctionIterator.hasNext()) {
            final Pair<Attribute, Attribute> correlationAttributes = conjunctionIterator.next();

            // take the index of the correlation attributes
            final int correlationKeyAttributeIndex = correlationKeyHelper.getAttributeIndex(correlationAttributes.first.getName());
            final int subscriptionAttributeIndex = subscriptionHelper.getAttributeIndex(correlationAttributes.second.getName());
            correlationKeyFingerprintConfigBuilder.append(correlationKeyAttributeIndex);
            subscriptionFingerprintConfigBuilder.append(subscriptionAttributeIndex);
            if (conjunctionIterator.hasNext()) {
                correlationKeyFingerprintConfigBuilder.append('&');
                subscriptionFingerprintConfigBuilder.append('&');
            }
        }
        return new Pair<String, String>(correlationKeyFingerprintConfigBuilder.toString(), subscriptionFingerprintConfigBuilder.toString());
    }

    private String generateSunbeamConsumeEventScriptHeader(final IntermediateCatchEvent intermediate_control, final GalaxyClass tokenClass,
            final GalaxyClass instanceClass, final GalaxyClass subscriptionClass, final GalaxyClass correlationTriggerClass,
            final Collection<DataContainer> usedContext, final CompilerContext ctx) {
        final StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                CompilerConstants.TARGET_INTERMEDIATE_CONTROL_EVENT, intermediate_control));
        sb.append(ScriptHelper.generateClassDeclaration(tokenClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(instanceClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(subscriptionClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_SUBSCRIPTION)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(correlationTriggerClass, new Variable(
                CompilerConstants.SCRIPT_VARIABLE_CORRELATION_TRIGGER)));
        for (final DataContainer container : usedContext) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(container), new Variable(ctx
                    .getState().getContextVariableName(container))));
        }
        sb.append(") ");
        return sb.toString();
    }

    private String generateSunbeamConsumeEventScriptBody(final IntermediateCatchEvent intermediate_control, final Target target,
            final Set<DataContainer> usedContext, final Operation operation, final String mappingId, final Set<DataContainer> inputContext,
            final Set<DataContainer> outputContext, final CompilerContext ctx, final MessageTriggerContext messageTriggerContext)
            throws BPMNCompilerException {
        final List<Variable> parameters = new ArrayList<Variable>();
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_SUBSCRIPTION));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_CORRELATION_TRIGGER));
        for (final DataContainer container : usedContext) {
            parameters.add(new Variable(ctx.getState().getContextVariableName(container)));
        }

        final StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, intermediate_control, target, parameters));

        // scope code
        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(),
                new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        // generate mapping code only if there is some mapping
        if (!usedContext.isEmpty()) {
            // message=trigger:getData();
            sb.append(ScriptHelper.generateInvocationCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_MESSAGE), new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_CORRELATION_TRIGGER), "getData"));

            // mapping script
            final XsdElementDeclaration request = WSDLHelper.getRequestElement(operation);
            sb.append(ScriptHelper.generateMappingCode(ctx, mappingId, inputContext, outputContext,
                    new Triple<XsdElementDeclaration, Variable, StringLiteral>(request, new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_MESSAGE), new StringLiteral(ctx.getHost().getVersionId(
                            ctx.getDependencyHelper().getScope(operation), CompilerType.TYPECOMPILER))), null));
        }

        appendTokenAdvanceScript(ctx, intermediate_control, sb);

        // remember whether the trigger was consumed (or deleted) for conditional start endpoints
        if (messageTriggerContext.isConditionalStartEndpoint()) {
            // consumed = true;
            sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CORRELATION_TRIGGER), "consumed",
                    BooleanLiteral.TRUE));
        }

        final String mofId = intermediate_control.get___Mri().getMofId();
        sb.append(ScriptHelper.generateInvocationCommand(null, new Variable(CompilerConstants.SCRIPT_VARIABLE_CORRELATION_TRIGGER),
                CompilerConstants.METHOD_CORRELATIONTRIGGER_LOG_CONSUMPTION, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT),
                new StringLiteral(mofId)));

        // write event log entry for ime triggered/consumed
        final Variable varInstance = new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT);
        final Variable varCorrelationTrigger = new Variable(CompilerConstants.SCRIPT_VARIABLE_CORRELATION_TRIGGER);
        final Variable varMessageId = new Variable(CompilerConstants.SCRIPT_VARIABLE_MESSAGE_ID);
        sb.append(ScriptHelper.generateAssignCommand(varMessageId, varCorrelationTrigger, "messageId"));
        EventLogHelper.addEventWithMsgId(sb, ctx.getState().getEventLoggerClass(), EventTypeIds.INTERMEDIATE_EVENT_TRIGGERED, ((Pool) ctx
                .getRootScope()).refMofId(), varInstance, intermediate_control.refMofId(), null, varMessageId);

        // delete correlationTrigger;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CORRELATION_TRIGGER)));

        sb.append("}");
        return sb.toString();
    }

    private void appendTokenAdvanceScript(final CompilerContext ctx, final IntermediateCatchEvent intermediateControl,
            final StringBuilder sb) throws BPMNCompilerException {

        final int beforeState = ctx.getState().getBeforeTokenLabel(intermediateControl);
        final int nextState = ctx.getState().getAfterTokenLabel(intermediateControl);
        final Variable varToken = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN);
        if (nextState == beforeState) {
            /**
             * See Note 2052360 - We have to ensure that timers after event-based gateways are cleaned up and recreated
             */
            // frame=token:frame
            final Variable varFrame = new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME);
            sb.append(ScriptHelper.generateAssignCommand(varFrame, varToken, CompilerConstants.ATTRIBUTE_FRAME));
            // tokenCopy = new Token(parent, nextTokenState, frame)
            final Variable varTokenCopy = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "Copy");
            final GalaxyClass tokenClass = ctx.getState().getTokenSource().getGalaxyClass();
            sb.append(ScriptHelper.generateNewCommand(varTokenCopy, tokenClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT),
                    new IntegerLiteral(nextState), varFrame));
            appendPrinciplePropagationScript(ctx, sb, varTokenCopy);
            // delete old token object
            sb.append(ScriptHelper.generateDeleteCommand(varToken));
        } else {
            appendPrinciplePropagationScript(ctx, sb, varToken);
            // token:state=<next>;
            sb.append(ScriptHelper.generateUpdateCommand(varToken, CompilerConstants.ATTRIBUTE_STATE, new IntegerLiteral(nextState)));
        }
    }

    private void appendPrinciplePropagationScript(final CompilerContext ctx, final StringBuilder sb, final Variable varToken) {
        // propagate principal from correlation trigger to token
        // token:copyPrincipalFromCorrelationTrigger(correlationTrigger, subscription);
        if (ctx.isPrincipalPropagationActive()) {
            sb.append(ScriptHelper.generateInvocationCommand(null, varToken,
                    CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_CORRELATIONTRIGGER, new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_CORRELATION_TRIGGER), new Variable(
                            CompilerConstants.SCRIPT_VARIABLE_SUBSCRIPTION)));
        }
    }

}
