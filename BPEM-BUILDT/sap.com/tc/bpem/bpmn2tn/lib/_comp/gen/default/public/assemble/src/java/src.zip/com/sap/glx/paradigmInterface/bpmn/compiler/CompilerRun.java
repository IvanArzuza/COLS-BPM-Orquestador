package com.sap.glx.paradigmInterface.bpmn.compiler;

import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.triggernet.Network;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.DependencyHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.CollectArtifactsStage;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.CompileArtifactsStage;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.CompilerStage;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.CreateScopeClassesStage;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.DetermineDependingViewsStage;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.GenerateDebugSymbolsStage;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.GenerateScenarioLibraryStage;
import com.sap.glx.paradigmInterface.bpmn.compiler.stage.LabelEdgesStage;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.Partitionable;

/**
 * The Galaxy BPMN2TN compiler. To compile a BPMN workflow into a Galaxy trigger
 * network, create a new instance of this class and execute its
 * {@link #generateTriggerNetwork(Warnable)} method.
 * 
 * @author Thilo-Alexander Ginkel
 * @author d046672
 * @author Boris Savov ( I030791 )
 * 
 * @version $Id:
 *          //bpem/bpem.tools/dev/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/CompilerRun.java#9 $
 */
public class CompilerRun {
	/**
	 * An array referencing all compiler stages, which will be executed in the
	 * given order.
	 */
	@SuppressWarnings("unchecked")
	private static final Class<? extends CompilerStage>[] STAGES = new Class[] {
			CollectArtifactsStage.class, CreateScopeClassesStage.class,
			LabelEdgesStage.class, GenerateScenarioLibraryStage.class,
			DetermineDependingViewsStage.class, CompileArtifactsStage.class, 
			GenerateDebugSymbolsStage.class };


	/**
	 * Transforms the BPMN model previously supplied to the constructor into its
	 * trigger network representation.
	 * 
	 * @param warnable
	 * @return the transformation result, i.e. the resulting trigger network
	 * @throws BPMNCompilerException
	 *             if a compilation error occurs
	 */
	public Pair<Subnet, String> generateTriggerNetwork(Scope scope, ITriggernetFacade triggernetFacade,
			DependencyHelper dependencies, IBuilderHost host)
			throws BPMNCompilerException {
		
		Subnet subnet = createSubnet(scope);
		
		CompilerContext ctx = new CompilerContext(
				triggernetFacade,
				scope, 
				subnet, 
				dependencies, 
				host);
		
		createSkeletonTriggerNetwork(ctx);

		String version = VersioningHelper.computeTriggernetVersion(ctx, subnet);
		
		afterBurner(subnet, version, ctx);

		return new Pair<Subnet, String>(subnet, version);
	}

	private Subnet createSubnet(Scope scope) throws BPMNCompilerException {
	    Connection connection = ((Partitionable) scope).get___Connection();
	    Network net = connection.createElement(Network.class);
		Subnet subnet = connection.createElement(Subnet.class);
		subnet.setName(createNetworkName(scope));
		subnet.setId(scope.refMofId());
		net.getSubnet().add(subnet);
		return subnet;
	}
	
	private String createNetworkName(Scope scope) {
		String scopeName = scope.getOriginalName();
		int remaining = 255 - scopeName.length(); 
		
		if (remaining < 0) {
			return scopeName.substring(0, 255);
		} else if (remaining < 10) {
			return scopeName;
		} else {
			String dcName = ((Partitionable) scope).get___Mri().getContainerName();
			if(dcName.length() < remaining - 1) {
				return dcName + '/' + scopeName;
			} else {
				return dcName.substring(0, remaining - 4) + ".../" + scopeName; //$NON-NLS-1$
			}
		}
	}
	
	/**
	 * Creates an incomplete TN (classes/configuration are not yet versioned)
	 * 
	 * @return
	 * @throws BPMNCompilerException
	 */
	private void createSkeletonTriggerNetwork(CompilerContext ctx) throws BPMNCompilerException {
		for (Class<? extends CompilerStage> stageClazz : STAGES) {
			// instantiate the compiler stage...
			CompilerStage stage;
			try {
				stage = stageClazz.newInstance();
			} catch (Exception e) {
				throw ctx.getValidator().error("BPM.rt_c_bpmn.000068", //$NON-NLS-1$
				        "Unable to instantiate the '%s' compiler stage", e, stageClazz.getSimpleName()); //$NON-NLS-1$
			}

			// ...and execute it
			stage.execute(ctx);
		}

		
	}

	private void afterBurner(Subnet subnet, String version, CompilerContext ctx) {
		ctx.getVersioningHelper().versionTriggerNetwork(version);
		subnet.setId(version);
	}
}
