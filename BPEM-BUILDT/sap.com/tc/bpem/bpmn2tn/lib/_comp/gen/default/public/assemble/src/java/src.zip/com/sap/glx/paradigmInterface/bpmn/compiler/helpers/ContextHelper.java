package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.paradigmInterface.bpmn.compiler.BidiMap;

public class ContextHelper {
    private BidiMap<DataContainer,GalaxyClass> name2context_class = new BidiMap<DataContainer,GalaxyClass>();
    private Map<GalaxyClass,GalaxyClass> container2scope = new HashMap<GalaxyClass,GalaxyClass>();
    
    public void addContextVariable(DataContainer container, GalaxyClass clsContainer, GalaxyClass clsScope) {
        name2context_class.put(container, clsContainer);
        container2scope.put(clsContainer, clsScope);
    }
    
    public GalaxyClass getScopeClass(GalaxyClass container_class) {
        return container2scope.get(container_class);
    }
    
    public GalaxyClass getClassByDataObject(DataContainer object) {
        return name2context_class.getRight(object);
    }
    
    public DataContainer getDataObjectByClass(GalaxyClass clazz) {
        return name2context_class.getLeft(clazz);
    }
    
    public boolean existContextClasses() {
        return name2context_class.size()>0;
    }
    
    public Set<GalaxyClass> getContextClasses() {
        return name2context_class.values();
    }
    
    public Set<DataContainer> getDataContainers() {
        return name2context_class.keys();
    }
    
    public Set<Map.Entry<DataContainer,GalaxyClass>> fullContext() {
        return name2context_class.entrySet();
    }
}
