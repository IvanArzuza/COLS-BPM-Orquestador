package com.sap.glx.paradigmInterface.bpmn.compiler;

public class Triple<T1, T2, T3> implements Comparable<Triple<T1, T2, T3>> {
    public T1 first;
    public T2 second;
    public T3 third;

    public Triple(T1 first, T2 second, T3 third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }

    public boolean equals(Object o) {
        if (o instanceof Triple<?,?,?>) {
            @SuppressWarnings("unchecked")
            Triple<T1, T2, T3> other = (Triple<T1, T2, T3>) o;

            return other.first.equals(first) && other.second.equals(second) && other.third.equals(third);
        }
        return false;
    }

    public int hashCode() {
        return first.hashCode() ^ second.hashCode() ^ third.hashCode();
    }

    @SuppressWarnings("unchecked")
    public int compareTo(Triple<T1, T2, T3> triple) {
        int comp_first = ((Comparable<T1>) first).compareTo(triple.first);

        if (comp_first == 0) {
            int comp_second = ((Comparable<T2>) second).compareTo(triple.second);
            if (comp_second == 0)
                return ((Comparable<T3>) third).compareTo(triple.third);
            return comp_second;
        }
        return comp_first;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("("); 					//$NON-NLS-1$
        sb.append(first.toString());
        sb.append(", "); 					//$NON-NLS-1$
        sb.append(second.toString());
        sb.append(", "); 					//$NON-NLS-1$
        sb.append(third.toString());
        return sb.toString();
    }
}
