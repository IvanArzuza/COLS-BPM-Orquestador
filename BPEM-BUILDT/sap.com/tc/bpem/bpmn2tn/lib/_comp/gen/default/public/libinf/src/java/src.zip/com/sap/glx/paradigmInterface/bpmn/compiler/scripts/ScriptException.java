package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;


/**
 * This exception can occur while composing a script with the classes  
 * in the com.sap.glx.paradigmInterface.bpmn.compiler.scripts package.
 * 
 * @author Philipp Sommer
 *
 */
public class ScriptException extends RuntimeException {

	private static final long serialVersionUID = 668686638821834835L;

	public ScriptException(String message) {
		super(message);
	}

}
