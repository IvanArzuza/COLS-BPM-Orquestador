package com.sap.glx.paradigmInterface.bpmn.compiler;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class BidiMap<T1,T2> {
    private Map<T1,T2> t1_t2 = new HashMap<T1,T2>();
    private Map<T2,T1> t2_t1 = new HashMap<T2,T1>();
    
    public void put(T1 t1, T2 t2) {
        t1_t2.put(t1,t2);
        t2_t1.put(t2,t1);
    }  
    
    public T2 getRight(T1 t1) {
        return t1_t2.get(t1);
    }
    
    public T1 getLeft(T2 t2) {
        return t2_t1.get(t2);
    }
    
    public int size() {
        return t1_t2.size();
    }
    
    public Set<T1> keys() {
        return t1_t2.keySet();
    }
    
    public Set<T2> values() {
        return t2_t1.keySet();
    }
    
    public Set<Map.Entry<T1, T2>> entrySet() {
        return t1_t2.entrySet();
    }
}
