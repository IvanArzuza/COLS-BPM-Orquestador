package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals;

public abstract class AbstractLiteral<T> implements Literal<T>{
    protected T value;
    
    protected AbstractLiteral(T value) {
        this.value = value;
    }
    
    public T getValue() {
        return value;
    }
    
    public String toString() {
        return String.valueOf(value);
    }
}
