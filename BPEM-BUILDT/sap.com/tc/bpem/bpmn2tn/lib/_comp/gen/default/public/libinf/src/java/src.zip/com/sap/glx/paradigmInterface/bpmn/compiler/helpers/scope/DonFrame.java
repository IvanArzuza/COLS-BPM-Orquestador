package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * This helper holds a hierarchy of scopes as well as provide some convinience methods Furthermore it initializes some data related to the
 * scopes, e.g. assigning GalaxyClasses
 */
public class DonFrame {

    private final FrameNode rootFrame;
    private final CompilerContext ctx;
    private Map<Scope, FrameNode> scope2frame = new HashMap<Scope, FrameNode>();

    public DonFrame(FrameNode rootFrame, CompilerContext ctx) throws BPMNCompilerException {
        this.rootFrame = rootFrame;
        this.ctx = ctx;
        this.initialize();
    }

    public FrameNode getFrameNode4Scope(Scope scope) {
        return scope2frame.get(scope);
    }

    public boolean isRootScope(FrameNode frameNode) {
        return rootFrame.equals(frameNode);
    }

    /**
     * returns true if the parent of the given frame node is the root scope
     * @param frameNode
     * @return
     */
    public boolean isParentRootScope(FrameNode frameNode) {
        FrameNode parent = frameNode.getParent();
        if (parent == null) {
            // is the root scope
            return false;
        }
        if (rootFrame.getScope().equals(parent.getScope())) {
            return true;
        }
        return false;
    }

    public FrameNode getRootFrameNode() {
        return rootFrame;
    }

    private void initialize() throws BPMNCompilerException {
        rootFrame.setGalaxyClass(ctx.getState().getInstanceClass());
        scope2frame.put(rootFrame.getScope(), rootFrame);
        List<FrameNode> childNodes = rootFrame.getChildren();
        for (FrameNode child : childNodes) {
            initializeFrame(child);
        }
    }

    private void initializeFrame(FrameNode frameNode) throws BPMNCompilerException {
        FrameNode parent = frameNode.getParent();
        GalaxyClass parentClass = parent.getGalaxyClass();
        // create Galaxy Frame Class
        GalaxyClass frameClass = ctx.getReplicator().generateFrameClass(frameNode, parentClass, ctx);
        frameNode.setGalaxyClass(frameClass);
        EmbeddedScope frameScope = (EmbeddedScope) frameNode.getScope();
        if (frameScope != null) {
            scope2frame.put(frameScope, frameNode);
        }
        List<FrameNode> childNodes = frameNode.getChildren();
        for (FrameNode child : childNodes) {
            this.initializeFrame(child);
        }
    }

}
