package com.sap.glx.paradigmInterface.bpmn.compiler;

public class LocalCompilerConstants extends CompilerConstants {

    public static final String TARGET_INCL_GW_SPLIT = "INCL_GW"; //$NON-NLS-1$

}
