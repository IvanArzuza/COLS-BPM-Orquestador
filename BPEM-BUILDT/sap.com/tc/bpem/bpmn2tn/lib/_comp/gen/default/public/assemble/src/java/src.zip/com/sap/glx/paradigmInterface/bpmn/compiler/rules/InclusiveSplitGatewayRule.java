package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.galaxy.workflow.ConditionalSequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.InclusiveDataSplitGateway;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.LocalSource;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.LocalCompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.BooleanLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.NullLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Script;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.mapping.base.compiler.IMappingCompiler;

/**
 * A rule to compile Inclusive Gateway artifacts.
 * 
 * @version $Id:
 *          //bpem/bpem.bp/NW750EXT_SP_COR/src/SCs/sap.com/BPEM-BUILDT/DCs/sap.com/tc/bpem/bpmn2tn/lib/_comp/src/com/sap/glx/paradigmInterface
 *          /bpmn/compiler/rules/InclusiveSplitGatewayRule.java#1 $
 */
public class InclusiveSplitGatewayRule extends BaseCompilerRule<InclusiveDataSplitGateway> implements
        CompilerRule<InclusiveDataSplitGateway> {

    public Class<InclusiveDataSplitGateway> getSupportedArtifact() {
        return InclusiveDataSplitGateway.class;
    }

    public void compile(InclusiveDataSplitGateway inclusiveDataSplitGateway, CompilerContext ctx) throws BPMNCompilerException {
        ctx.getValidator().validateConnectors(inclusiveDataSplitGateway, 1, 1, 1, Integer.MAX_VALUE);

        // make sure the default edge is the last one
        List<SequenceConnector> conditionalConnectors = new LinkedList<SequenceConnector>();
        SequenceConnector defaultConnector = null;
        for (SequenceConnector connector : inclusiveDataSplitGateway.getOutgoingConnectors()) {
            if (((ConditionalSequenceConnector) connector).isDefault()) {
                ctx.getValidator()
                        .validate(
                                defaultConnector == null,
                                "BPM.rt_c_bpmn.001061", //$NON-NLS-1$ 
                                "Inclusive choice gateway '%s' has more than one outgoing default connector.", inclusiveDataSplitGateway.getOriginalName()); //$NON-NLS-1$
                defaultConnector = connector;
            } else {
                conditionalConnectors.add(connector);
            }
        }

        final int inboundEdgeTokenState = ctx.getState().getBeforeTokenSwitchExit(inclusiveDataSplitGateway);
        if (conditionalConnectors.isEmpty()) {
            // there is only a single connector which is the default connector
            // directly connect to the token switch
            // token:state=<next>
            Target forward_default_target = ctx.getTargetFactory().generateTarget(defaultConnector, "forward_token_default");
            ctx.getTargetFactory().setScript(forward_default_target, generateInclSplitGWDefault0Header(ctx, defaultConnector),
                    generateInclSplitGWDefault0Body(ctx, inclusiveDataSplitGateway, defaultConnector, forward_default_target));
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), inboundEdgeTokenState, forward_default_target, 0);
            return;
        }

        final Target highPrioBlackHole = generateHighPrioBlackHole(ctx); // priority=1

        DonFrame derDon = ctx.getState().getDonFrame();
        FrameNode currentFrameNode = derDon.getFrameNode4Scope(inclusiveDataSplitGateway.getScope());
        boolean isRootScope = derDon.isRootScope(currentFrameNode);

        final GalaxyClass connector0_class = ctx.getReplicator().generateConnectorClass((ConditionalSequenceConnector) defaultConnector,
                ctx.getState().getInstanceSource().getGalaxyClass(), ctx.getState().getTokenClass(), currentFrameNode.getGalaxyClass());
        final LocalSource connector0_source = ctx.getSourceFactory().getSource4Class(connector0_class);

        final Join connector0_instance_join = ctx.getJoinFactory().generateJoin(inclusiveDataSplitGateway,
                "inclusive_gw_connector0_instance_join", "0/0/0", "1/1/-1");
        NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), inboundEdgeTokenState, connector0_instance_join, 1);
        final Swizzle connector0TokenBlackHoleSwizzle;
        if (isRootScope) {
            connector0TokenBlackHoleSwizzle = ctx.getSwizzleFactory().generateSwizzle(inclusiveDataSplitGateway,
                    "connector0TokenBlackHoleSwizzle", 0, 1);
            NodeFactory.connectNodes(connector0_source, 0, connector0_instance_join, 0);
        } else {
            connector0TokenBlackHoleSwizzle = ctx.getSwizzleFactory().generateSwizzle(inclusiveDataSplitGateway,
                    "connector0TokenBlackHoleSwizzle", 0, 2);
            wireConnectorSourceWithNewJoinNodeForInstance(ctx, currentFrameNode, isRootScope, 0, defaultConnector, connector0_source,
                    connector0_instance_join);
        }
        NodeFactory.connectNodes(connector0TokenBlackHoleSwizzle, 0, generateDeleteConnector0TokenWithHighPrio(ctx), 0);
        NodeFactory.connectNodes(connector0_instance_join, 0, connector0TokenBlackHoleSwizzle, 0);

        int branch = 0;
        final List<Triple<String, LinkedHashSet<DataContainer>, GalaxyClass>> connectorsExtractionDataGC = new LinkedList<Triple<String, LinkedHashSet<DataContainer>, GalaxyClass>>();
        final List<ConstantFilter> connector_filters = new ArrayList<ConstantFilter>();
        final LinkedHashMap<String, DataContainer> mergedUsedContexts = new LinkedHashMap<String, DataContainer>();
        for (final SequenceConnector outbound_edge : conditionalConnectors) {
            final ConditionalSequenceConnector conditional_edge = (ConditionalSequenceConnector) outbound_edge;
            ctx.getValidator().validate(conditional_edge.getCondition() != null, "BPM.rt_c_bpmn.001062",//$NON-NLS-1$ 
                    "An outgoing connector of the inclusive choice gateway '%s' is neither default nor equipped with a branch condition.", //$NON-NLS-1$ 
                    inclusiveDataSplitGateway.getOriginalName());

            // Connector GalaxyClass + its source node
            GalaxyClass connector_class = ctx.getReplicator().generateConnectorClass(conditional_edge,
                    ctx.getState().getInstanceSource().getGalaxyClass(), ctx.getState().getTokenClass(), currentFrameNode.getGalaxyClass());
            LocalSource connector_source = ctx.getSourceFactory().getSource4Class(connector_class);

            Pair<IMappingCompiler.Summary, String> extraction = ctx.getMappingHelper().compile(conditional_edge.getCondition());
            LinkedHashSet<DataContainer> usedContext = identifySourceDataObjects(ctx, extraction.first);
            connectorsExtractionDataGC.add(new Triple<String, LinkedHashSet<DataContainer>, GalaxyClass>(extraction.second, usedContext,
                    connector_class));
            for (final DataContainer dataContainer : usedContext) {
                mergedUsedContexts.put(ctx.getState().getContextVariableName(dataContainer), dataContainer);
            }

            // High prio Blackhole gets connected with Connector source nodes
            // connects the connector's source node with the black hole (asynchronous deletion)
            // high prio guarantees that connectors are deleted before any other action happens (i.e. undesired repeated execution)
            NodeFactory.connectNodes(connector_source, 0, highPrioBlackHole, 0);

            // connector.valid==true [connector,parent/frame]
            ConstantFilter connector_filter = ctx.getConstantFilterFactory().generateFilter(conditional_edge,
                    "connector_valid_" + Integer.toString(branch), "0/0/2", "BOOLEAN:true", "==");
            connector_filters.add(connector_filter);

            // new Token(<next>, instance, ...); delete connector_i;
            GenericOperator forward_token_generic = ctx.getExecutionFactory().generateExecution(conditional_edge,
                    "forward_token_" + Integer.toString(branch));
            ctx.getExecutionFactory().setScript(forward_token_generic,
                    generateInclSplitGWForwardHeader(ctx, conditional_edge, connector_class, currentFrameNode, isRootScope),
                    generateInclSplitGWForwardBody(ctx, inclusiveDataSplitGateway, conditional_edge, forward_token_generic, isRootScope));
            // valid filter to forward target
            NodeFactory.connectNodes(connector_filter, 0, forward_token_generic, 0);

            wireConnectorSourceWithNewJoinNodeForInstance(ctx, currentFrameNode, isRootScope, branch, conditional_edge, connector_source,
                    connector_filter);
            branch++;
        }

        // Token, Parent, [Frame], [DO]{1..n}
        // valid=...; new Connector0..n(parent,valid);

        Target created_connector0_target = ctx.getTargetFactory().generateTarget(inclusiveDataSplitGateway, "evaluate_connectors");
        ctx.getTargetFactory().setScript(
                created_connector0_target,
                generateInclSplitGWConnector0Header(ctx, inclusiveDataSplitGateway, mergedUsedContexts, currentFrameNode, isRootScope),
                generateInclSplitGWConnector0Body(ctx, inclusiveDataSplitGateway, connectorsExtractionDataGC, created_connector0_target,
                        isRootScope, defaultConnector, connector0_class));

        ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, inclusiveDataSplitGateway.getScope(), inclusiveDataSplitGateway,
                "branch" + Integer.toString(branch), mergedUsedContexts.values());
        if (projectionSwizzle != null) {
            if (isRootScope) {
                // is root scope, projection only contains data objects
                // instance=do.owner
                Join context_join = ctx.getJoinFactory().generateJoin(inclusiveDataSplitGateway, "context_join", "0/1/-1", "1/0/0");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), inboundEdgeTokenState, context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, context_join, 1);
                NodeFactory.connectNodes(context_join, 0, created_connector0_target, 0);
            } else {
                // is in frame and has context
                // is in embedded scope, projection contains frame object as first element
                // token.frame=frame - get the correct instances
                Join context_join = ctx.getJoinFactory().generateJoin(inclusiveDataSplitGateway, "context_join", "0/0/2", "1/0/-1");
                NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), inboundEdgeTokenState, context_join, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, context_join, 1);
                // for the target node remove the frame now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                // token and instance
                usedIndexes.add(0);
                usedIndexes.add(1);
                // ignore frame
                int runningIndex = 3;
                // data objects
                for (int i = 1; i <= projectionSwizzle.getLastIndex(); i++) {
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(inclusiveDataSplitGateway, "context_no_frame_projection",
                        usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(context_join, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, created_connector0_target, 0);
            }
        } else {
            // target will get frame from token
            NodeFactory.connectNodes(ctx.getState().getTokenSwitch(), inboundEdgeTokenState, created_connector0_target, 0);
        }

        // DEFAULT connector
        final Pair<Node, Integer> default_script_connector_node = generateDefaultJoinCascade(ctx, connector_filters, defaultConnector,
                inboundEdgeTokenState);
        // new Token(instance, <default branch>); delete Connector_{0..n};
        GenericOperator forward_default_generic = ctx.getExecutionFactory().generateExecution(defaultConnector, "forward_token_default");
        ctx.getExecutionFactory().setScript(
                forward_default_generic,
                generateInlcSplitGWDefaultIHeader(ctx, defaultConnector, connectorsExtractionDataGC, currentFrameNode, isRootScope),
                generateInclSplitGWDefaultIBody(ctx, inclusiveDataSplitGateway, defaultConnector, connectorsExtractionDataGC,
                        forward_default_generic, isRootScope));
        NodeFactory.connectNodes(default_script_connector_node.first, default_script_connector_node.second, forward_default_generic, 0);
    }

    private void wireConnectorSourceWithNewJoinNodeForInstance(CompilerContext ctx, FrameNode currentFrameNode, boolean isRootScope,
            int branch, final SequenceConnector sequenceConnector, LocalSource connector_source, Node successorOfJoinNode) {
        // always a connector join with instance/frame
        if (isRootScope) {
            // connector.owner=instance
            Join connector_join = ctx.getJoinFactory().generateJoin(sequenceConnector, "connector_join_branch_" + Integer.toString(branch),
                    "0/0/0", "1/0/-1");
            NodeFactory.connectNodes(connector_source, 0, connector_join, 0);
            NodeFactory.connectNodes(ctx.getState().getInstanceSource(), 0, connector_join, 1);
            NodeFactory.connectNodes(connector_join, 0, successorOfJoinNode, 0);
        } else {
            // connector.frame=frame
            Join connector_join = ctx.getJoinFactory().generateJoin(sequenceConnector, "connector_join_branch_" + Integer.toString(branch),
                    "0/0/3", "1/0/-1");
            NodeFactory.connectNodes(connector_source, 0, connector_join, 0);
            NodeFactory.connectNodes(ctx.getSourceFactory().getSource4Class(currentFrameNode.getGalaxyClass()), 0, connector_join, 1);
            NodeFactory.connectNodes(connector_join, 0, successorOfJoinNode, 0);
        }
    }

    private final Target generateDeleteConnector0TokenWithHighPrio(final CompilerContext ctx) throws BPMNCompilerException {
        final Script script = new Script(ctx, ScriptName.BLACK_HOLE_HIGH_PRIO_TWO_PARAMS, null);
        final ScriptVariable varObject1 = script.addParameter(new ScriptVariable("object1"));
        final ScriptVariable varObject2 = script.addParameter(new ScriptVariable("object2"));
        script.generateDeleteCommand(varObject1);
        script.generateDeleteCommand(varObject2);
        return script.getTarget(1);
    }

    private final Target generateHighPrioBlackHole(final CompilerContext ctx) throws BPMNCompilerException {
        final Script script = new Script(ctx, ScriptName.BLACK_HOLE_HIGH_PRIO, null);
        final ScriptVariable varObject = script.addParameter(ScriptVariable.OBJECT);
        script.generateDeleteCommand(varObject);
        return script.getTarget(1);
    }

    private final Pair<Node, Integer> generateDefaultJoinCascade(final CompilerContext ctx, final List<ConstantFilter> connector_filters,
            final ModelElement modelElement, final int inboundEdgeTokenState) {
        // only one connector (beside of default connector) => connect directly to default script node
        if (connector_filters.size() == 1) {
            return new Pair<Node, Integer>(connector_filters.get(0), 1);
        }

        Join connector_join = ctx.getJoinFactory().generateJoin(modelElement, "inclusive_gw_default_join_cascade_0", "0/1/-1", "1/1/-1");
        NodeFactory.connectNodes(connector_filters.get(0), 1, connector_join, 0);
        NodeFactory.connectNodes(connector_filters.get(1), 1, connector_join, 1);

        for (int counter = 2; counter < connector_filters.size(); counter++) {
            final Join previous_connector_join = connector_join;
            connector_join = ctx.getJoinFactory().generateJoin(modelElement, "inclusive_gw_default_join_cascade_" + counter, "0/1/-1",
                    "1/1/-1");
            NodeFactory.connectNodes(previous_connector_join, 0, connector_join, 0);
            NodeFactory.connectNodes(connector_filters.get(counter), 1, connector_join, 1);
        }
        return new Pair<Node, Integer>(connector_join, 0);
    }

    private String generateInclSplitGWForwardHeader(CompilerContext ctx, ConditionalSequenceConnector connector,
            GalaxyClass connector_class, FrameNode currentFrame, boolean isRootScope) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                LocalCompilerConstants.TARGET_INCL_GW_SPLIT + "_forward", connector));
        sb.append(ScriptHelper.generateClassDeclaration(connector_class, new Variable(CompilerConstants.SCRIPT_VARIABLE_CONNECTOR)));
        sb.append(", ");
        if (isRootScope) {
            // instance
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_PARENT)));
        } else {
            // frame
            sb.append(ScriptHelper.generateClassDeclaration(currentFrame.getGalaxyClass(), new Variable(
                    CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        }
        sb.append(")");
        return sb.toString();
    }

    private String generateInclSplitGWForwardBody(CompilerContext ctx, InclusiveDataSplitGateway inclusiveDataSplitGateway,
            ConditionalSequenceConnector connector, Node target, boolean isRootScope) throws BPMNCompilerException {
        List<Variable> parameters = new ArrayList<Variable>(2);
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_CONNECTOR));
        final Variable instanceVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT);
        final Variable connectorVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_CONNECTOR);
        final Variable scopeVariable = isRootScope ? instanceVariable : new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME);
        parameters.add(scopeVariable);

        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_NO_CALLBACK, inclusiveDataSplitGateway, target, parameters));

        final Variable frameVariable;
        if (isRootScope) {
            frameVariable = null;
        } else {
            // instance = frame:parent
            frameVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME);
            sb.append(ScriptHelper.generateAssignCommand(instanceVariable, frameVariable, CompilerConstants.ATTRIBUTE_PARENT));
        }

        // token_new = new Token(instance, <default branch>);
        int nextLabel = ctx.getState().getTokenLabel(connector);
        final GalaxyClass tokenClass = ctx.getState().getTokenSource().getGalaxyClass();
        final Variable newTokenVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "_new");
        sb.append(ScriptHelper.generateNewCommand(newTokenVariable, tokenClass, instanceVariable, new IntegerLiteral(nextLabel),
                frameVariable));

        if (ctx.isPrincipalPropagationActive()) {
            final Variable oldTokenVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "_old");
            sb.append(ScriptHelper.generateAssignCommand(oldTokenVariable, connectorVariable, CompilerConstants.SCRIPT_VARIABLE_TOKEN));
            sb.append(ScriptHelper.generateInvocationCommand(null, newTokenVariable,
                    CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_TOKEN, oldTokenVariable));
        }

        // delete connector;
        sb.append(ScriptHelper.generateDeleteCommand(connectorVariable));

        sb.append("}");
        return sb.toString();
    }

    private String generateInlcSplitGWDefaultIHeader(CompilerContext ctx, SequenceConnector defaultConnector,
            List<Triple<String, LinkedHashSet<DataContainer>, GalaxyClass>> connectorsExtractionDataGC, FrameNode currentFrame,
            boolean isRootScope) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                LocalCompilerConstants.TARGET_INCL_GW_SPLIT + "_default", defaultConnector));
        int counter = 0;
        for (Triple<String, LinkedHashSet<DataContainer>, GalaxyClass> connectorData : connectorsExtractionDataGC) {
            final GalaxyClass connector_class = connectorData.third;
            if (counter > 0) {
                sb.append(",");
            }
            counter++;
            sb.append(ScriptHelper.generateClassDeclaration(connector_class, new Variable(CompilerConstants.SCRIPT_VARIABLE_CONNECTOR
                    + counter)));
            sb.append(",");
            if (isRootScope) {
                sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_PARENT + counter)));
            } else {
                sb.append(ScriptHelper.generateClassDeclaration(currentFrame.getGalaxyClass(), new Variable(
                        CompilerConstants.SCRIPT_VARIABLE_FRAME + counter)));
            }
        }
        sb.append(")");
        return sb.toString();
    }

    /**
     * Inclusive Split Gateway: create a token for the default connector
     */
    private String generateInclSplitGWDefaultIBody(CompilerContext ctx, InclusiveDataSplitGateway inclusiveDataSplitGateway,
            SequenceConnector defaultConnector, List<Triple<String, LinkedHashSet<DataContainer>, GalaxyClass>> connectorsExtractionDataGC,
            GenericOperator exec, boolean isRootScope) throws BPMNCompilerException {
        List<Variable> parameters = new ArrayList<Variable>(2);
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_CONNECTOR));

        final Variable instanceVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT + 1);
        final Variable scopeVariable = isRootScope ? instanceVariable : new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME);
        parameters.add(scopeVariable);
        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_NO_CALLBACK, inclusiveDataSplitGateway, exec, parameters));

        final Variable newTokenVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "_new");
        final Variable frameVariable;
        if (isRootScope) {
            frameVariable = null;
        } else {
            // instance = frame:parent
            frameVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME + 1);
            sb.append(ScriptHelper.generateAssignCommand(instanceVariable, frameVariable, CompilerConstants.ATTRIBUTE_PARENT));
        }

        // token_new = new Token(instance, <default branch>);
        int nextLabel = ctx.getState().getTokenLabel(defaultConnector);
        final GalaxyClass tokenClass = ctx.getState().getTokenSource().getGalaxyClass();
        sb.append(ScriptHelper.generateNewCommand(newTokenVariable, tokenClass, instanceVariable, new IntegerLiteral(nextLabel),
                frameVariable));

        if (ctx.isPrincipalPropagationActive()) {
            final Variable oldTokenVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN + "_old");
            sb.append(ScriptHelper.generateAssignCommand(oldTokenVariable, new Variable(CompilerConstants.SCRIPT_VARIABLE_CONNECTOR + "1"),
                    CompilerConstants.SCRIPT_VARIABLE_TOKEN));
            sb.append(ScriptHelper.generateInvocationCommand(null, newTokenVariable,
                    CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_TOKEN, oldTokenVariable));
        }

        for (int counter = 1; counter <= connectorsExtractionDataGC.size(); counter++) {
            // delete connector+$counter
            sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_CONNECTOR + counter)));
        }
        sb.append("}");
        return sb.toString();
    }

    private String generateInclSplitGWDefault0Header(CompilerContext ctx, SequenceConnector defaultConnector) {
        return generateSimpleScriptHeader(ctx, LocalCompilerConstants.TARGET_INCL_GW_SPLIT + "_default", defaultConnector);
    }

    /**
     * Inclusive Split Gateway: if there is only a single connector which is the default connector, we simply pass on the token
     */
    private String generateInclSplitGWDefault0Body(CompilerContext ctx, InclusiveDataSplitGateway inclusiveDataSplitGateway,
            SequenceConnector defaultConnector, Target target) throws BPMNCompilerException {
        List<Variable> parameters = new ArrayList<Variable>(2);
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN));
        parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));

        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, inclusiveDataSplitGateway, target, parameters));

        // token:state=next
        int nextLabel = ctx.getState().getTokenLabel(defaultConnector);
        sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN),
                CompilerConstants.ATTRIBUTE_STATE, new IntegerLiteral(nextLabel)));

        sb.append("}");
        return sb.toString();
    }

    private String generateInclSplitGWConnector0Header(CompilerContext ctx, InclusiveDataSplitGateway inclusiveDataSplitGateway,
            LinkedHashMap<String, DataContainer> joined_used_context, FrameNode currentFrame, boolean isRootScope) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(),
                LocalCompilerConstants.TARGET_INCL_GW_SPLIT + "_evaluate", inclusiveDataSplitGateway));
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getTokenSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        sb.append(", ");
        sb.append(ScriptHelper.generateClassDeclaration(ctx.getState().getInstanceSource().getGalaxyClass(), new Variable(
                CompilerConstants.SCRIPT_VARIABLE_PARENT)));

        for (DataContainer context_variable : joined_used_context.values()) {
            sb.append(",");
            sb.append(ScriptHelper.generateClassDeclaration(ctx.getContextHelper().getClassByDataObject(context_variable), new Variable(ctx
                    .getState().getContextVariableName(context_variable))));
        }
        sb.append(")");
        return sb.toString();
    }

    /**
     * Inclusive GW: first transition to delete the token and evaluate the first connector.
     */
    private String generateInclSplitGWConnector0Body(CompilerContext ctx, InclusiveDataSplitGateway inclusiveDataSplitGateway,
            List<Triple<String, LinkedHashSet<DataContainer>, GalaxyClass>> extractionsDataGC, Node target, boolean isRootScope,
            SequenceConnector connector0_connector, GalaxyClass connector0_class) throws BPMNCompilerException {
        List<Variable> parameters = new ArrayList<Variable>(2);
        Variable tokenVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN);
        parameters.add(tokenVariable);
        if (isRootScope) {
            parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT));
        } else {
            parameters.add(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME));
        }

        StringBuilder sb = new StringBuilder(ScriptHelper.generateBodyPrefix(ctx.getState().getExitClass(),
                CompilerConstants.BITMASK_ON_ACTIVATION, inclusiveDataSplitGateway, target, parameters));
        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), tokenVariable));

        if (!isRootScope) {
            // frame=token:frame
            sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), tokenVariable,
                    CompilerConstants.ATTRIBUTE_FRAME));
        }

        // new Connector_0(parent,token,true)
        sb.append(ScriptHelper.generateNewCommand(null, connector0_class, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT),
                tokenVariable, BooleanLiteral.TRUE, (isRootScope) ? NullLiteral.NULL
                        : new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));

        int counter = 0;
        for (final Triple<String, LinkedHashSet<DataContainer>, GalaxyClass> item : extractionsDataGC) {
            counter++;
            final String expression_id = item.first;
            final LinkedHashSet<DataContainer> used_context = item.second;
            final GalaxyClass galaxyClass = item.third;

            final Variable validVariable = new Variable(CompilerConstants.SCRIPT_VARIABLE_VALID + counter);
            // valid=...
            sb.append(ScriptHelper.generateExpressionCode(ctx, expression_id, used_context, null, validVariable,
                    ctx.getSimpleTypes().BOOLEAN));

            // new Connector_$counter(parent,token,valid)
            sb.append(ScriptHelper.generateNewCommand(null, galaxyClass, new Variable(CompilerConstants.SCRIPT_VARIABLE_PARENT),
                    tokenVariable, validVariable, (isRootScope) ? NullLiteral.NULL : new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
        }

        sb.append("}");
        return sb.toString();
    }
}
