package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.Collection;

import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Target;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerState;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventLogHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventTypeIds;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;

public class BlankEndEventRule extends BaseCompilerRule<EndEvent> implements CompilerRule<EndEvent> {

    public Class<EndEvent> getSupportedArtifact() {
        return EndEvent.class;
    }

    public void compile(EndEvent endEvent, CompilerContext ctx) throws BPMNCompilerException {
        CompilerState state = ctx.getState();
        Node tokenSwitch = state.getTokenSwitch();

        // create the target node and script
        Target target = generateBlankEndEventTransition(ctx, endEvent);

        // connect all incoming connectors to this target
        Collection<SequenceConnector> incomingConnectors = endEvent.getIncomingConnectors();
        for (SequenceConnector connector : incomingConnectors) {
            int tokenSwitchExit = state.getTokenSwitchExit(connector);
            NodeFactory.connectNodes(tokenSwitch, tokenSwitchExit, target, 0);
        }
    }

    private Target generateBlankEndEventTransition(CompilerContext ctx, EndEvent endEvent) throws BPMNCompilerException {
        AdvancedScript script = new AdvancedScript(ctx, ScriptName.END_EVENT_BLANK, endEvent);
        ScriptVariable varToken = script.addParameter(ScriptVariable.TOKEN, ctx.getState().getTokenClass());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());

        script.generateDebugCode(varInstance, varToken);
        script.generateScopeCode(varToken);

        // event logging for terminating end event
        if (!(endEvent.getScope() instanceof EmbeddedScope) && !ctx.isTaskFlow()) {
            ScriptVariable varKicker = script.generateAssignCommand(ScriptVariable.KICKER, varInstance,
                    CompilerConstants.SCRIPT_VARIABLE_KICKER);
            EventLogHelper.addEvent(script, ctx.getState().getEventLoggerClass(), EventTypeIds.END_TRIGGERED, ((Pool) ctx
                    .getRootScope()).refMofId(), varInstance, endEvent.refMofId(), varKicker);
        }

        if (endEvent.isTerminate()) {
            // terminating end events delete the instance
            script.generateDeleteCommand(varInstance);
        } else {
            Scope scope = endEvent.getScope();
            if (scope instanceof EmbeddedScope) {
                // set token state to output channel
                int nextLabel = ctx.getState().getTokenLabelFrameEnd(scope);
                script.generateUpdateCommand(varToken, "state", new IntegerLiteral(nextLabel));
            } else {
                // end event is in the root scope and just deletes the token
                script.generateDeleteCommand(varToken);
            }
        }

        return script.getTarget(getTransitionPriority(endEvent));
    }
}
