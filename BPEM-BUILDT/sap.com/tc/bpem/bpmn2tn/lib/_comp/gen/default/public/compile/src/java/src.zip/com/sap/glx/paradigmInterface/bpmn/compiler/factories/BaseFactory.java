package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import com.sap.tc.moin.repository.mmi.reflect.RefObject;

import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.Partitionable;

public abstract class BaseFactory {

	protected Subnet subnet;
    protected Connection connection;
	
	protected BaseFactory(Subnet subnet) {
		this.subnet = subnet;
		this.connection = ((Partitionable) subnet).get___Connection();
	}
	
	protected <T extends RefObject> T createElement(Class<T> clazz) {
    	return connection.createElement(clazz);
    }

}
