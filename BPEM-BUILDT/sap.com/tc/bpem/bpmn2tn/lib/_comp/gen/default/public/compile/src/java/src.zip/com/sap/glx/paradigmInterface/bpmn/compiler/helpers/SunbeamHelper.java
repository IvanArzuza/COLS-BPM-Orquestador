package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;

/**
 * <p>
 * The <code>SunbeamHelper</code> is used during compilation to collect all available message triggers and its related artifacts (e.g.
 * galaxy classes, intermediate message events, etc.) of a process model.
 * </p>
 * 
 * <p>
 * This information is stored in a so called {@link MesssageTriggerContext} that can be accessed in various ways via this helper.
 * </p>
 * 
 * <p>
 * Once all message triggers are collected make sure to invoke {@link #finishPreprocess()} to calculate a mapping between each intermediate
 * message event and its message trigger (context). Otherwise {@link #getMessageTriggerContext(IntermediateCatchEvent)} will not work, but
 * fail with an {@link IllegalStateException} instead.
 * </p>
 * 
 * @see #finishPreprocess()
 */
public class SunbeamHelper {

    Map<String, MessageTriggerContext> contexts = new HashMap<String, MessageTriggerContext>();
    Map<IntermediateCatchEvent, MessageTriggerContext> eventToMessageTriggerContext = null;

    /**
     * Retrieves a message trigger context by its trigger name, e.g. <code>sap.com/some/dc/with/a/trigger</code>.
     * 
     * @param qualifiedTriggerName
     *            not null
     * 
     * @return the message trigger context, might be null
     */
    public MessageTriggerContext getMessageTriggerContext(final String qualifiedTriggerName) {
        return contexts.get(qualifiedTriggerName);
    }

    /**
     * Adds a message trigger context to this helper.
     * 
     * Adding multiple contexts with the same qualified trigger name is not permitted and will result in an exception.
     * 
     * @param messageTriggerContext
     *            not null
     */
    public void addMessageTriggerContext(final MessageTriggerContext messageTriggerContext) {
        if (messageTriggerContext == null) {
            throw new NullPointerException("MessageTriggerContext must not be null.");
        }

        final String qualifiedTriggerName = messageTriggerContext.getQualifiedTriggerName();
        final MessageTriggerContext oldContext = contexts.put(qualifiedTriggerName, messageTriggerContext);
        if (oldContext != null) {
            throw new IllegalStateException(String.format(
                    "Message trigger context for trigger '%s' is already part of the sunbeam helper context.", qualifiedTriggerName));
        }
    }

    /**
     * Retrieves the message trigger context of one intermediate message event
     * 
     * @see #finishPreprocess()
     * 
     * @param intermediateMessageEvent
     *            not null
     * 
     * @return the message trigger context, might be null
     */
    public MessageTriggerContext getMessageTriggerContext(final IntermediateCatchEvent intermediateMessageEvent) {
        if (eventToMessageTriggerContext == null) {
            throw new IllegalStateException("Mapping not initialized. Invoke finishPreprocess() first.");
        }
        return eventToMessageTriggerContext.get(intermediateMessageEvent);
    }

    /**
     * @return all message trigger contexts known to this helper.
     */
    public Collection<MessageTriggerContext> getMessageTriggerContexts() {
        return Collections.unmodifiableCollection(contexts.values());
    }

    /**
     * Needs to be invoked after all message trigger contexts are collected in order to build up a mapping between each intermediate message
     * event and its message trigger (context).
     * 
     * @see #getMessageTriggerContext(IntermediateCatchEvent)
     */
    public void finishPreprocess() {
        eventToMessageTriggerContext = new HashMap<IntermediateCatchEvent, MessageTriggerContext>();

        for (final MessageTriggerContext messageTriggerContext : contexts.values()) {
            for (final IntermediateMessageEventContext intermediateMessageEventContext : messageTriggerContext
                    .getIntermediateMessageEventContexts()) {
                final IntermediateCatchEvent event = intermediateMessageEventContext.getIntermediateMessageEvent();
                final MessageTriggerContext oldContext = eventToMessageTriggerContext.put(event, messageTriggerContext);
                if (oldContext != null) {
                    throw new IllegalStateException(String.format("Found multiple message trigger contexts for the same event %s.", event
                            .getName()));
                }
            }
        }
    }

}
