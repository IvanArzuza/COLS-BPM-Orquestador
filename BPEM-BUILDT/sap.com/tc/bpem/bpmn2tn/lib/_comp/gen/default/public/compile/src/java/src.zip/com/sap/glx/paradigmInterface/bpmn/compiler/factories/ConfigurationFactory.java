package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.configuration.AdapterConfiguration;
import com.sap.glx.ide.model.configuration.ConfigurationString;
import com.sap.glx.ide.model.galaxy.processsupplements.ReportingActivity;
import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.task.TaskCategory;
import com.sap.glx.ide.model.galaxy.task.TaskCategoryEnum;
import com.sap.glx.ide.model.galaxy.task.UicomponentDefinition;
import com.sap.glx.ide.model.galaxy.task.Uiproperty;
import com.sap.glx.ide.model.galaxy.text.ModelElementNameText;
import com.sap.glx.ide.model.galaxy.text.ScopeDataElementDescText;
import com.sap.glx.ide.model.galaxy.text.ScopeDataElementNameText;
import com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity;
import com.sap.glx.ide.model.galaxy.workflow.CatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.CustomAction;
import com.sap.glx.ide.model.galaxy.workflow.CustomAttribute;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Event;
import com.sap.glx.ide.model.galaxy.workflow.EventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.HumanActivity;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.PoolReference;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeObject;
import com.sap.glx.ide.model.galaxy.workflow.SequenceConnector;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.AbstractVersioningCallback;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.AppendVersioningCallback;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.MessageTriggerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.SDOHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.util.IMoinUtils;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.glx.ui.rendering.UIComponentPropertyKeys;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReferenceTypeEnum;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdComplexTypeContent;
import com.sap.tc.esmp.mm.xsd1.XsdComplexTypeDefinition;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;
import com.sap.tc.esmp.mm.xsd1.XsdModelGroup;
import com.sap.tc.esmp.mm.xsd1.XsdParticle;
import com.sap.tc.esmp.mm.xsd1.XsdParticleContent;

public class ConfigurationFactory extends BaseFactory {

    private final static Pair<String, String> clsGenerator = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER,
            CompilerConstants.GALAXY_REPLICATOR);
    private final static String CONFIG_EMPTY = ""; //$NON-NLS-1$

    private final CompilerContext ctx;

    Map<String, AdapterConfiguration> adapter_configs = new HashMap<String, AdapterConfiguration>();

    public ConfigurationFactory(final Subnet subnet, final CompilerContext ctx) {
        super(subnet);
        this.ctx = ctx;
    }

    private Pair<AdapterConfiguration, ConfigurationString[]> generateConfiguration(final String adapter, final String... items) {
        // first find the right adapter configuration (by the adapter name)
        AdapterConfiguration config = adapter_configs.get(adapter);
        if (config == null) {
            config = connection.createElement(AdapterConfiguration.class);
            config.setAdapterName(adapter);
            subnet.getAdapterConfiguration().add(config);
            adapter_configs.put(adapter, config);
        }

        // then traverse down in the hierarchy as fast as possible
        Collection<ConfigurationString> root = config.getRoot();
        final ConfigurationString[] cascade = new ConfigurationString[items.length];
        int level;
        for (level = 0; level < items.length; level++) {
            boolean found = false;
            for (final ConfigurationString string : root) {
                if (string.getValue().equals(items[level])) {
                    root = string.getChild();
                    found = true;
                    cascade[level] = string;
                    break;
                }
            }

            if (!found) {
                break;
            }
        }

        // and create new config strings for the missing levels
        for (; level < items.length; level++) {
            final ConfigurationString string = connection.createElement(ConfigurationString.class);
            string.setValue(items[level]);
            root.add(string);
            cascade[level] = string;
            root = string.getChild();
        }

        return new Pair<AdapterConfiguration, ConfigurationString[]>(config, cascade);
    }

    private Pair<AdapterConfiguration, ConfigurationString[]> generateConfiguration(final GalaxyClass cls,
            final boolean with_class_versioning, final String... items) {
        final String[] class_items = new String[items.length + 1];
        class_items[0] = cls.getName();
        System.arraycopy(items, 0, class_items, 1, items.length);

        final Pair<AdapterConfiguration, ConfigurationString[]> config_cascade = generateConfiguration(cls.getAdapter(), class_items);

        // version the class name in the configuration tree
        if (with_class_versioning) {
            ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config_cascade.second[0]));
        }

        return config_cascade;
    }

    private Pair<AdapterConfiguration, ConfigurationString[]> generateConfiguration(final Pair<String, String> class_name,
            final boolean with_class_versioning, final String... items) {
        final String[] class_items = new String[items.length + 1];
        class_items[0] = class_name.second;
        System.arraycopy(items, 0, class_items, 1, items.length);

        final Pair<AdapterConfiguration, ConfigurationString[]> config_cascade = generateConfiguration(class_name.first, class_items);
        if (with_class_versioning) {
            ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config_cascade.second[0]));
        }

        return config_cascade;
    }

    private Pair<AdapterConfiguration, ConfigurationString[]> generateConfigurationProperty(final GalaxyClass cls, final String key,
            final String value) {
        return generateConfiguration(cls, true, key + '=' + value);
    }

    /**
     * Creates static metadata configuration for container classes:
     * 
     * <pre>
     * 	&lt;container class&gt;,MOF_ID=&lt;MOFID of DataContainer entity&gt;
     * 	&lt;container class&gt;,NAME=&lt;display name of DataContainer entity&gt;
     *  &lt;container class&gt;,FLAVOR=TASK &lt;in case of inner task flow data container&gt;
     * 	&lt;container class&gt;,VERSION=&lt;flow version id&gt;
     * 	&lt;container class&gt;,TYPE,ROOT_NAME=&lt;SDO type name&gt;
     * 	&lt;container class&gt;,TYPE,ROOT_URI=&lt;SDO type namespace&gt;
     * 	&lt;container class&gt;,ELEMENT,ROOT_NAME=&lt;XSD root element name&gt;
     * 	&lt;container class&gt;,ELEMENT,ROOT_URI=&lt;XSD root element namespace&gt;
     * 	&lt;container class&gt;,SCOPE=&lt;type scope version&gt;
     * </pre>
     * 
     * @param clsContainer
     *            is the GalaxyClass for the data container entity.
     * @param container
     *            is the data container model element.
     */
    public void generateDataContainerConfiguration(final GalaxyClass clsContainer, final DataContainer container) {
        // data container attributes
        generateConfigurationProperty(clsContainer, CompilerConstants.CONFIG_MOFID, container.refMofId());
        generateConfigurationProperty(clsContainer, CompilerConstants.CONFIG_NAME, container.getOriginalName());

        // flow attributes
        if (ctx.isTaskFlow()) {
            generateConfigurationProperty(clsContainer, CompilerConstants.CONFIG_FLAVOR, CompilerConstants.CONFIG_TASK);
        }
        ctx.getVersioningHelper().registerVersioningCallback(
                new AppendVersioningCallback(generateConfiguration(clsContainer, true, CompilerConstants.CONFIG_VERSION).second[1], '='));

        // scope id configuration
        final String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScopeOld(container), CompilerType.TYPECOMPILER);
        generateConfigurationProperty(clsContainer, CompilerConstants.CONFIG_SCOPE, scopeId);

        // we pass in the original XSD root element name (for XML rendering)
        final QName elementName = container.getXsdElementDeclaration().getReferencedElementDeclaration() == null ? new QName(container
                .getXsdElementDeclaration().getNamespace(), container.getXsdElementDeclaration().getName()) : new QName(container
                .getXsdElementDeclaration().getReferencedElementDeclaration().getNamespace(), container.getXsdElementDeclaration()
                .getReferencedElementDeclaration().getName());
        final QName typeName = SDOHelper.generateSDOName(WSDLHelper.getElementType(container.getXsdElementDeclaration()));
        generateConfiguration(clsContainer, true, CompilerConstants.CONFIG_TYPE, CompilerConstants.CONFIG_ROOT_NAME + '='
                + typeName.getLocalPart());
        generateConfiguration(clsContainer, true, CompilerConstants.CONFIG_TYPE, CompilerConstants.CONFIG_ROOT_URI + '='
                + typeName.getNamespaceURI());
        generateConfiguration(clsContainer, true, CompilerConstants.CONFIG_ELEMENT, CompilerConstants.CONFIG_ROOT_NAME + '='
                + elementName.getLocalPart());
        generateConfiguration(clsContainer, true, CompilerConstants.CONFIG_ELEMENT, CompilerConstants.CONFIG_ROOT_URI + '='
                + elementName.getNamespaceURI());
    }

    /**
     * Generates configuration information that for an event. This is either a start or intermediate event. For intermediate events of inner
     * task flows no configuration is generated since 7.20.
     * 
     * <pre>
     *        &lt;event class&gt;,VERSION=&lt;flow version&gt;
     *        &lt;event class&gt;,SERVICE=&lt;service identifier&gt;
     *        &lt;event class&gt;,METHOD=&lt;operation name&gt;
     *        &lt;event class&gt;,SCOPE=&lt;type scope identifier&gt;
     *        &lt;event class&gt;,URL=&lt;WS provisioning url&gt;
     *        &lt;event class&gt;,ALIAS,&lt;MOF_ID&gt;,TYPE=START|INTERMEDIATE;
     * </pre>
     * 
     * @param clsEvent
     *            galaxy class for the event
     * @param event
     *            BPMN event (must be either a start or intermediate event with a message trigger
     * @param bpmnService
     *            service identifier for the BPMN adapter
     * @param operation
     *            used by the message event definition of the catch event
     * @throws BPMNCompilerException
     */
    public void generateEventConfiguration(final GalaxyClass clsEvent, final CatchEvent event, final String bpmnService,
            final Operation operation) throws BPMNCompilerException {
        ctx.getVersioningHelper().registerVersioningCallback(
                new AppendVersioningCallback(generateConfiguration(clsEvent, true, CompilerConstants.CONFIG_VERSION).second[1], '='));
        generateConfiguration(clsEvent, true, CompilerConstants.CONFIG_SERVICE + '=' + bpmnService);
        generateConfiguration(clsEvent, true, CompilerConstants.CONFIG_METHOD + '=' + operation.getName());
        final String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(operation), CompilerType.TYPECOMPILER);
        generateConfiguration(clsEvent, true, CompilerConstants.CONFIG_SCOPE + '=' + scopeId);
        if (!ctx.isTaskFlow()) {
            generateConfiguration(clsEvent, true, CompilerConstants.CONFIG_URL + '=' + OperationHelper.getEndpointUrl(ctx, event));
        }
        generateEventConfigurationAddition(clsEvent, event);
    }

    public void generateCorrelationKeyConfiguration(final MessageTriggerContext messageTriggerContext) {
        final String endpointId = messageTriggerContext.getEndpointId();
        final GalaxyClass correlationKeyClass = messageTriggerContext.getCorrelationKeyClass();
        final String correlationTriggerClassName = messageTriggerContext.getCorrelationTriggerClass().getName();

        generateConfigurationForCorrelationKeyOrSubscription(correlationKeyClass, endpointId, correlationTriggerClassName,
                messageTriggerContext.getCorrelationConditionConfigurationForCorrelationKey(), null);

        String qualityOfService = null;
        if (messageTriggerContext.isConditionalStartEndpoint()) {
            qualityOfService = CompilerConstants.CONFIG_QOS_PROPERTY_CONDITIONAL_START;

            final String conditionalStarterClassName = messageTriggerContext.getConditionalStarterClass().getName();
            final Pair<AdapterConfiguration, ConfigurationString[]> config = generateConfiguration(correlationKeyClass, true,
                    CompilerConstants.CONFIG_CORRELATION_STARTER_CLASS + "=" + conditionalStarterClassName);
            ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config.second[1], "_"));

            generateConfiguration(correlationKeyClass, true, CompilerConstants.CONFIG_CORRELATION_PROCESS_DEFINITION_ID + "="
                    + ctx.getRootScope().refMofId());
        } else {
            qualityOfService = CompilerConstants.CONFIG_QOS_PROPERTY_STANDARD;
        }
        generateConfiguration(correlationKeyClass, true, CompilerConstants.CONFIG_QUALITY_OF_SERVICE + "=" + qualityOfService);
    }

    public void generateSubscriptionConfiguration(final GalaxyClass subscription, final String endpointId,
            final String correlationTriggerClassName, final String correlationConditionConfiguration, final String fingerprintConfiguration) {
        ctx.getVersioningHelper().registerVersioningCallback(
                new AppendVersioningCallback(generateConfiguration(subscription, true, CompilerConstants.CONFIG_VERSION).second[1], '='));

        generateConfigurationForCorrelationKeyOrSubscription(subscription, endpointId, correlationTriggerClassName,
                correlationConditionConfiguration, fingerprintConfiguration);
    }

    public void generateSubscriptionConfigurationPerIntermediateMessageEvent(final GalaxyClass subscription,
            final IntermediateCatchEvent interMediateMessageEvent) {
        final String mofId = interMediateMessageEvent.get___Mri().getMofId();
        final ModelElementNameText name = interMediateMessageEvent.getName();
        final String originalText = interMediateMessageEvent.getOriginalName();
        final String textId = ToolUtils.getInstance().getTextId(name);

        generateConfiguration(subscription, true, "IME", mofId, "TEXT_ID=" + textId);
        generateConfiguration(subscription, true, "IME", mofId, "ORIG_NAME=" + originalText);
    }

    private void generateConfigurationForCorrelationKeyOrSubscription(final GalaxyClass theClass, final String endpointId,
            final String correlationTriggerClassName, final String correlationConditionConfiguration, final String fingerprintConfiguration) {
        generateConfiguration(theClass, true, CompilerConstants.CONFIG_CORRELATION_ENDPOINT_ID + "=" + endpointId);
        generateConfiguration(theClass, true, CompilerConstants.CONFIG_CORRELATION_CONDITION + "=" + correlationConditionConfiguration);
        if (fingerprintConfiguration != null) {
            // TODO: add to CompilerConstants
            generateConfiguration(theClass, true, "FP_IDX" + "=" + fingerprintConfiguration);
        }
        final Pair<AdapterConfiguration, ConfigurationString[]> config = generateConfiguration(theClass, true,
                CompilerConstants.CONFIG_CORRELATION_TRIGGER_CLASS + "=" + correlationTriggerClassName);
        ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config.second[1], "_"));
    }

    public void generateResendRequestConfiguration(final GalaxyClass resendRequest) {
        generateConfiguration(resendRequest, true, CompilerConstants.CONFIG_RESENDREQUEST_PROCESS_DEFINITION_ID + "="
                + ctx.getRootScope().refMofId());
    }

    /**
     * Generates configuration information for additional BPMN events using the same galaxy class. In order to generate a valid
     * configuration only additional events can use this method. For the first event the method
     * {@link #generateEventConfiguration(GalaxyClass, Event, Pair)} must be used.
     * 
     * <pre>
     *        &lt;event class&gt;,ALIAS,&lt;MOF_ID&gt;,TYPE=START|INTERMEDIATE;
     * </pre>
     * 
     * @param clsEvent
     *            galaxy class for the event.
     * @param endpoint
     *            endpoint of the event.
     * @param event
     *            BPMN event (must be either a start or intermediate event with a message trigger.
     * @throws BPMNCompilerException
     */
    public void generateEventConfigurationAddition(final GalaxyClass clsEvent, final CatchEvent event) {
        if (event instanceof StartEvent) {
            generateConfiguration(clsEvent, true, CompilerConstants.CONFIG_ALIAS, event.refMofId(), CompilerConstants.CONFIG_TYPE + '='
                    + CompilerConstants.CONFIG_START);
        }
        if (event instanceof IntermediateCatchEvent) {
            generateIntermediateEventConfigurationAddition(clsEvent, event);
        }
    }

    public void generateIntermediateEventConfigurationAddition(final GalaxyClass clsEvent, final CatchEvent event) {
        generateConfiguration(clsEvent, true, CompilerConstants.CONFIG_ALIAS, event.refMofId(), CompilerConstants.CONFIG_TYPE + '='
                + CompilerConstants.CONFIG_INTERMEDIATE);
    }

    /**
     * Provides the token label for each connector.
     * 
     * <pre>
     * 	&lt;token class&gt;,LABELS,CONNECTOR,&lt;connector mofid&gt;=&lt;integer token state&gt;
     * </pre>
     * 
     * @param token_class
     *            is the token class this connector label refers to.
     * @param connector
     *            is the connector model entity (flow metamodel).
     * @param label
     *            is the integer label (=token state) that corresponds to this connector.
     */
    public void generateConnectorConfiguration(final GalaxyClass token_class, final SequenceConnector connector, final int label) {

        final String connectorModelId = connector.refMofId();

        generateConfiguration(token_class, true, CompilerConstants.CONFIG_LABELS, CompilerConstants.CONFIG_CONNECTOR, connectorModelId
                + "=" //$NON-NLS-1$
                + Integer.toString(label));

        final ScopeObject connectorTarget = connector.getTarget();

        if (connectorTarget instanceof ReportingActivity || connectorTarget instanceof AutomatedActivity
                || connectorTarget instanceof EndEvent) {
            final String connectorTargetModelId = connectorTarget.refMofId();

            generateConfiguration(token_class, true, CompilerConstants.CONFIG_LABELS, CompilerConstants.CONFIG_CONNECTOR,
                    CompilerConstants.CONFIG_CONNECTOR_TARGET, connectorTargetModelId + "=" //$NON-NLS-1$
                            + Integer.toString(label));
        }
    }

    /**
     * Provides the token label for each subflow (aka workflow reference).
     * 
     * <pre>
     * 	&lt;token class&gt;,LABELS,SUBFLOW,&lt;workflow reference MOFID&gt;=&lt;integer token state&gt;
     * </pre>
     * 
     * @param token_class
     *            is the token class this subflow label refers to.
     * @param subflow
     *            is the workflow reference entity (flow metamodel)
     * @param label
     *            is the integer label (=token state) that corresponds to this subflow.
     */
    public void generateSubflowConfiguration(final GalaxyClass token_class, final PoolReference subflow, final int label) {
        generateConfiguration(token_class, true, CompilerConstants.CONFIG_LABELS, CompilerConstants.CONFIG_SUBFLOW, subflow.refMofId()
                + "=" //$NON-NLS-1$
                + Integer.toString(label));
    }

    /**
     * Provides the token label for each human activity. TODO: shouldn't we think of a separate category aside from SUBFLOW (e.g., TASK)
     * 
     * <pre>
     * 	&lt;token class&gt;,LABELS,TASK,&lt;human activity MOFID&gt;,&lt;integer token state&gt;
     * </pre>
     * 
     * @param token_class
     *            is the token class this human activity label refers to.
     * @param activity
     *            is the human activity entity (flow metamodel).
     * @param label
     *            is the integer label (=token state) that corresponds to this human activity.
     */
    public void generateHumanActivityConfiguration(final GalaxyClass token_class, final HumanActivity activity, final int label) {
        generateConfiguration(token_class, true, CompilerConstants.CONFIG_LABELS, CompilerConstants.CONFIG_TASK, activity.refMofId() + "="
                + Integer.toString(label));

    }

    /**
     * Correlates the root scope MOFID, version, and display name with the associated instance class.
     * 
     * <pre>
     * 	&lt;instance class&gt;,ROOT,MOFID=&lt;root scope MOFID&gt;
     * 	&lt;instance class&gt;,ROOT,VERSION=&lt;flow version&gt;
     * 	&lt;instance class&gt;,ROOT,NAME=&lt;display name of the root scope&gt;
     *  &lt;instance class&gt;,FLAVOR={TASK|WORKFLOW}
     *  &lt;instance class&gt;,COMPILER=compiler timestamp
     * </pre>
     * 
     * @param instance_class
     *            is the "Instance*" GalaxyClass
     * @param scope
     *            is the root scope this "Instance*" class was generated for.
     */
    public void generateWorkflowConfiguration(final GalaxyClass instance_class, final Scope scope) {
        generateConfiguration(instance_class, true, CompilerConstants.CONFIG_WORKFLOW, CompilerConstants.CONFIG_MOFID
                + "=" + scope.refMofId()); //$NON-NLS-1$

        generateConfiguration(instance_class, true, CompilerConstants.CONFIG_ROOT, CompilerConstants.CONFIG_MOFID + "=" + scope.refMofId()); //$NON-NLS-1$
        generateConfiguration(instance_class, true, CompilerConstants.CONFIG_ROOT, CompilerConstants.CONFIG_NAME
                + "=" + scope.getOriginalName()); //$NON-NLS-1$

        ctx.getVersioningHelper().registerVersioningCallback(
                new AppendVersioningCallback(generateConfiguration(instance_class, true, CompilerConstants.CONFIG_ROOT,
                        CompilerConstants.CONFIG_VERSION).second[2], '='));

        if (ctx.isTaskFlow()) {
            generateConfiguration(instance_class, true, CompilerConstants.CONFIG_FLAVOR + "=" + CompilerConstants.CONFIG_TASK);//$NON-NLS-1$
        } else {
            final String visualization = ctx.getHost().getVersionId(ctx.getTopLevelEntity(), CompilerType.DIAGRAMTOXMLCONVERTER);
            generateConfiguration(instance_class, true, CompilerConstants.CONFIG_WORKFLOW, CompilerConstants.CONFIG_VISUALIZATION
                    + "=" + visualization);//$NON-NLS-1$
            generateConfiguration(instance_class, true, CompilerConstants.CONFIG_FLAVOR + "=" + CompilerConstants.CONFIG_WORKFLOW);//$NON-NLS-1$
        }
    }

    /**
     * New stuff (foreign key to type scope, only):
     * 
     * <pre>
     *  &lt;scope class&gt;,SCOPE=&lt;scope version as generated by type compiler&gt;
     * </pre>
     * 
     * @param scope_class
     *            is the anchoring GalaxyClass for this scope
     */
    public void generateScopeConfiguration(final Iterable<XsdElementDeclaration> scope) throws BPMNCompilerException {
        final GalaxyClass scope_class = ctx.getDependencyHelper().getScopeClassOld(scope);

        generateConfiguration(scope_class, true, CompilerConstants.CONFIG_SCOPE + "="
                + ctx.getHost().getVersionId(scope, CompilerType.TYPECOMPILER));

    }

    /**
     * Configuration for WS consumption. Essentially covers WSDAS API requirements to call a web service.
     * 
     * <pre>
     *  &lt;call class&gt;,Style={RPC|DOC}
     *  &lt;call class&gt;,LogicalDestination=&lt;logical destination name as defined in NW destination service&gt;
     *  &lt;call class&gt;,InterfaceName=&lt;WSDL1.1 portType name&gt;
     *  &lt;call class&gt;,InterfaceNameSpace=&lt;WSDL1.1 portType ns&gt;
     *  &lt;call class&gt;,OperationName=&lt;WSDL operation name&gt;
     * </pre>
     * 
     * Optional part:
     * 
     * <pre>
     *  &lt;call class&gt;,&lt;fault name&gt;=&lt;exception version&gt;
     *  ...
     * </pre>
     * 
     * @param call_class
     *            is the "Call" GalaxyClass
     * @param activity
     *            is the automated activity (flow metamodel entity).
     */
    public void generateCallConfiguration(final CompilerContext ctx, final GalaxyClass call_class, final AutomatedActivity activity)
            throws BPMNCompilerException {

        if (activity.getServiceReference() != null) {
            final String applicationName = ctx.getHost().getApplicationName(activity.getServiceReference());
            final String serviceReference = activity.getServiceReference().getId();
            final String connectivityType = activity.getServiceReference().getBindingType();
            if (ctx.isMicrobusEnabled()) {
                // microbus configuration
                generateConfiguration(call_class, true, CompilerConstants.CONFIG_FLAVOR + "=" + CompilerConstants.CONFIG_SCA_CONFIGURATION);
                generateConfiguration(call_class, true, "ApplicationName=" + applicationName);
                final String componentName = ctx.getHost().getApplicationName() + "/BPMcomponent";
                generateConfiguration(call_class, true, "ComponentName=" + componentName.replace('/', '~'));
                generateConfiguration(call_class, true, "ReferenceName=" + serviceReference);
            } else {
                // the old mass configuration
                if (ServiceReferenceTypeEnum.WS.equals(activity.getServiceReference().getType())) {
                    generateConfiguration(call_class, true, CompilerConstants.CONFIG_FLAVOR + "="
                            + CompilerConstants.CONFIG_MASS_CONFIGURATION);
                    generateConfiguration(call_class, true, "ApplicationName=" + applicationName);
                    generateConfiguration(call_class, true, "ServiceReferenceId=" + serviceReference);
                } else {
                    throw ctx
                            .getValidator()
                            .error(
                                    "An EhP1 development component does not support the use of the service reference of type RFC '%s' on the automated activity '%s'.",
                                    "BPM.rt_c_bpmn.000000", activity.getServiceReference().getId(), activity.getOriginalName());
                }
            }
            generateConfiguration(call_class, true, "ConnectivityType=" + connectivityType);
        } else {
            // configuration with logical destination
            generateConfiguration(call_class, true, CompilerConstants.CONFIG_FLAVOR + "=" + CompilerConstants.CONFIG_LOGICAL_DESTINATION);
            generateConfiguration(call_class, true, "LogicalDestination=" + activity.getLogicalDestination());
        }

        // get operation and its style
        final Operation operation = activity.getOperation();
        final boolean isRPC = WSDLHelper.isRpcStyle(operation);

        // generate operation-specific configuration
        if (isRPC) {
            generateConfiguration(call_class, true, "Style=ARPC");
        } else {
            generateConfiguration(call_class, true, "Style=DOC");
        }
        generateConfiguration(call_class, true, "InterfaceName=" + operation.getServiceInterface().getName());
        generateConfiguration(call_class, true, "InterfaceNameSpace=" + operation.getServiceInterface().getNamespace());
        generateConfiguration(call_class, true, "OperationName=" + operation.getName());

        // generate fault-specific configuration
        if (activity.getEventDefinitions() != null) {
            for (final EventDefinition event_definition : activity.getEventDefinitions()) {
                if (event_definition instanceof ErrorEventDefinition) {
                    final ErrorEventDefinition exception = (ErrorEventDefinition) event_definition;
                    if (exception.getWsdlFault() != null) {
                        generateConfiguration(call_class, true, "Faults", exception.getWsdlFault().getName() + "="
                                + ctx.getHost().getVersionId(exception, CompilerType.EXCEPTIONCOMPILER));
                    }
                }
            }
        }
    }

    /**
     * Generates the technical configuration for task management (as agreed on with HIM).
     * 
     * <pre>
     * 	&lt;task class&gt;,category=&lt;task category&gt;
     * 	&lt;task class&gt;,subject=&lt;task subject text id&gt;
     * 	&lt;task class&gt;,name=&lt;task name text id&gt;
     * 	&lt;task class&gt;,description=&lt;task description text id&gt;
     * 	&lt;task class&gt;,COMPONENT_&lt;component MOFID&gt;,type=&lt;component type&gt;
     * 	&lt;task class&gt;,COMPONENT_&lt;component MOFID&gt;,isMaster={true|false}
     * 	&lt;task class&gt;,COMPONENT_&lt;component MOFID&gt;,usage=&lt;component usage&gt;
     * 	&lt;task class&gt;,COMPONENT_&lt;component MOFID&gt;,PART_&lt;part MOFID&gt;,name=&lt;part name&gt;
     * 	&lt;task class&gt;,COMPONENT_&lt;component MOFID&gt;,PART_&lt;part MOFID&gt;,value=&lt;part value&gt;
     *  &lt;task class&gt;,VERSION=&lt;flow version id&gt;
     *  &lt;task class&gt;,MOF_ID=&lt;task MOFID&gt;
     * </pre>
     * 
     * @param clsTask
     *            the galaxy class for the task adapter.
     * @param task
     *            the BPMN task object.
     * @param endpoint
     *            service interface, required to check the attached error event definitions.
     */
    public void generateTaskConfiguration(final GalaxyClass clsTask, final Task task, final MessageEventDefinition endpoint)
            throws BPMNCompilerException {
        final IMoinUtils mu = ToolUtils.getInstance();
        generateConfiguration(clsTask, true, "category=" + task.getCategory().toString()); //$NON-NLS-1$
        generateConfiguration(clsTask, true, "subject=" + mu.getTextId(task.getSubject())); //$NON-NLS-1$
        generateConfiguration(clsTask, true, "name=" + mu.getTextId(task.getName())); //$NON-NLS-1$
        generateConfiguration(clsTask, true, "description=" + mu.getTextId(task.getDescription())); //$NON-NLS-1$
        generateConfiguration(clsTask, true, "sharable=" + task.isSharable()); //$NON-NLS-1$

        // $Subtasking
        // moved javadoc
        /*
         * <b>Note:</b> The configurations starting with "DATAOBJECT_" are currently only generated for the subtask definition. It is
         * subject to future enhancements to introduce a metamodel flag allowing a developer to mark a task as subtask definition.
         */
        /*
         * &lt;task class&gt;,sharable=&lt;task sharable attribute id&gt; &lt;task class&gt;,DATAOBJECT_&lt;data object
         * MOFID&gt;,scope=&lt;data object scope id&gt; &lt;task class&gt;,DATAOBJECT_&lt;data object MOFID&gt;,name=&lt;data object name
         * text&gt; &lt;task class&gt;,DATAOBJECT_&lt;data object MOFID&gt;,ROOT_URI=&lt;data object root xsd namespace&gt; &lt;task
         * class&gt;,DATAOBJECT_&lt;data object MOFID&gt;,ROOT_NAME=&lt;data object root xsd name&gt;
         */
        // in 7.31, the following fragment is only generated for the subtask
        // definition. In future releases this should be generalised by
        // usage of a a meta model flag
        /*
         * if(task.getOriginalName().equalsIgnoreCase("Subtask") && //$NON-NLS-1$ ctx.getHost().getApplicationName(task).equalsIgnoreCase(
         * "sap.com/tc~bpem~content~predefs~internal")) { //$NON-NLS-1$ for(ScopeObject scope: task.getScopeObjects()) { if(scope instanceof
         * DataContainer) { DataContainer dataObject =(DataContainer)scope; String mofId = dataObject.refMofId();
         * Iterable<XsdElementDeclaration> xsd=ctx.getDependencyHelper().getScopeOld(dataObject); generateConfiguration(clsTask, true,
         * "DATAOBJECT_" + mofId, CompilerConstants.CONFIG_SCOPE + "=" + ctx.getHost().getVersionId(xsd,
         * CompilerType.TYPECOMPILER));//$NON-NLS-1$ //$NON-NLS-2$ generateConfiguration(clsTask, true, "DATAOBJECT_" + mofId,
         * CompilerConstants.CONFIG_NAME + "=" + dataObject.getOriginalName());//$NON-NLS-1$ //$NON-NLS-2$
         * 
         * XsdTypeDefinition xsdType = dataObject.getXsdElementDeclaration().getTypeDefinition(); generateConfiguration(clsTask, true,
         * "DATAOBJECT_" + mofId, CompilerConstants.CONFIG_ROOT_URI + "=" + xsdType.getNamespace());//$NON-NLS-1$ //$NON-NLS-2$
         * generateConfiguration(clsTask, true, "DATAOBJECT_" + mofId, CompilerConstants.CONFIG_ROOT_NAME + "=" +
         * xsdType.getName());//$NON-NLS-1$ //$NON-NLS-2$
         * 
         * } } }
         */

        ctx.getVersioningHelper().registerVersioningCallback(
                new AppendVersioningCallback(generateConfiguration(clsTask, true, CompilerConstants.CONFIG_VERSION).second[1], '='));
        generateConfiguration(clsTask, true, CompilerConstants.CONFIG_MOFID + '=' + task.refMofId());

        final String DC_VENDOR_NAME = "glx.ui.dc.vendor.name"; //$NON-NLS-1$
        final String DC_NAME = "glx.ui.dc.name"; //$NON-NLS-1$

        for (final UicomponentDefinition component : task.getUiComponentDefinitions()) {
            final String componentId = component.refMofId();
            generateConfiguration(clsTask, true, "COMPONENT_" + componentId, "type=" + component.getType().toString()); //$NON-NLS-1$ //$NON-NLS-2$
            generateConfiguration(clsTask, true, "COMPONENT_" + componentId, "isMaster=" + Boolean.toString(component.isMaster())); //$NON-NLS-1$ //$NON-NLS-2$
            generateConfiguration(clsTask, true, "COMPONENT_" + componentId, "usage=" + component.getUsage().toString()); //$NON-NLS-1$ //$NON-NLS-2$

            String vendorName = null;
            String dcName = null;

            final Collection<Uiproperty> propertyBag = component.getDefinitionParts();
            fillPropertyBagWithExceptions(task, propertyBag, endpoint);

            for (final Uiproperty property : propertyBag) {
                // copy the property bag to the task configuration
                generateConfiguration(clsTask, true,
                        "COMPONENT_" + componentId, "PART_" + property.refMofId(), "name=" + property.getName()); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                generateConfiguration(clsTask, true,
                        "COMPONENT_" + componentId, "PART_" + property.refMofId(), "value=" + property.getValue()); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$

                // keep the vendorName and dcName for subsequent DC dependency
                // check
                if (property.getName().equals(DC_VENDOR_NAME)) {
                    vendorName = property.getValue();
                } else if (property.getName().equals(DC_NAME)) {
                    dcName = property.getValue();
                }
            }

            // validation of the DC dependencies
            checkDcDependency(task, vendorName, dcName);
        }
        generateForCustomAttributes(clsTask, task);
        generateForCustomActions(clsTask, task);
    }
    
    /**
     * Helper method to generate structure configuration for custom attributes.
     * Elements with in the XSD is iterated and new configuration are generated.
     * Attribute's name, label and type are taken as structure configurations.
     * Sample generated configuration which are name value pairs looks like below.
     *       CUSTOM_ATTRIBUTE_0  attribute_name=First                    
     *       CUSTOM_ATTRIBUTE_0  attribute_type=boolean                  
     *       CUSTOM_ATTRIBUTE_0  attribute_label=34f35a4600693044b12677acbf2b9500                    
     *       CUSTOM_ATTRIBUTE_1  attribute_name=Second                   
     *       CUSTOM_ATTRIBUTE_1  attribute_type=date                 
     *       CUSTOM_ATTRIBUTE_1  attribute_label=cae70ce5bf8e32b998896b57487a65b9
     * @param clsTask
     *         Galaxy Class
     * @param task
     *          Task scope object
     */
    private void generateForCustomAttributes(final GalaxyClass clsTask, final Task task) {
        for (ScopeObject scope : task.getScopeObjects()) {
            if (scope instanceof DataContainer) {
                final DataContainer dataObject = (DataContainer) scope;
                if (dataObject.getOriginalName().equals(CompilerConstants.CUSTOM_ATTRIBUTES)) {
                    CustomAttribute customAttribute = (CustomAttribute) dataObject;
                    String mofId = dataObject.refMofId();

                    final List<XsdParticle> contents = getXsdContent(dataObject);
                    if (contents == null || contents.isEmpty()) {
                        return;
                    }
                    String doMofString = CompilerConstants.CONFIG_DATA_OBJECT + mofId;
                    generateConfiguration(clsTask, true, doMofString,
                            CompilerConstants.CONFIG_DATA_OBJECT_TYPE + "=" + dataObject.getOriginalName()); //$NON-NLS-1$

                    final ToolUtils toolUtils = ToolUtils.getInstance();
                    final List<ScopeDataElementNameText> attributeLabels = customAttribute.getAttributeLabels();
                    int index = 0;
                    for (XsdParticle particle : contents) {
                        XsdParticleContent particleContent = particle.getContent();
                        XsdElementDeclaration elemDecl = (XsdElementDeclaration) particleContent;
                        if (elemDecl == null) {
                            continue;
                        }
                        String attributeName = elemDecl.getName();
                        String attributeType = elemDecl.getTypeDefinition().getName();
                        String attributeLabelTextId = ""; //$NON-NLS-1$
                        if (attributeLabels != null && !attributeLabels.isEmpty() && attributeLabels.size() > index) {
                            ScopeDataElementNameText attributeLabelElement = attributeLabels.get(index);
                            if (attributeLabelElement != null) {
                                attributeLabelTextId = toolUtils.getTextId(attributeLabelElement);
                            } 
                        }
                        String doIndexString = CompilerConstants.CONFIG_DATA_OBJECT_CA + index;

                        generateConfiguration(clsTask, true, doMofString, doIndexString, CompilerConstants.CONFIG_DATA_OBJECT_CA_NAME
                                + "=" + attributeName); //$NON-NLS-1$ 
                        generateConfiguration(clsTask, true, doMofString, doIndexString, CompilerConstants.CONFIG_DATA_OBJECT_CA_TYPE
                                + "=" + attributeType); //$NON-NLS-1$ 
                        generateConfiguration(clsTask, true, doMofString, doIndexString, CompilerConstants.CONFIG_DATA_OBJECT_CA_LABEL
                                + "=" + attributeLabelTextId); //$NON-NLS-1$
						generateConfiguration(clsTask, true, doMofString, doIndexString, CompilerConstants.CONFIG_DATA_OBJECT_CA_INDEX
                                + "=" + index); //$NON-NLS-1$
                        index++;
                    }
                }
            }
        }
    }

    /**
     * Helper method to generate structure configuration for custom actions.
     * Elements with in the XSD is iterated and new configuration are generated.
     * Action's name, label and description are taken as structured configuration
     * The last part of the structured configuration object's name (after the last _)
     * is taken as action index and is used for ordering.
     * Sample generated configuration which are name value pairs looks like below.
     *       CUSTOM_ACTION_0  action_name=Action0                    
     *       CUSTOM_ACTION_0  action_label=34f35a4600693044b12677acbf2b9500                  
     *       CUSTOM_ACTION_0  action_description=34f35a4600693044b12677acbf2b9500                    
     *       CUSTOM_ACTION_0  action_name=Action1                    
     *       CUSTOM_ACTION_0  action_label=34f35a4600693044b12677acbf2b9500                  
     *       CUSTOM_ACTION_0  action_description=34f35a4600693044b12677acbf2b9500
     * @param clsTask
     *         Galaxy Class
     * @param task
     *          Task scope object
     */
    private void generateForCustomActions(final GalaxyClass clsTask, final Task task) {
    	for (ScopeObject taskObject : task.getScopeObjects()) {
            if (taskObject instanceof CustomAction) {
            	final CustomAction customAction = (CustomAction) taskObject;
                if (customAction.getOriginalName().equals(CompilerConstants.CUSTOM_ACTIONS)) {  //$NON-NLS-1$
                    String mofId = customAction.refMofId();

                    final List<XsdParticle> contents = getXsdContent(customAction);
                    if (contents == null || contents.isEmpty()) {
                        return;
                    }
                    String doMofString = CompilerConstants.CONFIG_DATA_OBJECT + mofId;
                    generateConfiguration(clsTask, true, doMofString,
                            CompilerConstants.CONFIG_DATA_OBJECT_TYPE + "=" + customAction.getOriginalName()); //$NON-NLS-1$

                    final ToolUtils toolUtils = ToolUtils.getInstance();
                    final List<ScopeDataElementNameText> actionLabels = customAction.getActionLabels();
                    final List<ScopeDataElementDescText> actionDescriptions = customAction.getActionDescriptions();
                    int index = 0;
                    for (XsdParticle particle : contents) {
                        XsdParticleContent particleContent = particle.getContent();
                        XsdElementDeclaration elemDecl = (XsdElementDeclaration) particleContent;
                        if (elemDecl == null) {
                            continue;
                        }
                        String customActionName = elemDecl.getName();
                        
                        String customActionLabelTextId = ""; //$NON-NLS-1$
                        if (actionLabels != null && !actionLabels.isEmpty() && actionLabels.size() > index) {
                            ScopeDataElementNameText customActionLabelElement = actionLabels.get(index);
                            if (customActionLabelElement != null) {
                                customActionLabelTextId = toolUtils.getTextId(customActionLabelElement);
                            } 
                        }
                        
                        String customActionDescriptionTextId = ""; //$NON-NLS-1$
                        if (actionDescriptions != null && !actionDescriptions.isEmpty() && actionDescriptions.size() > index) {
                            ScopeDataElementDescText customActionDescriptionElement = actionDescriptions.get(index);
                            if (customActionDescriptionElement != null) {
                                customActionDescriptionTextId = toolUtils.getTextId(customActionDescriptionElement);
                            } 
                        }
                        
                        String doIndexString = CompilerConstants.CONFIG_DATA_OBJECT_CACT + index;

                        generateConfiguration(clsTask, true, doMofString, doIndexString, CompilerConstants.CONFIG_DATA_OBJECT_CACT_NAME
                                + "=" + customActionName); //$NON-NLS-1$ 
                        generateConfiguration(clsTask, true, doMofString, doIndexString, CompilerConstants.CONFIG_DATA_OBJECT_CACT_LABEL
                                + "=" + customActionLabelTextId); //$NON-NLS-1$ 
                        generateConfiguration(clsTask, true, doMofString, doIndexString, CompilerConstants.CONFIG_DATA_OBJECT_CACT_DESCRIPTION
                                + "=" + customActionDescriptionTextId); //$NON-NLS-1$
                        generateConfiguration(clsTask, true, doMofString, doIndexString, CompilerConstants.CONFIG_DATA_OBJECT_CACT_INDEX
                                + "=" + index); //$NON-NLS-1$
                        index++;
                    }
                }
            }
        }
    }
	/**
	 * Helper method to get the XSD contents of the Data container object
	 * @param dataObject Data Container
	 * @return List of XSD Particles
	 */
	private List<XsdParticle> getXsdContent(DataContainer dataObject) {
		XsdComplexTypeDefinition xsdType = (XsdComplexTypeDefinition)dataObject.getXsdElementDeclaration().getTypeDefinition(); 
		XsdComplexTypeContent attributesComplexTypeContent = xsdType.getContent();
		XsdParticle xsdParticle = (XsdParticle) attributesComplexTypeContent;
		XsdParticleContent xsdParticleContent = xsdParticle.getContent();
		XsdModelGroup xsdModelGroup = (XsdModelGroup) xsdParticleContent;
		List<XsdParticle> contents = xsdModelGroup.getContents();
		return contents;
	}

    private void fillPropertyBagWithExceptions(final Task task, final Collection<Uiproperty> propertyBag,
            final MessageEventDefinition endpoint) throws BPMNCompilerException {
        // find values of prefixes
        final String errorIdPrefixKey = UIComponentPropertyKeys.UUI_ERROR_EVENT_IDPREFIX_KEY.toString();
        final String errorValuePrefixKey = UIComponentPropertyKeys.UUI_ERROR_EVENT_VALUEPREFIX_KEY.toString();
        String errorIdPrefix = null;
        String errorValuePrefix = null;
        for (final Uiproperty property : propertyBag) {
            if (errorIdPrefixKey.equals(property.getName())) {
                errorIdPrefix = property.getValue();
            }
            if (errorValuePrefixKey.equals(property.getName())) {
                errorValuePrefix = property.getValue();
            }
        }

        // if the prefixes are not defined, there is nothing to do
        if (errorIdPrefix != null && errorValuePrefix != null) {

            // get all faults on the operation and their exceptions ids
            final Map<String, String> exceptionIds = new HashMap<String, String>();
            for (final ErrorEventDefinition error : endpoint.getErrorEventDefinitions()) {
                if (error.getWsdlFault() != null) {
                    final String id = ctx.getHost().getVersionId(error, CompilerType.EXCEPTIONCOMPILER);
                    exceptionIds.put(error.getWsdlFault().getName(), id);
                }
            }

            // find all value properties
            final Map<String, String> faultNames = new HashMap<String, String>();
            for (final Uiproperty property : propertyBag) {
                if (property.getName().startsWith(errorValuePrefix) && !property.getName().equals(errorValuePrefixKey)) {
                    final String index = property.getName().substring(errorValuePrefix.length());
                    faultNames.put(index, property.getValue());
                }
            }

            // find the id properties and fill them with the exception ids
            for (final Uiproperty property : propertyBag) {
                if (property.getName().startsWith(errorIdPrefix) && !property.getName().equals(errorIdPrefixKey)) {
                    final String index = property.getName().substring(errorIdPrefix.length());
                    final String faultName = faultNames.get(index);
                    ctx.getValidator().validate(faultName != null, "BPM.rt_c_bpmn.000002",
                            "Invalid configuration for fault handling of task '%s'.", task.getOriginalName());
                    final String exceptionId = exceptionIds.get(faultName);
                    ctx.getValidator().validate(exceptionId != null, "BPM.rt_c_bpmn.000003",
                            "No compiled exception found for task '%s' and fault '%s'.", task.getOriginalName(), faultName);
                    property.setValue(exceptionId);
                }
            }
        }
    }

    /**
     * Checks depending on the task type whether a dependency to an UI development components is maintained. If there dependency is not
     * properly maintained this is logged as a warning.
     */
    private void checkDcDependency(final Task task, final String vendorName, final String dcName) {
        final TaskCategory taskCategory = task.getCategory();
        final boolean hasDCReference = vendorName != null && dcName != null;
        boolean checkRequired = false;

        if (taskCategory == TaskCategoryEnum.NOTIFICATION) {
            if (hasDCReference) {
                checkRequired = true;
            }
        } else if (taskCategory == TaskCategoryEnum.BUSINESS_TASK) {
            // If any of the potential UI technologies for tasks require a
            // compulsory check (e.g. based on add. properties), it can be added
            // here. For the WebDynpro ABAP integration the mandatory check for
            // a valid value in the DC properties was removed.
            if (hasDCReference) {
                checkRequired = true;
            }
            // else { ctx.getValidator().error("BPM.rt_c_bpmn.000001",
            // "Could not retrieve DC vendor and/or name from UI Component of task '%s'.",
            // task.getOriginalName());
            // }
        } else if (taskCategory == TaskCategoryEnum.SIMPLE_SHARED_TASK) {
            if (hasDCReference) {
                checkRequired = true;
            }
        } else if (taskCategory == TaskCategoryEnum.OFFLINE_TASK) {
            if (hasDCReference) {
                checkRequired = true;
            }
        } else {
            if (hasDCReference) {
                checkRequired = true;
            }
        }

        if (checkRequired) {
            final boolean deployDep = ctx.getHost().isDependencyAvailable(vendorName, dcName, IBuilderHost.DEP_TYPES.DEPLOYTIME);
            if (!deployDep) {
                ctx.getValidator().warning("BPM.rt_c_bpmn.000005", //$NON-NLS-1$
                        "Deploy time dependency to DC '%s' containing UI component of task '%s' is not available", //$NON-NLS-1$
                        dcName, task.getOriginalName());
            }
            final boolean buildDep = ctx.getHost().isDependencyAvailable(vendorName, dcName, IBuilderHost.DEP_TYPES.BUILDTIME);
            if (!buildDep) {
                ctx.getValidator().warning("BPM.rt_c_bpmn.000006", //$NON-NLS-1$
                        "Build time dependency to DC '%s' containing UI component of task '%s' is not available", //$NON-NLS-1$
                        dcName, task.getOriginalName());
            }
        }
    }

    /**
     * Replicates portions of the WSDL data for use in the BPMN and UC adapter. For the BPMN adapter uniqueness is guaranteed by
     * incorporating the version id of the flow. For the UC adapter only for generated endpoints configuration entries are written. Those
     * entries contain the version id of the interface.
     * 
     * (1) request metadata:
     * 
     * <pre>
     *  &lt;request class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,SCOPE=&lt;type scope identifier&gt;
     *  &lt;request class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,ELEMENT,NAME=&lt;sdo request name&gt;
     *  &lt;request class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,ELEMENT,NAMESPACE=&lt;sdo request ns&gt;
     *  &lt;request class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,TYPE,NAME=&lt;sdo request type name&gt;
     *  &lt;request class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,TYPE,NAMESPACE=&lt;sdo request type ns&gt;
     * </pre>
     * 
     * (2) response metadata
     * 
     * <pre>
     *  &lt;response class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,SCOPE=&lt;type scope identifier&gt;     
     *  &lt;response class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,ELEMENT,NAME=&lt;sdo response name&gt;
     *  &lt;response class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,ELEMENT,NAMESPACE=&lt;sdo response ns&gt;
     *  &lt;response class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,TYPE,NAME=&lt;sdo resonse type name&gt;
     *  &lt;response class&gt;,SERVICES,&lt;service id&gt;,&lt;operation name 1&gt;,TYPE,NAMESPACE=&lt;sdo response type ns&gt;
     * </pre>
     * 
     * @param endpoint
     *            message event definition of the endpoint to configure
     * @param bpmnService
     *            service identifier for the BPMN Adapter. In case of
     * @code{null no configuration is generated. This can be used to avoid unnecessary configuration for intermediate events.
     * @param ucService
     *            service identifier for the UC Adapter. In case of @code{null} no configuration is generated. This can be used to avoid
     *            unnecessary configuration for inner task flows or modelled endpoints.
     * 
     * @throws BPMNCompilerException
     */
    public void generateMessageConfiguration(final MessageEventDefinition endpoint, final String bpmnService, final String ucService)
            throws BPMNCompilerException {
        final Operation operation = endpoint.getOperation();

        // generate configuration the BPMN Request/Response, can be excluded for
        // intermediate events
        if (bpmnService != null) {
            generateMessageConfiguration(CompilerConstants.ADAPTER_BPMN, bpmnService, operation, true);
        }

        // generate configuration the UC configuration only for 7.11 models, for
        // modelled endpoints this is done by the interface compiler
        if (ucService != null && !OperationHelper.isModelledEndpoint(endpoint)) {
            generateMessageConfiguration(CompilerConstants.ADAPTER_UC, ucService, operation, false);
        }
    }

    private void generateMessageConfiguration(final String adapter, final String service, final Operation operation,
            final boolean includeVersion) {
        final Pair<String, String> clsRequest = new Pair<String, String>(adapter, CompilerConstants.GALAXY_REQUEST);
        final XsdElementDeclaration requestElement = WSDLHelper.getRequestElement(operation);
        if (includeVersion) {
            generateVersionedMessageConfiguration(clsRequest, service, operation, requestElement);
        } else {
            generateMessageConfiguration(clsRequest, service, operation, requestElement);
        }

        final Pair<String, String> clsResponse = new Pair<String, String>(adapter, CompilerConstants.GALAXY_RESPONSE);
        final XsdElementDeclaration responseElement = WSDLHelper.getResponseElement(operation);
        if (responseElement != null) {
            if (includeVersion) {
                generateVersionedMessageConfiguration(clsResponse, service, operation, responseElement);
            } else {
                generateMessageConfiguration(clsResponse, service, operation, responseElement);
            }
        }
    }

    private void generateVersionedMessageConfiguration(final Pair<String, String> cls, final String service, final Operation op,
            final XsdElementDeclaration elem) {
        final String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(op), CompilerType.TYPECOMPILER);
        final String operation = op.getName();

        final QName name = SDOHelper.generateSDOName(elem);
        final QName type = SDOHelper.generateSDOName(WSDLHelper.getElementType(elem));

        ConfigurationString config;
        config = generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CONFIG_EMPTY,
                CompilerConstants.CONFIG_SCOPE + '=' + scopeId).second[4];
        ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config, CONFIG_EMPTY));

        config = generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CONFIG_EMPTY,
                CompilerConstants.CONFIG_ELEMENT, CompilerConstants.CONFIG_NAME + '=' + name.getLocalPart()).second[4];
        ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config, CONFIG_EMPTY));

        config = generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CONFIG_EMPTY,
                CompilerConstants.CONFIG_ELEMENT, CompilerConstants.CONFIG_NAMESPACE + '=' + name.getNamespaceURI()).second[4];
        ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config, CONFIG_EMPTY));

        config = generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CONFIG_EMPTY,
                CompilerConstants.CONFIG_TYPE, CompilerConstants.CONFIG_NAME + '=' + type.getLocalPart()).second[4];
        ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config, CONFIG_EMPTY));

        config = generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CONFIG_EMPTY,
                CompilerConstants.CONFIG_TYPE, CompilerConstants.CONFIG_NAMESPACE + '=' + type.getNamespaceURI()).second[4];
        ctx.getVersioningHelper().registerVersioningCallback(new AppendVersioningCallback(config, CONFIG_EMPTY));
    }

    private void generateMessageConfiguration(final Pair<String, String> cls, final String service, final Operation op,
            final XsdElementDeclaration elem) {
        final String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(op), CompilerType.TYPECOMPILER);
        final String operation = op.getName();

        final QName name = SDOHelper.generateSDOName(elem);
        final QName type = SDOHelper.generateSDOName(WSDLHelper.getElementType(elem));

        generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CompilerConstants.CONFIG_SCOPE + '='
                + scopeId);
        generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CompilerConstants.CONFIG_ELEMENT,
                CompilerConstants.CONFIG_NAME + '=' + name.getLocalPart());

        generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CompilerConstants.CONFIG_ELEMENT,
                CompilerConstants.CONFIG_NAMESPACE + '=' + name.getNamespaceURI());

        generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CompilerConstants.CONFIG_TYPE,
                CompilerConstants.CONFIG_NAME + '=' + type.getLocalPart());

        generateConfiguration(cls, false, CompilerConstants.CONFIG_SERVICES, service, operation, CompilerConstants.CONFIG_TYPE,
                CompilerConstants.CONFIG_NAMESPACE + '=' + type.getNamespaceURI());
    }

    /**
     * Generates versioned adapter configuration for the key extraction. One of the parameters may be @code{null}, but they are not allowed
     * to be equal. For 7.11 content the ucService has a version id appended and the bpmnService not. For 7.20 and subsequent releases the
     * naming convention of explicitly modelled message triggers should not clash with the service identifier of pools.
     * 
     * <pre>
     *  &lt;generator class&gt;,&lt;rule id&gt;,SERVICE=&lt;service identifier&gt;
     *  &lt;generator class&gt;,&lt;rule id&gt;,OPERATION=&lt;operation&gt;
     *  &lt;generator class&gt;,&lt;rule id&gt;,ADAPTER=&lt;target class adapter&gt;
     *  &lt;generator class&gt;,&lt;rule id&gt;,CLASS=&lt;target class name&gt;
     *  &lt;generator class&gt;,&lt;rule id&gt;,ATTRIBUTE=&lt;target class attribute&gt;
     *  &lt;generator class&gt;,&lt;rule id&gt;,EXPRESSION=&lt;generation expression&gt;
     * </pre>
     * 
     * @param bpmnService
     *            service identifier for the BPMN adapter
     * @param ucService
     *            service identifier for the UC adapter
     * @param operation
     *            operation of the request
     * @param cls
     *            is the class where an instance is to be created from.
     * @param attribute
     *            is the attribute that shall be filled with the result from the generation expression.
     * @param expression
     *            is the generation expression XML (as created by the mapping compiler).
     */
    public void generateGeneratorConfiguration(final String bpmnService, final String ucService, final String operation,
            final GalaxyClass cls, final Attribute attribute, final String expression) {
        if (bpmnService != null) {
            generateGeneratorConfiguration(bpmnService, operation, cls, attribute, expression);
        }
        if (ucService != null) {
            generateGeneratorConfiguration(ucService, operation, cls, attribute, expression);
            if (ucService.equals(bpmnService)) {
                throw new IllegalArgumentException();
            }
        }
    }
    
    /**
     * producing CONFIG line with key OFFER:<service>:<operation>:<semantic_version>:<sovid>:<adapter_name>:<galaxy_class>:<network_id>:<scope_id>
     * 
     * @param bpmnService
     * @param operation
     * @param cls
     * @param semanticVersion
     */
    public void generateGeneratorOfferConfiguration(final String bpmnService, final String operation, final GalaxyClass cls,
            final Integer semanticVersion, final String scopeId) {
        if (bpmnService != null && operation != null && cls != null && semanticVersion != null) {
            Pair<AdapterConfiguration, ConfigurationString[]> config;

            String sovid = VersioningHelper.computeServiceOperationVersionMD5(bpmnService, operation, semanticVersion.intValue());

            final String ruleId = VersioningHelper.CONFIG_OFFER + ':' + bpmnService + ':' + operation + ':' + semanticVersion + ':' + sovid
                    + ':' + cls.getAdapter() + ':' + cls.getName() + '_' + CompilerConstants.SCRIPT_VALUE_VERSION + ':'
                    + CompilerConstants.SCRIPT_VALUE_VERSION + ':' + scopeId;

            // generate configurations and add the string which have to be versioned to the list
            config = generateConfiguration(clsGenerator, false, ruleId);
            final ConfigurationString configurationString = config.second[1];

            // add versioning callback to the configuration strings
            ctx.getVersioningHelper()
                    .registerVersioningCallback(new AbstractVersioningCallback<ConfigurationString>(null, configurationString) {

                        public void incorporateVersionIdentifier(String version_id) {
                            anchor.setValue(anchor.getValue().replace(CompilerConstants.SCRIPT_VALUE_VERSION, version_id));
                        }
                    });
        }
    }

    /**
     * producing CONFIG line with key REQUIRE:<service>:<operation>:<semantic_version>:<sovid>:<network_id>
     * 
     * @param bpmnService
     * @param operation
     * @param cls
     * @param semanticVersion
     */
    public void generateGeneratorRequireConfiguration(final String bpmnService, final String operation, final Integer semanticVersion) {
        if (bpmnService != null && operation != null && semanticVersion != null) {
            Pair<AdapterConfiguration, ConfigurationString[]> config;

            String sovid = VersioningHelper.computeServiceOperationVersionMD5(bpmnService, operation, semanticVersion.intValue());

            final String ruleId = VersioningHelper.CONFIG_REQUIRE + ':' + bpmnService + ':' + operation + ':' + semanticVersion + ':'
                    + sovid + ':' + CompilerConstants.SCRIPT_VALUE_VERSION;

            // generate configurations and add the string which have to be versioned to the list
            config = generateConfiguration(clsGenerator, false, ruleId);
            final ConfigurationString configurationString = config.second[1];

            // add versioning callback to the configuration strings
            ctx.getVersioningHelper()
                    .registerVersioningCallback(new AbstractVersioningCallback<ConfigurationString>(null, configurationString) {

                        public void incorporateVersionIdentifier(String version_id) {
                            anchor.setValue(anchor.getValue().replace(CompilerConstants.SCRIPT_VALUE_VERSION, version_id));
                        }
                    });
        }
    }

    /**
     * Generates new-style versioned adapter configuration for mappings.
     * 
     * <pre>
     *  &lt;mapper class&gt;,&lt;mapping id&gt;,MAPPING=&lt;mapping xml&gt;
     * </pre>
     * 
     * @param mapping_id
     *            is the non-versioned mapping identifier, the actual mapping identifier will be <mapping id>_<flow version>
     * @param mapping_xml
     *            is the mapping execution XML.
     */
    public void generateMapperConfiguration(final String mapping_id, final String mapping_xml) {
        final Pair<String, String> mapper_class = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER,
                CompilerConstants.GALAXY_TRANSFORMATOR);

        ctx.getVersioningHelper().registerAppendVersioningCallback(
                generateConfiguration(mapper_class, false, mapping_id, CompilerConstants.CONFIG_MAPPING + "=" + mapping_xml).second[1]);
    }

    private void generateGeneratorConfiguration(final String service, final String operation, final GalaxyClass cls,
            final Attribute attribute, final String expression) {
        final List<ConfigurationString> versionedConfigs = new ArrayList<ConfigurationString>(8);
        Pair<AdapterConfiguration, ConfigurationString[]> config;

        final String ruleId = service + ':' + cls.getAdapter() + ':' + cls.getName() + ':' + attribute.getName();

        // generate configurations and add the string which have to be versioned
        // to the list
        config = generateConfiguration(clsGenerator, false, ruleId, CompilerConstants.CONFIG_SERVICE + '=' + service);
        versionedConfigs.add(config.second[1]);
        config = generateConfiguration(clsGenerator, false, ruleId, CompilerConstants.CONFIG_OPERATION + '=' + operation);
        versionedConfigs.add(config.second[1]);
        config = generateConfiguration(clsGenerator, false, ruleId, CompilerConstants.CONFIG_ADAPTER + '=' + cls.getAdapter());
        versionedConfigs.add(config.second[1]);
        config = generateConfiguration(clsGenerator, false, ruleId, CompilerConstants.CONFIG_CLASS + '=' + cls.getName());
        versionedConfigs.add(config.second[1]);
        versionedConfigs.add(config.second[2]);
        config = generateConfiguration(clsGenerator, false, ruleId, CompilerConstants.CONFIG_ATTRIBUTE + '=' + attribute.getName());
        versionedConfigs.add(config.second[1]);
        config = generateConfiguration(clsGenerator, false, ruleId, CompilerConstants.CONFIG_EXPRESSION + '=' + expression);
        versionedConfigs.add(config.second[1]);

        // add versioning callback to the configuration strings
        for (final ConfigurationString configurationString : versionedConfigs) {
            ctx.getVersioningHelper().registerAppendVersioningCallback(configurationString);
        }
    }

    /**
     * Generates new-style versioned adapter configuration for expressions.
     * 
     * <pre>
     *  &lt;extractor class&gt;,&lt;expression id&gt;,EXPRESSION=&lt;expression xml&gt;
     * </pre>
     * 
     * @param expression_id
     *            is the non-versioned expression identifier.
     * @param expression_xml
     *            is the expression execution XML.
     */
    public void generateExtractorConfiguration(final String expression_id, final String expression_xml) {
        final Pair<String, String> extractor_class = new Pair<String, String>(CompilerConstants.ADAPTER_TRANSFORMER,
                CompilerConstants.GALAXY_COMPUTER);

        ctx.getVersioningHelper()
                .registerAppendVersioningCallback(
                        generateConfiguration(extractor_class, false, expression_id, CompilerConstants.CONFIG_EXPRESSION + "="
                                + expression_xml).second[1]);
    }

}
