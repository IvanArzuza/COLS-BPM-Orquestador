package com.sap.glx.paradigmInterface.bpmn.compiler.helpers;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateCatchEvent;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.tc.esmp.mm.wsdl2.Operation;

/**
 * <p>
 * A message trigger context contains various information related to a message trigger.
 * </p>
 * 
 * <p>
 * <ul>
 * <li>Qualified Trigger Name</li>
 * <li>Operation</li>
 * <li>(Calculated) Endpoint ID</li>
 * <li>Subscription Galaxy Class</li>
 * <li>CorrelationTrigger Galaxy Class</li>
 * <li>CorrelationKey Galaxy Class</li>
 * <li>(Triggernet) Join Node <code>&lt;Subscription, CorrelationTrigger&gt;</code> with <code>trigger.parent = subscription</code></li>
 * <li>Configuration for CorrelationKey Galaxy Class</li>
 * <li>Configuration for Subscription Galaxy Class</li>
 * <li>A collection of intermediate message event contexts</li>
 * </ul>
 * </p>
 * 
 * <p>
 * Note that the message trigger context needs to know about all its intermediate message events. Otherwise the fingerprints cannot be
 * calculated correctly for the class declaration or the configuration. Therefore all intermediate message events are
 * {@link #introduce(IntermediateCatchEvent)}ed during the compile() step. If all intermediate message events are known the compilation is
 * triggered.
 * </p>
 * 
 * @see #introduce(IntermediateCatchEvent)
 * @see #getKnownIntermediateMessageEvents()
 */
public class MessageTriggerContext {

    private static final String OR = "|";
    private static final String SLASH = "/";

    Map<IntermediateCatchEvent, IntermediateMessageEventContext> contexts = new HashMap<IntermediateCatchEvent, IntermediateMessageEventContext>();
    List<IntermediateCatchEvent> knownIntermediateMessageEvents = new ArrayList<IntermediateCatchEvent>();

    private final String qualifiedTriggerName;
    private final Operation operation;
    private final String endpointId;

    private boolean conditionalStartEndpoint = false;

    private GalaxyClass correlationKeyClass;
    private GalaxyClass correlationTriggerClass;
    private GalaxyClass subscriptionClass;
    private GalaxyClass conditionalStarterClass;

    private Join subscriptionCorrelationTriggerJoin;

    private final StringBuilder correlationKeyConfigurationBuilder = new StringBuilder();
    private final StringBuilder subscriptionConfigurationBuilder = new StringBuilder();
    private final StringBuilder fingerprintConfigurationBuilder = new StringBuilder();

    public MessageTriggerContext(final String qualifiedTriggerName, final Operation operation) {
        if (qualifiedTriggerName == null) {
            throw new NullPointerException("qualifiedTriggerName must not be null");
        }
        if (operation == null) {
            throw new NullPointerException("operation must not be null");
        }
        this.qualifiedTriggerName = qualifiedTriggerName;
        this.operation = operation;

        endpointId = constructEndpointId(qualifiedTriggerName, operation);
    }

    private String constructEndpointId(String service, final Operation operation) {
        if (!service.endsWith(SLASH)) {
            service += SLASH;
        }
        return service + operation.getName();
    }

    /**
     * Adds the intermediate message event context to the message trigger context.
     * 
     * Adding multiple contexts for the same event is not permitted and will result in an exception.
     * 
     * @param intermediateMessageEventContext
     *            not null
     */
    public void addIntermediateMessageEventContext(final IntermediateMessageEventContext intermediateMessageEventContext) {
        if (intermediateMessageEventContext == null) {
            throw new NullPointerException("IntermediateMessageEventContext must not be null.");
        }

        final IntermediateCatchEvent event = intermediateMessageEventContext.getIntermediateMessageEvent();
        final IntermediateMessageEventContext oldContext = contexts.put(event, intermediateMessageEventContext);
        if (oldContext != null) {
            throw new IllegalStateException(String.format(
                    "Intermediate message event context for event '%s' is already part of the message trigger context.", event.getName()));
        }
    }

    /**
     * @param intermediateMessageEvent
     *            not null
     * 
     * @return the context for the passed intemediate message event, might be null.
     */
    public IntermediateMessageEventContext getIntermediateMessageEventContext(final IntermediateCatchEvent intermediateMessageEvent) {
        return contexts.get(intermediateMessageEvent);
    }

    public String getQualifiedTriggerName() {
        return qualifiedTriggerName;
    }

    public Operation getOperation() {
        return operation;
    }

    /**
     * @return the calculated endpoint ID (= 'qualified trigger name' + '/' + 'operation name')
     */
    public String getEndpointId() {
        return endpointId;
    }

    public void setCorrelationKeyClass(final GalaxyClass correlationKeyClass) {
        this.correlationKeyClass = correlationKeyClass;

    }

    public void setCorrelationTriggerClass(final GalaxyClass correlationTriggerClass) {
        this.correlationTriggerClass = correlationTriggerClass;
    }

    public void setSubscriptionClass(final GalaxyClass subscriptionClass) {
        this.subscriptionClass = subscriptionClass;
    }

    public void setConditionalStarterClass(GalaxyClass conditionalStarterClass) {
        this.conditionalStarterClass = conditionalStarterClass;
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public GalaxyClass getCorrelationKeyClass() {
        if (correlationKeyClass == null) {
            throw new IllegalStateException("CorrelationKeyClass is unset.");
        }
        return correlationKeyClass;
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public GalaxyClass getCorrelationTriggerClass() {
        if (correlationTriggerClass == null) {
            throw new IllegalStateException("CorrelationTriggerClass is unset.");
        }

        return correlationTriggerClass;
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public GalaxyClass getSubscriptionClass() {
        if (subscriptionClass == null) {
            throw new IllegalStateException("SubscriptionClass is unset.");
        }

        return subscriptionClass;
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public GalaxyClass getConditionalStarterClass() {
        if (conditionalStarterClass == null) {
            throw new IllegalStateException("ConditionalStarterClass is unset.");
        }
        return conditionalStarterClass;
    }

    /**
     * @return a collection of all intermediate message event contexts added to this message trigger context, not null.
     */
    public Collection<IntermediateMessageEventContext> getIntermediateMessageEventContexts() {
        return Collections.unmodifiableCollection(contexts.values());
    }

    /**
     * <p>
     * Appends the attribute index of the correlation attributes to the correlation key &amp; subscription configuration.
     * </p>
     * 
     * <p>
     * Can be invoked multiple times. Each passed configuration will be concatenated with '|'.
     * </p>
     * 
     * <p>
     * Example:
     * </p>
     * 
     * <code>
     * CONFIG,com.sap.glx.adapter.internal.CorrelationAdapter,Subscription_0_IME1_db44bfa2c851c7767833bab99b4cfdb3,CORR_COND=1&amp;2|3&amp;4<br />
     * ...<br/>
     * CONFIG,com.sap.glx.adapter.internal.CorrelationAdapter,CorrelationKey_0_IME1_db44bfa2c851c7767833bab99b4cfdb3,CORR_COND=5&amp;6|7&amp;8<br />
     * </code>
     * 
     * @param correlationKeyConfiguration
     *            e.g. 1&amp;2 or 3&amp;4
     * @param subscriptionConfiguration
     *            e.g. 5&amp;6 or 7&amp;8
     */
    public void appendCorrelationConditionConfiguration(final String correlationKeyConfiguration, final String subscriptionConfiguration) {
        if (correlationKeyConfiguration == null) {
            throw new NullPointerException("CorrelationKeyConfiguration must not be null.");
        }
        if (subscriptionConfiguration == null) {
            throw new NullPointerException("SubscriptionConfiguration must not be null.");
        }

        appendConfiguration(correlationKeyConfigurationBuilder, correlationKeyConfiguration);
        appendConfiguration(subscriptionConfigurationBuilder, subscriptionConfiguration);
    }

    /**
     * <p>
     * Appends the attribute index of the fingerprints to the subscription configuration.
     * </p>
     * 
     * <p>
     * Can be invoked multiple times. Each passed configuration will be concatenated with '|'.
     * </p>
     * 
     * <p>
     * Example:
     * </p>
     * 
     * <code>
     * CONFIG,com.sap.glx.adapter.internal.CorrelationAdapter,Subscription_0_IME1_db44bfa2c851c7767833bab99b4cfdb3,FP_IDX=5|6
     * </code>
     * 
     * @param fingerprintConfiguration
     *            e.g. 5 or 6
     */
    public void appendFingerprintConfiguration(final String fingerprintConfiguration) {
        if (fingerprintConfiguration == null) {
            throw new NullPointerException("FingerprintConfiguration must not be null.");
        }
        appendConfiguration(fingerprintConfigurationBuilder, fingerprintConfiguration);
    }

    private void appendConfiguration(final StringBuilder builder, final String configuration) {
        if (builder.length() > 0) {
            builder.append(OR);
        }
        builder.append(configuration);
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public String getCorrelationConditionConfigurationForCorrelationKey() {
        if (correlationKeyConfigurationBuilder.length() == 0) {
            throw new IllegalStateException("No correlation key configuration appended.");
        }

        return correlationKeyConfigurationBuilder.toString();
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public String getCorrelationConditionConfigurationForSubscription() {
        if (subscriptionConfigurationBuilder.length() == 0) {
            throw new IllegalStateException("No subscription configuration appended.");
        }

        return subscriptionConfigurationBuilder.toString();
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public String getFingerprintConfiguration() {
        if (fingerprintConfigurationBuilder.length() == 0) {
            throw new IllegalStateException("No fingerprint configuration appended.");
        }

        return fingerprintConfigurationBuilder.toString();
    }

    /**
     * Introduces the passed intermediate message event to the message trigger context
     * 
     * An exception will be raised if the event did not belong to this trigger or if it was introduced before.
     * 
     * @see #getKnownIntermediateMessageEvents()
     * 
     * @param intermediateMessageEvent
     */
    public void introduce(final IntermediateCatchEvent intermediateMessageEvent) {
        if (!contexts.containsKey(intermediateMessageEvent)) {
            throw new IllegalStateException(String.format(
                    "Tried to introduce intermediate message event %s, but it is not part of the context.", intermediateMessageEvent
                            .getName().getOriginalText()));
        }
        if (knownIntermediateMessageEvents.contains(intermediateMessageEvent)) {
            throw new IllegalStateException(String.format("Tried to introduce intermediate message event %s which is already known.",
                    intermediateMessageEvent.getName()));
        }
        knownIntermediateMessageEvents.add(intermediateMessageEvent);
    }

    /**
     * @return true if the number of added intermediate message event contexts equals the number of introduced events, false otherwise.
     */
    public boolean knowsAllIntermediateMessageEvents() {
        return knownIntermediateMessageEvents.size() == contexts.size();
    }

    /**
     * @see #introduce(IntermediateCatchEvent)
     * 
     * @return a list of all intermediate message events that were introduced before.
     */
    public List<IntermediateCatchEvent> getKnownIntermediateMessageEvents() {
        return Collections.unmodifiableList(knownIntermediateMessageEvents);
    }

    public void setSubscriptionCorrelationTriggerJoin(final Join subscriptionCorrelationTriggerJoin) {
        this.subscriptionCorrelationTriggerJoin = subscriptionCorrelationTriggerJoin;
    }

    /**
     * @return not null
     * 
     * @throws IllegalStateException
     *             if invoked without being set before
     */
    public Join getSubscriptionCorrelationTriggerJoin() {
        if (subscriptionCorrelationTriggerJoin == null) {
            throw new IllegalStateException("SubscriptionCorrelationTriggerJoin is unset.");
        }
        return subscriptionCorrelationTriggerJoin;
    }

    public void markAsConditionalStartEndpoint() {
        this.conditionalStartEndpoint = true;
    }

    public boolean isConditionalStartEndpoint() {
        return conditionalStartEndpoint;
    }
}
