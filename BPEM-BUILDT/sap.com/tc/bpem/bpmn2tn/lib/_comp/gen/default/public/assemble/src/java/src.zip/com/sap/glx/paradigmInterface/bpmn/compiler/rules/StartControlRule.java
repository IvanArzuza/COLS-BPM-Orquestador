package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

import com.sap.glx.constants.DataContainerConstants;
import com.sap.glx.ide.model.classes.Attribute;
import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.classes.SimpleType;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.DataObject;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.MessageEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Pool;
import com.sap.glx.ide.model.galaxy.workflow.StartEvent;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.LocalSource;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ContextHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.MessageTriggerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.OperationHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.VersioningHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WSDLHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.WorkflowHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventLogHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog.EventTypeIds;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.BooleanLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Literal;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Parameter;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Script;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptName;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.tc.esmp.mm.wsdl2.Operation;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * A compiler rule for start events with a message event definitions.
 * 
 * @author Sören Balko
 * @author Thilo-Alexander Ginkel
 * @author Philipp Sommer
 * 
 */

public class StartControlRule extends CatchEventMessageRule<StartEvent> implements CompilerRule<StartEvent> {

    private static Pair<String, String> clsUcRequest = new Pair<String, String>(CompilerConstants.ADAPTER_UC,
            CompilerConstants.GALAXY_REQUEST);
    private static Pair<String, String> clsBpmnRequest = new Pair<String, String>(CompilerConstants.ADAPTER_BPMN,
            CompilerConstants.GALAXY_REQUEST);


    private GalaxyClass clsEvent;
    private String bpmnService;
    private String ucService;
    private Operation operation;

    public Class<StartEvent> getSupportedArtifact() {
        return StartEvent.class;
    }

    private enum StartOption {
        BPMN, UC, RESEND
    }

    @Override
    public void preprocess(final CompilerContext ctx) throws BPMNCompilerException {
        // validated by the CollectArtifactsStage: the one and only start event with a message trigger
        final StartEvent startEvent = ctx.getState().getStartEvent();

        // get validated endpoint of the start event
        final Triple<String, String, Operation> endpoint = getEndpoint(ctx, startEvent);
        bpmnService = endpoint.first;
        ucService = endpoint.second;
        operation = endpoint.third;

        if (ctx.useLegacyConditionalStart()) {
            // shared events must refer to a modelled message trigger
            if (OperationHelper.isModelledEndpoint(startEvent.getTrigger())) {
                clsEvent = ctx.getState().getEvent(ucService);
                ctx.getConfigFactory().generateEventConfigurationAddition(clsEvent, startEvent);
            } else {
                ctx.getValidator().error("BPM.rt_c_bpmn.000086", //$NON-NLS-1$
                        "Start event '%s' must refer to an explicitly modeled message trigger.", startEvent.getOriginalName());//$NON-NLS-1$
            }
        } else {
            clsEvent = ctx.getReplicator().generateEventClass(startEvent);
            NodeFactory.connectNodes(ctx.getSourceFactory().getSource4Class(clsEvent), 0, ctx.getReplicator().getBlackHole(), 0);

            // configuration of the event, the request classes and its generator rules for ppUsername and ppHash
            configureEndpoint(ctx, startEvent, clsEvent);
        }
        // add the 'valid' attribute for the start condition and configure the generator rule
        final Attribute attValid = ctx.getClassFactory().addAttribute(clsEvent, ATTRIBUTE_VALID, ctx.getSimpleTypes().BOOLEAN);
        ctx.getMappingHelper().generate(bpmnService, ucService, getOperationName(ctx, operation), clsEvent, attValid,
                startEvent.getExpression());
        Integer semanticVersionOffer = VersioningHelper.getBPMNEndpointSemanticVersionOffer(ctx, startEvent);
        if(semanticVersionOffer != null){
            final String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(operation), CompilerType.TYPECOMPILER);
            ctx.getConfigFactory().generateGeneratorOfferConfiguration(bpmnService,  getOperationName(ctx, operation), clsEvent, semanticVersionOffer, scopeId);
        }
    }

    public void compile(final StartEvent startEvent, final CompilerContext ctx) throws BPMNCompilerException {

        ctx.getValidator().validateConnectors(startEvent, 0, 0, 1, 1);

        // nothing to be done for blank start events (only allowed in embedded subflows)
        if (startEvent.getEventDefinition() == null) {
            ctx.getValidator().validate(startEvent.getScope() != ctx.getRootScope(), "BPM.rt_c_bpmn.000051", //$NON-NLS-1$
                    "Blank start event '%s' found outside of embedded subflows.", startEvent); //$NON-NLS-1$
            return;
        }
        ctx.getValidator().validate(startEvent.getEventDefinition() instanceof MessageEventDefinition, "BPM.rt_c_bpmn.000052", //$NON-NLS-1$
                "Start event '%s' has an unsupported trigger type.", startEvent.getOriginalName()); //$NON-NLS-1$
        ctx.getValidator().validateOperation(startEvent, operation);

        if (ctx.useITF_Decoupling() || ctx.useSunbeamNonConditionalStart() || ctx.useSunbeamConditionalStart()) {
            final GalaxyClass groupLocalityClass = ctx.getReplicator().generateGroupLocalityHandlerClass(ctx.getRootScope());
            ctx.getState().setGroupLocalityHandler(groupLocalityClass);
        }

        if (ctx.useITF_Decoupling()) {
            GalaxyClass referenceProxyClass = ctx.getReplicator().generateReferenceProxyClass(ctx.getRootScope());
            ctx.getState().setReferenceProxyClass(referenceProxyClass);
        }

        // compile the output mapping
        final Pair<IMappingCompiler.Summary, String> mapping = ctx.getMappingHelper().compile(startEvent.getOutputMapping());

        // generate synchronous script execution nodes
        final GenericOperator bpmnStartTarget = createStartTarget(ctx, startEvent, mapping, StartOption.BPMN);
        final GenericOperator ucStartTarget = createStartTarget(ctx, startEvent, mapping, StartOption.UC);

        // generate triggernet fragment
        final Source eventSource = ctx.getSourceFactory().generateSource(clsEvent);

        if (ctx.useLegacyConditionalStart()) {
            // requests through the BPMN adapter do always create a new process instance
            final Join bpmnRequestEvent = generateRequestEventJoin(ctx, ctx.getState().getBPMNRequest(), eventSource, bpmnService,
                    operation.getName());
            final ConstantFilter bpmnValidFilter = ctx.getConstantFilterFactory().generateFilter(startEvent, "valid", "0/1/3",
                    "BOOLEAN:true", "==");
            NodeFactory.connectNodes(bpmnRequestEvent, 0, bpmnValidFilter, 0);
            NodeFactory.connectNodes(bpmnValidFilter, 0, bpmnStartTarget, 0);

            // requests from the UC adapter go thought the shared persistent join node any create new
            // instances, if there is no existing one to consume the message
            final Node subscriptionJoin = ctx.getState().getSharedPersistentJoin();
            final ConstantFilter ucValidFilter = ctx.getConstantFilterFactory().generateFilter(startEvent, "valid", "0/1/3",
                    "BOOLEAN:true", "==");
            NodeFactory.connectNodes(subscriptionJoin, 1, ucValidFilter, 0);
            NodeFactory.connectNodes(ucValidFilter, 0, ucStartTarget, 0);
            ctx.getExecutionFactory().setEdgeTriggeredToFalse(ucStartTarget);
        } else {

            // handle both request the same way (duplicated trigger net)
            final ConstantFilter validFilter = ctx.getConstantFilterFactory().generateFilter(startEvent, "valid", "0/0/3", "BOOLEAN:true",
                    "==");
            NodeFactory.connectNodes(eventSource, 0, validFilter, 0);
            final Join bpmnRequestEvent = generateRequestEventJoin(ctx, ctx.getState().getBPMNRequest(), validFilter, bpmnService,
                    operation.getName());
            final Join ucRequestEvent = generateRequestEventJoin(ctx, ctx.getState().getUCRequest(), validFilter, ucService, operation
                    .getName());

            if (ctx.getState().isSharedStart()) {
                final GenericOperator resendStartTarget = createStartTarget(ctx, startEvent, mapping, StartOption.RESEND);
                GalaxyClass resendRequestGalaxyClass = ctx.getState().getResendRequest();
                final Source resendRequest = ctx.getSourceFactory().getSource4Class(resendRequestGalaxyClass);
                final Join resendRequestEvent = generateRequestEventJoin(ctx, resendRequest, validFilter, ucService,
                        operation.getName());
                NodeFactory.connectNodes(resendRequestEvent, 0, resendStartTarget, 0);
            }

            NodeFactory.connectNodes(bpmnRequestEvent, 0, bpmnStartTarget, 0);
            NodeFactory.connectNodes(ucRequestEvent, 0, ucStartTarget, 0);

        }

        // ITF_DECOUPLING and Correlation: generate fragments for creation of group locality handler,
        // which will be created only for root flows but not for referenced or embedded subflows
        if (!ctx.isTaskFlow() && (ctx.useITF_Decoupling() || ctx.useSunbeamNonConditionalStart())) {
            final ConstantFilter instanceIsRootFilter = ctx.getConstantFilterFactory().generateFilter(ctx.getRootScope(), "isRoot",
                    "0/0/0", "NULL", "==");
            GalaxyClass clsInstance = ctx.getState().getInstanceClass();
            LocalSource instanceSource = ctx.getSourceFactory().getSource4Class(clsInstance);
            NodeFactory.connectNodes(instanceSource, 0, instanceIsRootFilter, 0);
            final GenericOperator localityHandlerTarget = createLocalityHandlerTarget(ctx);
            NodeFactory.connectNodes(instanceIsRootFilter, 0, localityHandlerTarget, 0);
        }
    }



    /**
     * ITF_DECOUPLING and Correlation: returns a Script, which creates a marker object used for tracking the locality of storage groups
     */
    private GenericOperator createLocalityHandlerTarget(CompilerContext ctx) {
        Script script = new Script(ctx, ScriptName.CREATE_GROUP_LOCALITY_HANDLER, ctx.getRootScope());
        ScriptVariable varInstance = script.addParameter(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass());

        // new AsyncActionAdapter:GroupLocalityHandler(instance);
        script.generateNewCommand(ctx.getState().getGroupLocalityHandler(), varInstance);
        return script.getExecution();
    }

    private GenericOperator createStartTarget(final CompilerContext ctx, final StartEvent startEvent,
            final Pair<IMappingCompiler.Summary, String> mapping, final StartOption startOption) throws BPMNCompilerException {
        // script header generation
        AdvancedScript script = null;
        ScriptVariable varRequest = null;
        ScriptVariable varMessageId = null;

        switch (startOption) {
            case BPMN:
                script = new AdvancedScript(ctx, ScriptName.START_EVENT_BPMN, startEvent);
                varRequest = script.addParameter(ScriptVariable.REQUEST, clsBpmnRequest);
                break;
            case UC:
                script = new AdvancedScript(ctx, ScriptName.START_EVENT_UC, startEvent);
                varRequest = script.addParameter(ScriptVariable.REQUEST, clsUcRequest);
                varMessageId = script.generateAssignCommand(ScriptVariable.MESSAGE_ID, varRequest, "messageId");
                break;
            case RESEND:
                script = new AdvancedScript(ctx, ScriptName.START_EVENT_RESEND, startEvent);
                GalaxyClass clsResendRequest = ctx.getState().getResendRequest();
                varRequest = script.addParameter(ScriptVariable.REQUEST, clsResendRequest);
                varMessageId = script.generateAssignCommand(ScriptVariable.MESSAGE_ID, varRequest, "messageId");
                break;
        }
        final ScriptVariable varEvent = script.addParameter(ScriptVariable.EVENT, clsEvent);
        //TODO Check if we need to ser 
        ScriptVariable varInitiator = null;
        ScriptVariable varKicker = null;
        if(startOption != StartOption.RESEND ){
            varInitiator = script.generateAssignCommand(ScriptVariable.INITIATOR, varRequest, "initiator");
            varKicker = script.generateAssignCommand(ScriptVariable.KICKER, varRequest, "kicker");
        }
        ScriptVariable varInstance = null;
        if ((ctx.isTaskFlow() && ctx.useITF_Decoupling()) || (startOption.equals(StartOption.BPMN) && ctx.useReferencedSubProcess_Decoupling() && ctx.getState().isSynchronouslyProvisioned())) {
            // ITF_DECOUPLING: Separate StorageGroup using ReferenceProxy objects

            // resolver = new AsyncActionAdapter:AsyncActionHandler();
            final ScriptVariable varResolver = new ScriptVariable("resolver");
            script.generateNewCommand(varResolver, new Pair<String, String>(CompilerConstants.ADAPTER_ASYNCACTION,
                    CompilerConstants.GALAXY_ASYNCACTIONHANDLER));

            // parent and kicker will be set later
            // NOTE: this creation order is used to ensure that parent and kicker proxies are created in the storage group of task instance
            // and not the other way around
            // instance=new BPMN:Instance(null,null,null,false,null);
            varInstance = script.generateNewCommand(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass(), Literal.NULL, Literal.NULL,
                    Literal.NULL, BooleanLiteral.FALSE, Literal.NULL, Literal.NULL);

            // initiatorRef = resolver:getReferenceString(initiator);
            final ScriptVariable varInitiatorRef = new ScriptVariable("initiatorRef");
            script.generateInvocationCommand(varInitiatorRef, varResolver, "getReferenceString", varInitiator);

            // kickerRef = resolver:getReferenceString(kicker);
            final ScriptVariable varKickerRef = new ScriptVariable("kickerRef");
            script.generateInvocationCommand(varKickerRef, varResolver, "getReferenceString", varKicker);

            // initiator = new AsyncActionAdapter:ReferenceProxy(instance, initiatorRef);
            script.generateNewCommand(varInitiator, ctx.getState().getReferenceProxyClass(), varInstance, varInitiatorRef);

            // kicker = new AsyncActionAdapter:ReferenceProxy(instance, kickerRef);
            script.generateNewCommand(varKicker, ctx.getState().getReferenceProxyClass(), varInstance, varKickerRef);

            // instance:parent = initiator
            script.generateUpdateCommand(varInstance, "parent", varInitiator);
            // instance:kicker = kicker
            script.generateUpdateCommand(varInstance, "kicker", varKicker);

            // delete resolver;
            script.generateDeleteCommand(varResolver);

            // new AsyncActionAdapter:GroupLocalityHandler(instance);
            script.generateNewCommand(ctx.getState().getGroupLocalityHandler(), varInstance);

        } else if(startOption == StartOption.RESEND){
            
            // ooiIn = request:ppUsername
            ScriptVariable initiatingUsername = new ScriptVariable("initiatingUsername");
            script.generateAssignCommand(initiatingUsername, varRequest, "ppUsername");
            
            // instance=new BPMN:Instance(initiator,null,kicker,false,messageId, ooiIn);
            varInstance = script.generateNewCommand(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass(), varInitiator, Literal.NULL,
                    varKicker, BooleanLiteral.FALSE, varMessageId, initiatingUsername);
        } else {
         // instance=new BPMN:Instance(initiator,null,kicker,false,messageId);
            varInstance = script.generateNewCommand(ScriptVariable.INSTANCE, ctx.getState().getInstanceClass(), varInitiator, Literal.NULL,
                    varKicker, BooleanLiteral.FALSE, varMessageId, Literal.NULL);
        }

        // create a bridge object if the process is provided through a synchronous web service call excluding inner task flows
        if (!ctx.isTaskFlow() && ctx.getState().isSynchronouslyProvisioned()) {
            final ScriptVariable varBridge = script.generateNewCommand(ScriptVariable.BRIDGE, ctx.getState().getBridgeClass(), varInstance);
            script.generateInvocationCommand(varBridge, "setRequest", varRequest);
        }

        // token=new BPMN:Token(instance,"initial");
        final int label = ctx.getState().getAfterTokenLabel(startEvent);
        final ScriptVariable varToken = script.generateNewCommand(ScriptVariable.TOKEN, ctx.getState().getTokenClass(), varInstance,
                new IntegerLiteral(label));

        // propagate principal from event to token
        if (ctx.isPrincipalPropagationActive()) {
            script.generateInvocationCommand(varToken, CompilerConstants.METHOD_TOKEN_COPY_PRINCIPAL_FROM_EVENT, varEvent);
        }

        // delete event;
        script.generateDeleteCommand(varEvent);

        // debug code
        script.generateDebugCode(varInstance, varToken);

        // new TaskAdapter:Task(parent,INACTIVE,true,false,false,false);
        ScriptVariable varTask = null;
        if (ctx.isTaskFlow()) {
            varTask = script.generateNewCommand(ScriptVariable.TASK, ctx.getState().getTaskSource().getGalaxyClass(), varInstance,
                    new IntegerLiteral(CompilerConstants.CONSTANT_TASK_INACTIVE), BooleanLiteral.TRUE, BooleanLiteral.FALSE,
                    BooleanLiteral.FALSE, BooleanLiteral.FALSE);
        }

        // exception/logging instrumentation
        script.generateScopeCode(varToken);

        // context creation for root scope
        final DonFrame derDon = ctx.getState().getDonFrame();
        final ContextHelper ctxHelper = ctx.getContextHelper();
        final Set<DataContainer> scopeDataContainer = ctx.getState().getDataContainer4Frame(
                derDon.getFrameNode4Scope(startEvent.getScope()));
        for (final DataContainer curDataContainer : scopeDataContainer) {
            final GalaxyClass curDataContainerClass = ctxHelper.getClassByDataObject(curDataContainer);
            // only instantiate the context variable as SDO if it is not the
            // task status (=task variable) itself
            if (!WorkflowHelper.isTaskStatusDataObject(ctx, curDataContainer)) {
                // scope = new TypeRegistry:ScopeX(parent);
                final GalaxyClass clsScope = ctx.getContextHelper().getScopeClass(curDataContainerClass);
                final ScriptVariable varScope = script.generateNewCommand(ScriptVariable.SCOPE, clsScope, varInstance);

                // context_i = new ContainerAdapter:ContextX(parent,scope,0,false,false,null);
                final ScriptVariable varContext = script.generateNewCommand(ctx.getState().getContextVariable(curDataContainer),
                        curDataContainerClass, varInstance, varScope, new IntegerLiteral(curDataContainer instanceof DataObject ? 0 : -1),
                        BooleanLiteral.FALSE, BooleanLiteral.FALSE, Literal.NULL);

                // if in a task flow, pass the context variable to the task
                final String originalName = curDataContainer.getOriginalName();
                if (ctx.isTaskFlow()) {
                    // task:setContainerObject(<name>,do);
                    script.generateInvocationCommand(varTask, "setContainerObject", new StringLiteral(originalName), varContext);
                } else {
                    if (DataContainerConstants.isDefinedAsConstant(originalName)) {
                        // instance:setContainerObject(<name>,do);
                        script.generateInvocationCommand(varInstance, "setContainerObject", new StringLiteral(originalName), varContext);
                    }
                }
            }
        }

        // payload=request:getData();
        final ScriptVariable varPayload = script.generateInvocationCommand(ScriptVariable.PAYLOAD, varRequest, "getData");
        final String scopeId = ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(operation), CompilerType.TYPECOMPILER);

        // mapping code
        final XsdElementDeclaration request = WSDLHelper.getRequestElement(operation);
        script.generateMappingCode(mapping.second, null, identifyInOutDataObjects(ctx, mapping.first, Direction.INOUT).second,
                new Triple<ScriptVariable, XsdElementDeclaration, String>(varPayload, request, scopeId), null);

        // create subscription instances for all intermediate events in inner task flows
        for (final Pair<GalaxyClass, GalaxyClass> subscription_event : ctx.getState().control2subscription_event.values()) {
            // new BPMNAdapter:SubscriptionX(parent,NULL,...,NULL);
            if (subscription_event.first != null) {
                // only do this for intermediate controls
                script.generateNewCommand(subscription_event.first, varInstance);
            }
        }

        // create a subscriptions for all services (aka endpoint, aka message trigger) in processes
        if (ctx.useSunbeamNonConditionalStart() || ctx.useSunbeamConditionalStart()) {
            compileSunbeamSubscriptionCreation(ctx, script, varInstance);
        } else {
            compileLegacySubscriptionCreation(ctx, script, varInstance);
        }

        // create a flight recorder object
        script.generateNewCommand(ctx.getState().getFlightRecorderClass(), varInstance);

        // event logging of the start event
        if (!(startEvent.getScope() instanceof EmbeddedScope) && !ctx.isTaskFlow()) {
            EventLogHelper.addEventWithMsgId(script, ctx.getState().getEventLoggerClass(), EventTypeIds.START_TRIGGERED, ((Pool) ctx
                    .getRootScope()).refMofId(), varInstance, startEvent.refMofId(), varKicker, varMessageId);
        }

        return script.getExecution();
    }

    private void compileLegacySubscriptionCreation(final CompilerContext ctx, final AdvancedScript script, final Parameter varInstance) {
        for (final String services : ctx.getState().getServices()) {
            final GalaxyClass clsSubscription = ctx.getState().getSubscription(services);
            final ScriptVariable varSubscription = script.generateNewCommand(ScriptVariable.SUBSCRIPTION, clsSubscription, varInstance);
            final int startIndex = 1;
            for (int i = startIndex; i < clsSubscription.getAttribute().size(); i = i + 2) {
                final Attribute attCorrelation = clsSubscription.getAttribute().get(i);
                final String extraction = ctx.getState().getCorrelationExtraction(attCorrelation);
                final LinkedHashSet<DataContainer> context = ctx.getState().getCorrelationContext(attCorrelation);
                if (extraction != null) {
                    generateSubscriptionUpdateScript(ctx, script, clsSubscription, varSubscription, attCorrelation, extraction, context);
                } else {
                    script.generateUpdateCommand(varSubscription, attCorrelation, BooleanLiteral.TRUE);
                }
            }
        }

    }

    private void compileSunbeamSubscriptionCreation(final CompilerContext ctx, final AdvancedScript script, final Parameter varInstance) {
        final Collection<MessageTriggerContext> messageTriggerContexts = ctx.getState().getSunbeamHelper().getMessageTriggerContexts();
        for (final MessageTriggerContext messageTriggerContext : messageTriggerContexts) {
            final GalaxyClass clsSubscription = messageTriggerContext.getSubscriptionClass();

            Parameter[] parameters = extractSubscriptionAttributes(ctx, script, varInstance, clsSubscription);
            final ScriptVariable varSubscription = script.generateNewCommand(ScriptVariable.SUBSCRIPTION, clsSubscription, parameters);

            updateModificationCounters(ctx, script, clsSubscription, varSubscription);

        }
    }

    private void updateModificationCounters(final CompilerContext ctx, final AdvancedScript script, final GalaxyClass clsSubscription,
            final ScriptVariable varSubscription) {
        for (int index = 0; index < clsSubscription.getAttribute().size(); index++) {
            Attribute attribute = clsSubscription.getAttribute().get(index);

            if (attribute.getName().startsWith("cor")) {
                final String extraction = ctx.getState().getCorrelationExtraction(attribute);
                if (extraction != null) {
                    final LinkedHashSet<DataContainer> context = ctx.getState().getCorrelationContext(attribute);
                    IntegerLiteral modAttributeIndex = new IntegerLiteral(index + 1);
                    for (DataContainer container : context) {
                        ScriptVariable varContext = ctx.getState().getContextVariable(container);
                        script.generateInvocationCommand(varSubscription, "addModifier", modAttributeIndex, varContext);
                    }
                }
            }
        }
    }

    private Parameter[] extractSubscriptionAttributes(final CompilerContext ctx, final AdvancedScript script, final Parameter varInstance,
            final GalaxyClass clsSubscription) {
        Parameter[] parameters = new Parameter[clsSubscription.getAttribute().size()];
        parameters[0] = varInstance;
        int i = 0;
        for (final Attribute attribute : clsSubscription.getAttribute()) {
            if (attribute.getName().startsWith("cor")) {
                final String extraction = ctx.getState().getCorrelationExtraction(attribute);
                if (extraction != null) {
                    final LinkedHashSet<DataContainer> context = ctx.getState().getCorrelationContext(attribute);
                    parameters[i] = script.generateExpressionCode(extraction, context, null, new ScriptVariable("value" + i),
                            (SimpleType) attribute.getAttributeType());
                } else {
                    parameters[i] = BooleanLiteral.TRUE;
                }
            }
            i++;
        }
        return parameters;
    }
}
