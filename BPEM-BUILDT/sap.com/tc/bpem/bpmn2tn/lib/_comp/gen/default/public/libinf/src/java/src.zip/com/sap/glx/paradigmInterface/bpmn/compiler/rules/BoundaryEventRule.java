package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.Set;

import com.sap.glx.ide.model.galaxy.workflow.BoundaryEvent;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * Simple rule to dispatch the compilation of boundary events 
 * to further rules (TimeoutBoundaryRule and EventionHandlerRule). 
 * 
 * @author Philipp Sommer
 * 
 */

public class BoundaryEventRule extends BaseCompilerRule<BoundaryEvent> {
    private EventionHandlerRule boundaryEventErrorRule = null;
    
    public Class<BoundaryEvent> getSupportedArtifact() {
        return BoundaryEvent.class;
    }
    
    @Override
    public void preprocess(CompilerContext ctx) throws BPMNCompilerException {
    	boolean containsErrorEvents = false;
    	
    	// find out which type of events exist
    	Set<BoundaryEvent> events = ctx.getArtifacts(BoundaryEvent.class);
    	for (BoundaryEvent event : events) {
    		if (event.getEventDefinition() instanceof ErrorEventDefinition) {
    			containsErrorEvents = true;
			}
    	}
    	
    	// create rule in case there is an according artifact
        if (containsErrorEvents) {
        	boundaryEventErrorRule = new EventionHandlerRule();
            boundaryEventErrorRule.preprocess(ctx);
       }
    }
	    
    public void compile(BoundaryEvent event, CompilerContext ctx) throws BPMNCompilerException {
        if (event.getEventDefinition() instanceof ErrorEventDefinition)
            boundaryEventErrorRule.compile(event, ctx);
        else 
    	 	ctx.getValidator().error("BPM.rt_c_bpmn.000021", "Trigger for boundary event '%s' is not supported.", event.getOriginalName());
    }

    @Override
    public void postprocess(CompilerContext ctx) throws BPMNCompilerException {
        if (boundaryEventErrorRule != null)
            boundaryEventErrorRule.postprocess(ctx);
    }
}