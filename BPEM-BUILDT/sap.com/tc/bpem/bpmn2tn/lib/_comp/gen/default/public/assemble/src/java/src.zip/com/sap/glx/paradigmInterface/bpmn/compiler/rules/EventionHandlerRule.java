package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.SortedSet;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.ide.model.galaxy.workflow.Activity;
import com.sap.glx.ide.model.galaxy.workflow.AutomatedActivity;
import com.sap.glx.ide.model.galaxy.workflow.BoundaryEvent;
import com.sap.glx.ide.model.galaxy.workflow.DataContainer;
import com.sap.glx.ide.model.galaxy.workflow.EmbeddedScope;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.Scope;
import com.sap.glx.ide.model.galaxy.workflow.ScopeReference;
import com.sap.glx.ide.model.triggernet.ConstantFilter;
import com.sap.glx.ide.model.triggernet.GenericOperator;
import com.sap.glx.ide.model.triggernet.Join;
import com.sap.glx.ide.model.triggernet.Node;
import com.sap.glx.ide.model.triggernet.RemoteSource;
import com.sap.glx.ide.model.triggernet.Source;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;
import com.sap.glx.paradigmInterface.bpmn.compiler.Pair;
import com.sap.glx.paradigmInterface.bpmn.compiler.Triple;
import com.sap.glx.paradigmInterface.bpmn.compiler.factories.NodeFactory;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.BooleanLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.NullLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.DonFrame;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.FrameNode;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.scope.ProjectionNode;
import com.sap.mapping.base.compiler.IMappingCompiler;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.tc.esmp.mm.xsd1.XsdElementDeclaration;

/**
 * Compiles evention handler artifacts (currently just exception handlers).
 * 
 * @author Thilo-Alexander Ginkel
 * @author Volker Lehmann
 * 
 * @version $Id:
 *          //bpem/bpem.tools/711_SP_COR/src/_com.sap.glx.bpmn2tn/java/com/sap/glx/paradigmInterface/bpmn/compiler/rules/EventionHandlerRule.java#3 $
 */
public class EventionHandlerRule extends BaseCompilerRule<BoundaryEvent> implements CompilerRule<BoundaryEvent> {

    private enum HandlerActivityType{
        SCOPE_REFERENCE,
        AUTOMATED_ACTIVITY,
        EMBEDDED_SCOPE,
        LOOP
    }
    
    private static final String SCOPE_TO_CANCEL = "scope_to_cancel";
    
    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#getSupportedArtifact()
     */
    public Class<BoundaryEvent> getSupportedArtifact() {
        return BoundaryEvent.class;
    }

    /*
     * @see com.sap.glx.paradigmInterface.bpmn.compiler.rules.CompilerRule#compile(com.sap.glx.ide.model.galaxy.workflow.FlowObject,
     *      com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext)
     */
    public void compile(BoundaryEvent handler, CompilerContext ctx) throws BPMNCompilerException {

        ctx.getValidator().validateConnectors(handler, 0, 1);
        ctx.getValidator().validate(handler.getTrigger() instanceof ErrorEventDefinition, 
                "BPM.rt_c_bpmn.000030", "Unsupported evention type associated with handler '%s'.", handler.getOriginalName());

        // ///////////////////////////////////////////////////////////////////////////
        // Prepare exception handling (including correlation expression calculation)
        // ///////////////////////////////////////////////////////////////////////////

        // retrieve the relevant context information of the event
        Activity activity = handler.getActivity();
        HandlerActivityType activityType = getActivityType(handler, ctx);
        Scope dataScope = activity.getScope();
        DonFrame derDon = ctx.getState().getDonFrame();        
        FrameNode dataScopeNode = derDon.getFrameNode4Scope(dataScope);
        boolean isRootScope = derDon.isRootScope(dataScopeNode);
 
        // get the galaxy class for the scope of the catched exception and the node 
        GalaxyClass clsScope = null;
        Node exceptionScope = null;
        switch(activityType){
            case EMBEDDED_SCOPE:
                //in an embedded scope the frame is the scope to check
                FrameNode embeddedFrameNode = derDon.getFrameNode4Scope((Scope) activity);
                clsScope = embeddedFrameNode.getGalaxyClass();
                exceptionScope = ctx.getSourceFactory().getSource4Class(clsScope);
                break;
            case LOOP:
                //in a loop the top frame is the scope to check
                FrameNode cycleFrameNode = derDon.getFrameNode4Scope((Scope) activity);
                FrameNode topFrame = cycleFrameNode.getParent();
                clsScope = topFrame.getGalaxyClass();
                exceptionScope = ctx.getSourceFactory().getSource4Class(clsScope);
                break;
            case SCOPE_REFERENCE: 
                // for scope references its the waiting token
                clsScope = ctx.getState().getTokenClass();
                int state = ctx.getState().getTokenLabel((ScopeReference) activity);
                exceptionScope = ctx.getConstantFilterFactory().generateFilter(handler, "scope_filter", "0/0/1", "INTEGER:" + state, "==");
                NodeFactory.connectNodes(ctx.getState().getTokenSource(), 0, exceptionScope, 0);
                break;
            case AUTOMATED_ACTIVITY:
                // scope is the token before the automated activity
                clsScope = ctx.getState().getTokenClass();
                state = ctx.getState().getBeforeTokenLabel(activity);
                exceptionScope = ctx.getConstantFilterFactory().generateFilter(handler, "scope_filter", "0/0/1", "INTEGER:" + state, "==");
                NodeFactory.connectNodes(ctx.getState().getTokenSource(), 0, exceptionScope, 0);
                break;
        }  

        // filters the exception with the correct id
        ErrorEventDefinition exception = (ErrorEventDefinition) handler.getTrigger();
        String exceptionId = ctx.getHost().getVersionId(exception, CompilerType.EXCEPTIONCOMPILER);
        RemoteSource exceptionSource = ctx.getSourceFactory().generateSource(CompilerConstants.ADAPTER_EXCEPTION, CompilerConstants.GALAXY_EXCEPTION);
        ConstantFilter exceptionFilter = ctx.getConstantFilterFactory().generateFilter(handler, "exception_name", "0/0/3", exceptionId, "==");

        // connect exception source to exception name filter
        NodeFactory.connectNodes(exceptionSource, 0, exceptionFilter, 0);;

        // check that the exception is to be checked in this scope: Exception.scope=Frame/Token
        Join scope_join = ctx.getJoinFactory().generateJoin(handler, "scope_join", "0/0/1", "1/0/-1");
        NodeFactory.connectNodes(exceptionFilter, 0, scope_join, 0);
        NodeFactory.connectNodes(exceptionScope, 0, scope_join, 1);    
        
        // correlation extraction stuff
        Pair<IMappingCompiler.Summary, String> extraction = ctx.getMappingHelper().compile(handler.getExpression());
        Set<DataContainer> usedCorrelationContext = identifySourceDataObjects(ctx, extraction.first);

        GenericOperator evaluatorTarget = ctx.getExecutionFactory().generateExecution(handler, "exception_evaluator");
 
        if(usedCorrelationContext.isEmpty()){
             NodeFactory.connectNodes(scope_join, 0, evaluatorTarget, 0);
        }else{
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, dataScope, handler, null, usedCorrelationContext);
            if(isRootScope){
                //the data scope is the root scope, join has to be configured on the instance object
                //if ex.scope is a frame -> use the parent attribute(0)
                //if ex.scope is a token -> use the owner attribute(0)
                //frame.parent=context.owner respectively token.owner=context.owner 
                Join contextJoin = ctx.getJoinFactory().generateJoin(handler, "context_join", "0/1/0", "1/0/0");
                NodeFactory.connectNodes(scope_join, 0, contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                NodeFactory.connectNodes(contextJoin, 0, evaluatorTarget, 0);
            }else{
                //is in embedded scope, projection contains frame object as first element
                Join contextJoin = null;
                if(activityType == HandlerActivityType.EMBEDDED_SCOPE || activityType == HandlerActivityType.LOOP){
                    //frame.parent=frame@ident
                    contextJoin = ctx.getJoinFactory().generateJoin(handler, "context_join", "0/1/0", "1/0/-1");
                }else{
                    //token.frame=frame@ident
                    contextJoin = ctx.getJoinFactory().generateJoin(handler, "context_join", "0/1/2", "1/0/-1");
                }
                NodeFactory.connectNodes(scope_join, 0, contextJoin, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoin, 1);
                
                //for the target node the frame of the context cascade has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                //Exception and Token/Frame
                usedIndexes.add(0);
                usedIndexes.add(1);
                //ignore frame
                int runningIndex = 3;
                //data objects
                for(int i = 1; i<=projectionSwizzle.getLastIndex(); i++){
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(handler, "context_no_frame_projection", usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(contextJoin, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, evaluatorTarget, 0);
            }
        }   
        
        // compile exception helper class
        GalaxyClass exceptionHelper = ctx.getReplicator().generateExceptionHelperClass(ctx, clsScope, handler);

        // create target to evaluate correlation expression and create ExceptionHelper object
        ctx.getExecutionFactory().setScript(evaluatorTarget, generateEvaluatorScriptHeader(ctx, handler, usedCorrelationContext, activityType, clsScope),
                generateEvaluatorScriptBody(ctx, handler, usedCorrelationContext, evaluatorTarget, extraction.second, exceptionHelper, activityType));

        
        // //////////////////////////////////////////
        // Handle exception (if everything matched)
        // //////////////////////////////////////////

        Source exHelperSource = ctx.getSourceFactory().generateSource(exceptionHelper);

        // ExceptionHelper.valid==BOOLEAN:true?
        ConstantFilter exValidFilter = ctx.getConstantFilterFactory().generateFilter(handler, "exception_valid", "0/0/2", "BOOLEAN:true", "==");
        NodeFactory.connectNodes(exHelperSource, 0, exValidFilter, 0);

        // connect ExceptionHelper to black hole
        NodeFactory.connectNodes(exHelperSource, 0, ctx.getReplicator().getBlackHole(), 0);

        // ExceptionHelper.owner = frame/token
        Join helperScopeJoin = ctx.getJoinFactory().generateJoin(handler, "helper_scope", "0/0/0", "1/0/-1");
        NodeFactory.connectNodes(exValidFilter, 0, helperScopeJoin, 0);
        NodeFactory.connectNodes(exceptionScope, 0, helperScopeJoin, 1);

        // ExceptionHelper.exception = exception
        Join helperExceptionJoin = ctx.getJoinFactory().generateJoin(handler, "exception_helper", "0/0/1", "1/0/-1");
        NodeFactory.connectNodes(helperScopeJoin, 0, helperExceptionJoin, 0);
        NodeFactory.connectNodes(exceptionFilter, 0, helperExceptionJoin, 1);

        // compile the mappings...
        Pair<IMappingCompiler.Summary, String> output_mapping = ctx.getMappingHelper().compile(handler.getOutputMapping());

        // ...and build context join cascade
        Pair<Set<DataContainer>, Set<DataContainer>> context = identifyInOutDataObjects(ctx, output_mapping.first, Direction.INOUT);

        @SuppressWarnings("unchecked")
        Set<DataContainer> usedMappingContext = union(context.first, context.second);

        // handling for depending views
        SortedSet<DataContainer> allViewDependencies = ctx.getState().getAllViewDependencies(usedMappingContext);
        usedMappingContext.addAll(allViewDependencies);
        
        //generate exception handler target for synchronous execution...
        GenericOperator targetExceptionHandler = ctx.getExecutionFactory().generateExecution(handler, "exception_handler");
        
        // ...and set handler script
        ctx.getExecutionFactory().setScript(
                targetExceptionHandler,
                generateHandlerScriptHeader(ctx, handler, exceptionHelper, usedMappingContext, activityType, clsScope),
                generateHandlerScriptBody(ctx, handler, exception, context.first, context.second, usedMappingContext, output_mapping.second,
                        activityType, isRootScope));  
        
        //mapping
        if (usedMappingContext.isEmpty()){
            NodeFactory.connectNodes(helperExceptionJoin, 0, targetExceptionHandler, 0);
        }else{
            ProjectionNode projectionSwizzle = buildContextProjectionNode(ctx, dataScope, handler, null, usedMappingContext);
            if(isRootScope){
                //the data scope is the root scope, join has to be configured on the instance object
                //if ex.scope is a frame -> use the parent attribute(0)
                //if ex.scope is a token -> use the owner attribute(0)
                //frame.parent=context.owner respectively token.owner=context.owner
                Join contextJoinRootScope = ctx.getJoinFactory().generateJoin(handler, "context_join_root_scope", "0/1/0", "1/0/0");
                NodeFactory.connectNodes(helperExceptionJoin, 0, contextJoinRootScope, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoinRootScope, 1);
                NodeFactory.connectNodes(contextJoinRootScope, 0, targetExceptionHandler, 0);
            }else{
                //is in embedded scope, projection contains frame object as first element
                Join contextJoinEmbeddedScope = null;
                if(activityType == HandlerActivityType.EMBEDDED_SCOPE || activityType == HandlerActivityType.LOOP){
                    //frame.parent=frame@ident
                    contextJoinEmbeddedScope = ctx.getJoinFactory().generateJoin(handler, "context_join_embedded_scope_frame", "0/1/0", "1/0/-1");
                }else{
                    //token.frame=frame@ident
                    contextJoinEmbeddedScope = ctx.getJoinFactory().generateJoin(handler, "context_join_embedded_scope_token", "0/1/2", "1/0/-1");
                }
                NodeFactory.connectNodes(helperExceptionJoin, 0, contextJoinEmbeddedScope, 0);
                NodeFactory.connectNodes(projectionSwizzle.getProjectionNode(), 0, contextJoinEmbeddedScope, 1);
                
                //for the target node the frame of the context cascade has to be removed now
                List<Integer> usedIndexes = new ArrayList<Integer>();
                //ExceptionHelper, Token/Frame, Exception
                usedIndexes.add(0);
                usedIndexes.add(1);
                usedIndexes.add(2);
                //ignore frame
                int runningIndex = 4;
                //data objects
                for(int i = 1; i<=projectionSwizzle.getLastIndex(); i++){
                    usedIndexes.add(runningIndex++);
                }
                Swizzle noFrameSwizzle = ctx.getSwizzleFactory().generateSwizzle(handler, "context_no_frame_projection", usedIndexes.toArray(new Integer[usedIndexes.size()]));
                NodeFactory.connectNodes(contextJoinEmbeddedScope, 0, noFrameSwizzle, 0);
                NodeFactory.connectNodes(noFrameSwizzle, 0, targetExceptionHandler, 0);
            }
        }
    }

    private HandlerActivityType getActivityType(BoundaryEvent handler, CompilerContext ctx) throws BPMNCompilerException {
        Activity activity = handler.getActivity();
        HandlerActivityType activityType;
        if(activity instanceof ScopeReference){
            activityType = HandlerActivityType.SCOPE_REFERENCE;
        }else if (activity instanceof AutomatedActivity){
            activityType = HandlerActivityType.AUTOMATED_ACTIVITY;
        }else {
            EmbeddedScope es = (EmbeddedScope) activity;
            if(es.getLoopCharacteristics()!= null){
                activityType = HandlerActivityType.LOOP;
            }else{
                activityType = HandlerActivityType.EMBEDDED_SCOPE;    
            }
        }
        return activityType;
    }

    private String generateEvaluatorScriptHeader(CompilerContext ctx, BoundaryEvent handler, Set<DataContainer> usedContext, HandlerActivityType activityType, GalaxyClass scopeClass) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(ctx.getRootScope(), CompilerConstants.TARGET_EXCEPTION_HANDLER, handler));
        sb.append(ScriptHelper.generateClassDeclaration(
        		CompilerConstants.ADAPTER_EXCEPTION, 
        		CompilerConstants.GALAXY_EXCEPTION,
                new Variable(CompilerConstants.SCRIPT_VARIABLE_EXCEPTION)));
        sb.append(", ");
        
        if(activityType == HandlerActivityType.EMBEDDED_SCOPE || activityType == HandlerActivityType.LOOP){
            sb.append(ScriptHelper.generateClassDeclaration(
                    scopeClass, 
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));  
        }else{
            sb.append(ScriptHelper.generateClassDeclaration(
                    scopeClass, 
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        }
        
        for (DataContainer var : usedContext) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(
            		ctx.getContextHelper().getClassByDataObject(var), 
            		new Variable(ctx.getState().getContextVariableName(var))));
        }

        sb.append(")");
        return sb.toString();
    }

    private String generateEvaluatorScriptBody(CompilerContext ctx, BoundaryEvent handler, Set<DataContainer> usedContext, GenericOperator target,
            String expression_id, GalaxyClass exceptionHelper, HandlerActivityType activityType) {
        StringBuilder sb = new StringBuilder("{ ");

        // script code to compute value of correlation expression: valid=...
        sb.append(ScriptHelper.generateExpressionCode(ctx, expression_id, usedContext, null, new Variable(CompilerConstants.SCRIPT_VARIABLE_VALID),
                ctx.getSimpleTypes().BOOLEAN));

        // new ExceptionHelper(owner, exception, valid);
        sb.append(ScriptHelper.generateNewCommand(
        		null, 
        		exceptionHelper, 
        		(activityType == HandlerActivityType.EMBEDDED_SCOPE || activityType == HandlerActivityType.LOOP)?new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME):new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_EXCEPTION),
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_VALID)));

        sb.append("}");
        return sb.toString();
    }

    private String generateHandlerScriptHeader(CompilerContext ctx, BoundaryEvent handler, GalaxyClass exceptionHelper, Set<DataContainer> usedContext, HandlerActivityType activityType, GalaxyClass scopeClass) {
        StringBuilder sb = new StringBuilder(ScriptHelper.generateHeaderPrefix(
        		ctx.getRootScope(), 
        		CompilerConstants.TARGET_EXCEPTION_HANDLER, handler));
        sb.append(ScriptHelper.generateClassDeclaration(
        		exceptionHelper, 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_HELPER)));
        sb.append(", ");
        if(activityType == HandlerActivityType.EMBEDDED_SCOPE || activityType == HandlerActivityType.LOOP){
            sb.append(ScriptHelper.generateClassDeclaration(
                    scopeClass, 
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME)));
            sb.append(", ");    
        }else{
            //token that matches the exception scope
            sb.append(ScriptHelper.generateClassDeclaration(
                    scopeClass, 
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER)));
            sb.append(", ");
        }
        sb.append(ScriptHelper.generateClassDeclaration(
        		CompilerConstants.ADAPTER_EXCEPTION, 
        		CompilerConstants.GALAXY_EXCEPTION,
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_EXCEPTION)));
        
        for (DataContainer var : usedContext) {
            sb.append(", ");
            sb.append(ScriptHelper.generateClassDeclaration(
            		ctx.getContextHelper().getClassByDataObject(var), 
            		new Variable(ctx.getState().getContextVariableName(var))));
        }

        sb.append(")");
        return sb.toString();
    }

    private String generateHandlerScriptBody(CompilerContext ctx, BoundaryEvent handler, ErrorEventDefinition cause, Set<DataContainer> contextIn,
            Set<DataContainer> contextOut, Set<DataContainer> usedContext, String mapping_id, HandlerActivityType activityType, boolean isRootScope) throws BPMNCompilerException {
        StringBuilder sb = new StringBuilder("{");
        
        //get the instance for the token creation
        if(activityType == HandlerActivityType.EMBEDDED_SCOPE || activityType == HandlerActivityType.LOOP){    
            final String SCOPEHELPER = "scope_helper"; 
            //scopeHelper = new ScopeHelper;
            sb.append(ScriptHelper.generateNewCommand(
                        new Variable(SCOPEHELPER),
                        new Pair<String, String>(CompilerConstants.ADAPTER_BPMN, CompilerConstants.GALAXY_SCOPE_HELPER)));
            //parent = scopeHelper.getInstanceOfScope(SCOPE);  
            sb.append(ScriptHelper.generateInvocationCommand(
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE),
                    new Variable(SCOPEHELPER),
                    CompilerConstants.METHOD_SCOPE_HELPER_GET_INSTANCE_OF_SCOPE,
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME))); 
            //delete scopeHelper
            sb.append(ScriptHelper.generateDeleteCommand(new Variable(SCOPEHELPER)));
        }else{
            //parent = token:owner; 
            sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE),
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER),
                    CompilerConstants.ATTRIBUTE_OWNER));
        }
      
        int nextState = ctx.getState().getAfterTokenLabel(handler);
   
        //create a new token
        if(isRootScope){
            // frame is null
            // token=new Token(owner, nextState)
            sb.append(ScriptHelper.generateNewCommand(
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), 
                    ctx.getState().getTokenClass(),
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE), 
                    new IntegerLiteral(nextState),
                    NullLiteral.NULL));            
        }else{
            // token has to be created in a frame
            //frameParent=frame:parent
            if(activityType == HandlerActivityType.EMBEDDED_SCOPE || activityType == HandlerActivityType.LOOP){
                sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT),
                        new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), 
                        CompilerConstants.ATTRIBUTE_PARENT));
            }else{
                //frameParent=token:frame
                sb.append(ScriptHelper.generateAssignCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT),
                        new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER), 
                        CompilerConstants.ATTRIBUTE_FRAME));
            }
            // token=new Token(owner, nextState, frame)
            sb.append(ScriptHelper.generateNewCommand(
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN), 
                    ctx.getState().getTokenClass(),
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE), 
                    new IntegerLiteral(nextState),
                    new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME_PARENT)));
        }

        // scope code
        sb.append(ScriptHelper.generateScopeCode(ctx.getState().getControllerClass(), new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));
        
        // debug code
        sb.append(ScriptHelper.generateDebugCode(handler, 
                CompilerConstants.BITMASK_ON_ACTIVATION,
                new Variable(CompilerConstants.SCRIPT_VARIABLE_INSTANCE), 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_TOKEN)));

        // document = exception:getPayload();
        sb.append(ScriptHelper.generateInvocationCommand(
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_DOCUMENT), 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_EXCEPTION),
        		"getPayload"));

        // map from the exception payload
        sb.append(ScriptHelper.generateMappingCode(
        		ctx, 
        		mapping_id, 
        		contextIn, 
        		contextOut, 
        		new Triple<XsdElementDeclaration, Variable, StringLiteral>(
        				getErrorElement(cause), 
        				new Variable(CompilerConstants.SCRIPT_VARIABLE_DOCUMENT), 
        				new StringLiteral(ctx.getHost().getVersionId(ctx.getDependencyHelper().getScope(cause),
                        CompilerType.TYPECOMPILER))), 
                        null));

        // exceptionController=new ExceptionController();
        sb.append(ScriptHelper.generateNewCommand(
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_EX_CONTROLLER), 
        		new Pair<String, String>(CompilerConstants.ADAPTER_EXCEPTION, CompilerConstants.GALAXY_CONTROLLER)));

        // exceptionController:onHandledException(exception);
        sb.append(ScriptHelper.generateInvocationCommand(
        		null, 
        		new Variable(CompilerConstants.SCRIPT_VARIABLE_EX_CONTROLLER),
                CompilerConstants.METHOD_EX_CONTROLLER_ON_HANDLED_EXCEPTION, 
                new Variable(CompilerConstants.SCRIPT_VARIABLE_EXCEPTION)));

        // delete exceptionController();
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EX_CONTROLLER)));

        if (cause.isCritical()) {
            switch(activityType){
                case SCOPE_REFERENCE:
                    // scope_to_cancel=exception:prev_scope;
                    sb.append(ScriptHelper.generateAssignCommand(
                            new Variable(SCOPE_TO_CANCEL), 
                            new Variable(CompilerConstants.SCRIPT_VARIABLE_EXCEPTION), 
                            CompilerConstants.ATTRIBUTE_PREV_SCOPE));

                    sb.append(ScriptHelper.generateCancellationScript(new Variable(SCOPE_TO_CANCEL)));
                    // delete the waiting token
                    sb.append(ScriptHelper.generateDeleteCommand(
                            new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER)));
                    break;
                case AUTOMATED_ACTIVITY:
                    // delete the token on the incoming connector of the automated activity
                    sb.append(ScriptHelper.generateDeleteCommand(
                            new Variable(CompilerConstants.SCRIPT_VARIABLE_KICKER)));
                    break;
                case EMBEDDED_SCOPE:
                case LOOP:
                    sb.append(ScriptHelper.generateUpdateCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_FRAME), CompilerConstants.ATTRIBUTE_CANCELLED, BooleanLiteral.TRUE));
                    break;
            }
        }
        
        // delete exception;
        sb.append(ScriptHelper.generateDeleteCommand(new Variable(CompilerConstants.SCRIPT_VARIABLE_EXCEPTION)));
        
        sb.append("}");
        return sb.toString();
    }

    private XsdElementDeclaration getErrorElement(ErrorEventDefinition error) {
        if (error.getWsdlFault() != null) {
            return error.getWsdlFault().getElement();
        } else {
            return error.getParameter();
        }
    }
}
