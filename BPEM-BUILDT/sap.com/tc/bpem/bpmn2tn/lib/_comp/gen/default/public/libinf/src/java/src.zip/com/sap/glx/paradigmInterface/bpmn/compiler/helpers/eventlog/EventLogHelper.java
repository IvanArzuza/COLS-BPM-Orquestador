package com.sap.glx.paradigmInterface.bpmn.compiler.helpers.eventlog;

import com.sap.glx.ide.model.classes.GalaxyClass;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerConstants;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.ScriptHelper;
import com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.Variable;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.AdvancedScript;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.Parameter;
import com.sap.glx.paradigmInterface.bpmn.compiler.scripts.ScriptVariable;

public class EventLogHelper {

    private static final Variable var_eventLoggerInstance = new Variable(CompilerConstants.SCRIPT_VARIABLE_EVENT_LOGGER);
    private static final ScriptVariable script_var_eventLoggerInstance = new ScriptVariable(CompilerConstants.SCRIPT_VARIABLE_EVENT_LOGGER);

    public static void addEvent(final AdvancedScript script, final GalaxyClass eventLoggerClass, final EventTypeIds eventType,
            final String processDefId, final Parameter processInstance, final String artifactMofId, final Parameter refMofId) {
        script.generateNewCommand(script_var_eventLoggerInstance, eventLoggerClass);
        script.generateInvocationCommand(script_var_eventLoggerInstance, CompilerConstants.METHOD_CREATE_EVENT_LOG_ENTRY,
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.IntegerLiteral(eventType.getId()),
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral(processDefId), processInstance,
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral(artifactMofId), refMofId);
        script.generateDeleteCommand(script_var_eventLoggerInstance);
    }

    public static void addEvent(final StringBuilder sb, final GalaxyClass eventLoggerClass, final EventTypeIds eventType,
            final String processDefId, final Variable processInstance, final String artifactMofId, final Variable refMofId) {
        sb.append(ScriptHelper.generateNewCommand(var_eventLoggerInstance, eventLoggerClass));
        sb.append(ScriptHelper.generateInvocationCommand(null, var_eventLoggerInstance, CompilerConstants.METHOD_CREATE_EVENT_LOG_ENTRY,
                new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral(eventType.getId()),
                new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral(processDefId), processInstance,
                new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral(artifactMofId), refMofId));
        sb.append(ScriptHelper.generateDeleteCommand(var_eventLoggerInstance));
    }

    public static void addEventWithMsgId(final AdvancedScript script, final GalaxyClass eventLoggerClass, final EventTypeIds eventType,
            final String processDefId, final Parameter processInstance, final String artifactMofId, final Parameter refMofId,
            final Parameter messageId) {
        script.generateNewCommand(script_var_eventLoggerInstance, eventLoggerClass);
        script.generateInvocationCommand(script_var_eventLoggerInstance, CompilerConstants.METHOD_CREATE_EVENT_LOG_ENTRY_WITH_MSGID,
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.IntegerLiteral(eventType.getId()),
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral(processDefId), processInstance,
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral(artifactMofId), refMofId, messageId);
        script.generateDeleteCommand(script_var_eventLoggerInstance);
    }

    public static void addEventWithMsgId(final StringBuilder sb, final GalaxyClass eventLoggerClass, final EventTypeIds eventType,
            final String processDefId, final Variable processInstance, final String artifactMofId, final Variable refMofId,
            final Variable messageId) {
        sb.append(ScriptHelper.generateNewCommand(var_eventLoggerInstance, eventLoggerClass));
        sb.append(ScriptHelper.generateInvocationCommand(null, var_eventLoggerInstance,
                CompilerConstants.METHOD_CREATE_EVENT_LOG_ENTRY_WITH_MSGID,
                new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral(eventType.getId()),
                new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral(processDefId), processInstance,
                new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral(artifactMofId), refMofId, messageId));
        sb.append(ScriptHelper.generateDeleteCommand(var_eventLoggerInstance));
    }

    public static void addEventWithMsgContext(final AdvancedScript script, final GalaxyClass eventLoggerClass, final EventTypeIds eventType,
            final String processDefId, final Parameter processInstance, final String artifactMofId, final Parameter refMofId,
            final Parameter messageId, final String componentName, final String interfaceName) {
        script.generateNewCommand(script_var_eventLoggerInstance, eventLoggerClass);
        script.generateInvocationCommand(script_var_eventLoggerInstance, CompilerConstants.METHOD_CREATE_EVENT_LOG_ENTRY_WITH_MSGCONTEXT,
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.IntegerLiteral(eventType.getId()),
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral(processDefId), processInstance,
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral(artifactMofId), refMofId, messageId,
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral(componentName),
                new com.sap.glx.paradigmInterface.bpmn.compiler.scripts.StringLiteral(interfaceName));
        script.generateDeleteCommand(script_var_eventLoggerInstance);
    }

    public static void addRDSEvent(final StringBuilder sb, final GalaxyClass eventLoggerClass, final String processDefId,
            final Variable processInstance, final String artifactMofId, final Variable refMofId, final String rdsMofId, final Variable sdo) {
        sb.append(ScriptHelper.generateNewCommand(var_eventLoggerInstance, eventLoggerClass));
        sb.append(ScriptHelper
                .generateInvocationCommand(null, var_eventLoggerInstance, CompilerConstants.METHOD_CREATE_RDS_LOG_ENTRY,
                        new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.IntegerLiteral(EventTypeIds.DATA_OBJECT_PERSISTED
                                .getId()), new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral(processDefId),
                        processInstance, new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral(artifactMofId),
                        refMofId, new com.sap.glx.paradigmInterface.bpmn.compiler.helpers.literals.StringLiteral(rdsMofId), sdo));
        sb.append(ScriptHelper.generateDeleteCommand(var_eventLoggerInstance));
    }

}
