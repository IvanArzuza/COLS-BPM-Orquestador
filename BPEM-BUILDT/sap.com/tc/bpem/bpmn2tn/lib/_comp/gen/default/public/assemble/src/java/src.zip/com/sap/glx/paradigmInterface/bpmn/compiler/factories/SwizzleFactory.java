package com.sap.glx.paradigmInterface.bpmn.compiler.factories;

import java.util.Arrays;

import com.sap.glx.ide.model.galaxy.core.ModelElement;
import com.sap.glx.ide.model.triggernet.Subnet;
import com.sap.glx.ide.model.triggernet.Swizzle;
import com.sap.glx.paradigmInterface.facades.ITriggernetFacade;

public class SwizzleFactory extends NodeFactory {

    public SwizzleFactory(ITriggernetFacade facade, Subnet subnet) {
        super(facade, subnet);
    }

    @Override
    protected String getNodePrefix() {
        return "SWIZZLE"; //$NON-NLS-1$
    }

    @Override
    protected int getInputCount() {
        return 1;
    }

    @Override
    protected int getOutputCount() {
        return 1;
    }

    public Swizzle generateSwizzle(ModelElement artifact, String name, Integer... order) {
        Swizzle swizzle = createElement(Swizzle.class);
        prepareNode(swizzle, artifact, name);
        swizzle.getParameters().addAll(Arrays.asList(order));
        return swizzle;
    }
}
