package com.sap.glx.paradigmInterface.bpmn.compiler.rules;

import java.util.Set;

import com.sap.glx.ide.model.galaxy.workflow.EndEvent;
import com.sap.glx.ide.model.galaxy.workflow.ErrorEventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.EventDefinition;
import com.sap.glx.ide.model.galaxy.workflow.IntermediateThrowEvent;
import com.sap.glx.ide.model.galaxy.workflow.ThrowEvent;
import com.sap.glx.paradigmInterface.bpmn.compiler.BPMNCompilerException;
import com.sap.glx.paradigmInterface.bpmn.compiler.CompilerContext;

/**
 * Simple rule to dispatch the compilation of throw events to
 * to further rules.
 *
 * @see RaiseEventionRule
 * @see EndControlRule
 * @see ErrorEndControlRule
 * @see BlankEndEventRule
 * 
 * @author Philipp Sommer
 */

public class ThrowEventRule extends BaseCompilerRule<ThrowEvent> {
	
	private RaiseEventionRule raiseEventionRule = null;
	private EndControlRule messageEndEventRule = null;
	private ErrorEndControlRule errorEndEventRule = null;
	private BlankEndEventRule blankEndEventRule = null;
	
    public Class<ThrowEvent> getSupportedArtifact() {
        return ThrowEvent.class;
    }
    
    @Override
    public void preprocess(CompilerContext ctx) throws BPMNCompilerException {
    	boolean containsIntermediateErrors = false;
    	boolean containsMessageEnds = false;
    	boolean containsErrorEnds = false;
    	boolean containsBlankEnds = false;
        	
    	// find out which type of events exist
    	Set<ThrowEvent> events = ctx.getArtifacts(ThrowEvent.class);
    	for (ThrowEvent event : events) {
    		EventDefinition definition = event.getEventDefinition();
    		if (event instanceof IntermediateThrowEvent) {
    		    ctx.getValidator().validate(definition instanceof ErrorEventDefinition, "BPM.rt_c_bpmn.000055",
    		            "Unsupported result of intermediate throw event '%s'.", event.getOriginalName());
    		    containsIntermediateErrors = true;
    		} else {
    			if (ctx.getState().isSynchronousEndEvent((EndEvent) event)) {
    				containsMessageEnds = true;
    			} else if (definition instanceof ErrorEventDefinition){
    			    containsErrorEnds = true;
    			} else {
    				containsBlankEnds = true;
        		}
    		}
    	}
    	
    	// create rules in case there is an according artifact
    	if (containsIntermediateErrors) {
    		raiseEventionRule = new RaiseEventionRule();
    		raiseEventionRule.preprocess(ctx);
        }
        if (containsBlankEnds) {
        	blankEndEventRule = new BlankEndEventRule();
        	blankEndEventRule.preprocess(ctx);
        }
        if (containsMessageEnds) {
        	messageEndEventRule = new EndControlRule();
        	messageEndEventRule.preprocess(ctx);
        }
        if (containsErrorEnds) {
        	errorEndEventRule = new ErrorEndControlRule();
        	errorEndEventRule.preprocess(ctx);
        }
    }

    public void compile(ThrowEvent event, CompilerContext ctx) throws BPMNCompilerException {
		EventDefinition definition = event.getEventDefinition();
		if (event instanceof IntermediateThrowEvent && definition instanceof ErrorEventDefinition) {
			raiseEventionRule.compile(event, ctx);
		} else {
			EndEvent endEvent = (EndEvent) event;
			if (ctx.getState().isSynchronousEndEvent(endEvent)){
				messageEndEventRule.compile(endEvent, ctx);
			} else if (definition instanceof ErrorEventDefinition){
			    errorEndEventRule.compile(endEvent, ctx);
			} else {
			    blankEndEventRule.compile(endEvent, ctx);
			}
		}
     }

    @Override
    public void postprocess(CompilerContext ctx) throws BPMNCompilerException {
    	if (raiseEventionRule != null)
    		raiseEventionRule.postprocess(ctx);
        if (blankEndEventRule != null)
        	blankEndEventRule.postprocess(ctx);
    	if (messageEndEventRule != null)
    		messageEndEventRule.postprocess(ctx);
        if (errorEndEventRule != null)
        	errorEndEventRule.postprocess(ctx);
    }
}