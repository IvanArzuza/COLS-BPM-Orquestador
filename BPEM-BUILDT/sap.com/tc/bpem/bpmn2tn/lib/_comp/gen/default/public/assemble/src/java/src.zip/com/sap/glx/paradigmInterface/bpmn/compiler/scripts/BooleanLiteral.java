package com.sap.glx.paradigmInterface.bpmn.compiler.scripts;


public class BooleanLiteral extends Literal<Boolean> implements Parameter {
    
    public static BooleanLiteral FALSE = new BooleanLiteral(false);
    public static BooleanLiteral TRUE = new BooleanLiteral(true);
    
    private BooleanLiteral(boolean value) {
        super(value);
    }
}
