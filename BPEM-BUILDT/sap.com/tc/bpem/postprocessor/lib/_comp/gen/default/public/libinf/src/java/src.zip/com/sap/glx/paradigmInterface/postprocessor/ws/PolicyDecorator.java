package com.sap.glx.paradigmInterface.postprocessor.ws;

import com.sap.tc.esmp.tools.wsdlexport.ExporterContext;
import com.sap.tc.esmp.tools.wsdlexport.SoapWsdl1ExporterExtension;
import com.sap.tc.esmp.tools.wsdlexport.WsdlExportException;

public class PolicyDecorator extends SoapWsdl1ExporterExtension {

	private WSSecurityPolicyUtils helper;
	
	public PolicyDecorator(String bindingName, String serviceName,
			String soapActionValue, String soapAddressLocation, String portName) {
		super(bindingName, serviceName, soapActionValue, soapAddressLocation,
				portName);
		helper = new WSSecurityPolicyUtils(soapAddressLocation);
	}

	@Override
	public void execute(ExporterContext context){
		super.execute(context);
		try {
			helper.decorate(context);
		} catch (WsdlExportException e) {
			throw new RuntimeException("Could not insert policy entries into WSDL.", e);
		}
	}
}
