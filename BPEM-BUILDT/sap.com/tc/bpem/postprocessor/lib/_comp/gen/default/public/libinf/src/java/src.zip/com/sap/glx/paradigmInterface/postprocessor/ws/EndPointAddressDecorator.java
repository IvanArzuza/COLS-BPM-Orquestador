package com.sap.glx.paradigmInterface.postprocessor.ws;

import java.net.MalformedURLException;
import java.net.URL;

import com.sap.tc.esmp.tools.wsdlexport.ExporterContext;
import com.sap.tc.esmp.tools.wsdlexport.Wsdl1ExporterExtension;
import com.sap.tc.esmp.tools.wsdlexport.WsdlExportException;

public class EndPointAddressDecorator implements Wsdl1ExporterExtension {

	private WSSecurityPolicyUtils helper;

	public EndPointAddressDecorator(String endpointAddress) throws MalformedURLException {
		// test the syntax of endpoint address URL
		new URL(endpointAddress);
		helper = new WSSecurityPolicyUtils(endpointAddress);
	}

	public void execute(ExporterContext context) throws WsdlExportException {
		helper.decorate(context);
	}

}
