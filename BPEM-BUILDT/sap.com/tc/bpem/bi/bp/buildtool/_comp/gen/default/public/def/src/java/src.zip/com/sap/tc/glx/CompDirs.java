package com.sap.tc.glx;

import java.io.File;

import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;

public class CompDirs {

    private CompilerType compiler; // An instance of the compiler
    private File targetDir; // The corresponding directory in the sda layout
    private String classString; // String identifying the class representation of the compiler
    private boolean newTocEntry; // newly created files always create a new entry in the version registry

    CompDirs(CompilerType comp, String target, String clString, boolean newTocEntry) {
        compiler = comp;
        targetDir = new File(target);
        classString = clString;
        this.newTocEntry = newTocEntry;
    }

    public CompilerType getCompiler() {
        return compiler;
    }

    public File getTargetDir() {
        return targetDir;
    }

    public String getClassString() {
        return classString;
    }

    public boolean newTocEntry() {
        return newTocEntry;
    }
}