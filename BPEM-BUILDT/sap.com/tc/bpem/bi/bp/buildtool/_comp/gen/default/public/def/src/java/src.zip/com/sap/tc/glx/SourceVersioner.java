package com.sap.tc.glx;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes;
import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.ICompiler2;
import com.sap.glx.paradigmInterface.buildapi.SourceArtifact;
import com.sap.glx.paradigmInterface.buildapi.VisualizationArtifact;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.BuildPluginLogConstants;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;

/**
 * SourceVersioner is a dummy compiler, which generates version id information for source files
 */
public class SourceVersioner implements ICompiler, ICompiler2<Collaboration, VisualizationArtifact> {

    private static String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + SourceVersioner.class.getName();
    ArrayList<String> fileList;
    static final int BUFFER_SIZE = 8192;   //using a buffer of 8Kb

    /**
     * Any artifact is processed which has a file representation in the DC Now it takes workflows and tasks
     */
    public boolean canCompile(Object artifact) {
        return true;
    }

    /**
     * No dependencies
     */
    public Object[] getDependencies(IBuilderHost host, Object artifact) {
        return new Object[0];
    }

    /**
     * Dummy compiler, so no real action, only version id creation
     */
    public boolean compile(IBuilderHost host, Object artifact) throws Exception {
        Log.debug(logPrefix + " compile(IBuilderHost host, Object artifact) - entering. ");

        Log.info(logPrefix + " compile(host, artifact) - Generating version IDs for sources...");

        // Getting root directory of DC
        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        File dcRoot = pbi.getRootDir();

        fileList = new ArrayList<String>();

        // Copying def files
        File def_inputDir = new File(dcRoot, BuildPluginConstants.DEF_DIR);
        File[] inputs = def_inputDir.listFiles();
       
        String child  = BuildPluginConstants.DEF_DIR + BuildPluginConstants.FILE_SEPARATOR ;
        addFilesToFileList(inputs, child);       

        // Copying collaboration files
        FilenameFilter filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.COLLABORATION_EXTENSION);
            };
        };

        String w = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.COLLABORATION);
        File workflow_inputDir = new File(dcRoot, w);
        inputs = workflow_inputDir.listFiles(filter);
        addFilesToFileList(inputs, w);

        // Copying old workflow files
        filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.COLLABORATION_EXTENSION_OLD);
            };
        };

        String w_old = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR + BuildPluginConstants.WORKFLOW_DIRECTORY_OLD;
        File workflow_old_inputDir = new File(dcRoot, w_old);
        inputs = workflow_old_inputDir.listFiles(filter);
        addFilesToFileList(inputs, w_old);

        // Copying task files
        filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.TASK_EXTENSION);
            };
        };

        String t = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.TASK);
        File tasks_inputDir = new File(dcRoot, t);
        inputs = tasks_inputDir.listFiles(filter);
        addFilesToFileList(inputs, t);

        /*
         * No need to copy wsdl files in src folder
         * See: https://wiki.wdf.sap.corp/display/bpem/Cross-DC+Service+Group+Usage#Cross-DCServiceGroupUsage-BuildTime%3ACopyingtheWSDL
         */
        // Copying wsdl files
//        String ws = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
//                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.WSDL);
//        File wsdl_inputDir = new File(dcRoot, ws);
//        inputs = wsdl_inputDir.listFiles();
//        if (inputs != null)
//            for (File input : inputs) {
//                if (input.isFile()) {
//                    fileList.add(new String(ws + input.getName()));
//                } else if (input.isDirectory()) {
//                    getSubdirFiles(ws, input);
//                }
//            }

        // Copying brms files
        String brms = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMS);
        File brms_inputDir = new File(dcRoot, brms);
        String[] allowedExtensions = new String[]{BuildPluginConstants.PROJECT_EXT, BuildPluginConstants.SHAREDRES_EXT, 
        		BuildPluginConstants.RULESET_EXT, BuildPluginConstants.ALIASSET_EXT}; 
        inputs = filter(brms_inputDir, allowedExtensions);
        addFilesToFileList(inputs, brms);
        
        // Copying brms/validationmessages.xml if exists
        String validationMessages = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
        + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMS) + BuildPluginConstants.VALIDATION_MSGS_FILE_NAME;
        File validationMessagesFile = new File(dcRoot, validationMessages);
        if(validationMessagesFile.exists() && validationMessagesFile.isFile()){
        	fileList.add(new String(brms+validationMessagesFile.getName()));
        }
        
        // Copying allowed files in brms/ws
        String brms_ws = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
        + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMS) + BuildPluginConstants.WS + BuildPluginConstants.FILE_SEPARATOR;
        File brms_ws_inputDir = new File(dcRoot, brms_ws);
        allowedExtensions = new String[]{BuildPluginConstants.CSDL_EXT, BuildPluginConstants.RULESSCDL_EXT}; 
        inputs = filter(brms_ws_inputDir, allowedExtensions);
        addFilesToFileList(inputs, brms_ws);
        
        // Copying allowed files in brms/diagrams
        String brms_diagrams = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
        + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMS) + BuildPluginConstants.DIAGRAMS + BuildPluginConstants.FILE_SEPARATOR;
        File brms_diagram_inputDir = new File(dcRoot, brms_diagrams);
        allowedExtensions = new String[]{BuildPluginConstants.DIAGRAM_EXT}; 
        inputs = filter(brms_diagram_inputDir, allowedExtensions);
        addFilesToFileList(inputs, brms_diagrams);

        // Copying brmstests files
        String brmstests = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMSTESTS);
        File brmstests_inputDir = new File(dcRoot, brmstests);
        inputs = brmstests_inputDir.listFiles();
        addFilesToFileList(inputs, brmstests);

        // Copying event definition files
        filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.EVENTDEF_EXTENSION);
            };
        };

        String ed = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.EVENT_DEFINITION);
        File eventdef_inputDir = new File(dcRoot, ed);
        inputs = eventdef_inputDir.listFiles(filter);
        addFilesToFileList(inputs, ed);

	
        int index = CompilerRegistry.getIndex(); // Current compiler index in
        // the CompilerRegistry
        for (String str : fileList) {          
           OutputStream oStream = host.createVersionedTargetFile(CompilerRegistry.COMPILERS[index].getTargetDir() + str, str);       
            File file = new File(dcRoot + BuildPluginConstants.FILE_SEPARATOR + str);
            FileInputStream iStream = new FileInputStream(file);
            byte[] buffer = new byte[BUFFER_SIZE];
            while (true) {
                int readCount = iStream.read(buffer);
                if (readCount == -1) {
                        break;
                }
                // It's important to use write method as we have it's
                // implementation
                // overridden in IBuilderHost implementation.
                oStream.write(buffer, 0, readCount);
            }             
            oStream.close();
            iStream.close();
            
        }

        Log.debug(logPrefix + " compile(IBuilderHost host, Object artifact) - exiting. ");
        return true;
    }

    private void addFilesToFileList(File[] inputs, String ed) {
        if (inputs != null)
            for (File input : inputs) {
                if (input.isFile()) {
                    if(input.length()==0){
                        Log.warn(String.format("%s [WARNING]:  Packaging of empty file is not supported. File { %s } in  folder { %s } will not be packaged for deployment. ", logPrefix,input.getName(),input.getPath()));
                    }else {
                        fileList.add(ed + input.getName());
                    }
                } else if (input.isDirectory()) {
                    if (isValidSource(input)) {
                        getSubdirFiles(ed, input);
                    }
                }
            }
    }

    private boolean isValidSource(File input) {
        if (input.getPath().endsWith(".svn")||input.getPath().endsWith(".cvs")) {
            return false;
        }else{
            return true;
        }
    }

    /**
     * Dummy compiler, so no real action, only version id creation
     */
    public boolean compile(IBuilderHost2 host, VisualizationArtifact artifact) throws BpemBuildException {

        Log.debug(logPrefix + " compile(IBuilderHost2 host, Object artifact) - entering. ");

        Log.info("Generating version IDs for sources...");

        // Getting root directory of DC
        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        File dcRoot = pbi.getRootDir();

        fileList = new ArrayList<String>();

        // Copying def files
        File def_inputDir = new File(dcRoot, BuildPluginConstants.DEF_DIR);
        File[] inputs = def_inputDir.listFiles();
        String child = BuildPluginConstants.DEF_DIR + BuildPluginConstants.FILE_SEPARATOR;
        addFilesToFileList(inputs, child);      

        // Copying collaboration files
        FilenameFilter filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.COLLABORATION_EXTENSION);
            };
        };

        String w = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.COLLABORATION);
        File workflow_inputDir = new File(dcRoot, w);
        inputs = workflow_inputDir.listFiles(filter);
        addFilesToFileList(inputs,w);

        // Copying old workflow files
        filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.COLLABORATION_EXTENSION_OLD);
            };
        };

        String w_old = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR + BuildPluginConstants.WORKFLOW_DIRECTORY_OLD;
        File workflow_old_inputDir = new File(dcRoot, w_old);
        inputs = workflow_old_inputDir.listFiles(filter);
        addFilesToFileList(inputs, w_old);

        // Copying task files
        filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.TASK_EXTENSION);
            };
        };

        String t = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.TASK);
        File tasks_inputDir = new File(dcRoot, t);
        inputs = tasks_inputDir.listFiles(filter);
        addFilesToFileList(inputs, t);

        // Copying wsdl files
        String ws = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.WSDL);
        File wsdl_inputDir = new File(dcRoot, ws);
        inputs = wsdl_inputDir.listFiles();
        addFilesToFileList(inputs, ws);
        // Copying brms files
        String brms = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMS);
	 	File brms_inputDir = new File(dcRoot, brms);
        String[] allowedExtensions = new String[]{BuildPluginConstants.PROJECT_EXT, BuildPluginConstants.SHAREDRES_EXT, 
        		BuildPluginConstants.RULESET_EXT, BuildPluginConstants.ALIASSET_EXT}; 
        inputs = filter(brms_inputDir, allowedExtensions);
        addFilesToFileList(inputs, brms);
		
		// Copying brms/validationmessages.xml if exists
		String validationMessages = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
		+ CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMS)+ BuildPluginConstants.VALIDATION_MSGS_FILE_NAME;
		File validationMessagesFile = new File(dcRoot, validationMessages);
		if(validationMessagesFile.exists() && validationMessagesFile.isFile()){
			fileList.add(new String(brms+validationMessagesFile.getName()));
		}
		
		// Copying allowed files in brms/ws
		String brms_ws = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
		+ CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMS) + BuildPluginConstants.WS + BuildPluginConstants.FILE_SEPARATOR;
		File brms_ws_inputDir = new File(dcRoot, brms_ws);
		allowedExtensions = new String[]{BuildPluginConstants.CSDL_EXT, BuildPluginConstants.RULESSCDL_EXT}; 
		inputs = filter(brms_ws_inputDir, allowedExtensions);
		addFilesToFileList(inputs, brms_ws);
		
		// Copying allowed files in brms/diagrams
		String brms_diagrams = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
		+ CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMS) + BuildPluginConstants.DIAGRAMS + BuildPluginConstants.FILE_SEPARATOR;
		File brms_diagram_inputDir = new File(dcRoot, brms_diagrams);
		allowedExtensions = new String[]{BuildPluginConstants.DIAGRAM_EXT}; 
		inputs = filter(brms_diagram_inputDir, allowedExtensions);
		addFilesToFileList(inputs, brms_diagrams);
        

        // Copying brmstests files
        String brmstests = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.BRMSTESTS);
        File brmstests_inputDir = new File(dcRoot, brmstests);
        inputs = brmstests_inputDir.listFiles();
        addFilesToFileList(inputs, brmstests);

        // Copying event definition files
        filter = new FilenameFilter() {

            public boolean accept(File dir, String name) {
                return name.endsWith(BuildPluginConstants.EVENTDEF_EXTENSION);
            };
        };

        String ed = BuildPluginConstants.SRC_DIR + BuildPluginConstants.FILE_SEPARATOR
                + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.EVENT_DEFINITION);
        File eventdef_inputDir = new File(dcRoot, ed);
        inputs = eventdef_inputDir.listFiles(filter);
        addFilesToFileList(inputs, ed);

        for (String str : fileList) {
            // Log.info("str: " + str);
			// Log.info("str2: " +
			// CompilerRegistry.COMPILERS[index].getTargetDir() + str);
			OutputStream oStream = host
					.createVersionedTargetFile(
							CompilerRegistry
									.getCompilerTargetDir(CompilerTypes.CompilerType.SOURCEVERSIONER)
									+ str, new SourceArtifact(str, host));
			File file = new File(dcRoot + BuildPluginConstants.FILE_SEPARATOR
					+ str);
			FileInputStream iStream;
			try {
				iStream = new FileInputStream(file);
				 byte[] buffer = new byte[BUFFER_SIZE];
		            while (true) {
						int readCount = iStream.read(buffer);
						if (readCount == -1) {
							break;
						}					
					// It's important to use write method as we have it's
					// implementation
					// overridden in IBuilderHost implementation.
					oStream.write(buffer, 0, readCount);
				}
				oStream.close();
				iStream.close();
			} catch (FileNotFoundException e) {
				throw new BpemBuildException(e);
			} catch (IOException e) {
				throw new BpemBuildException(e);
			}
        }
        Log.debug(logPrefix + " compile(IBuilderHost2 host, Object artifact) - exiting. ");
        return true;
    }
    private void getSubdirFiles(String parent, File subdir) {
        File[] inputs = subdir.listFiles();
        if (inputs != null)
            for (File input : inputs) {
                if (input.isFile()) {
                    fileList.add(new String(parent + subdir.getName() + BuildPluginConstants.FILE_SEPARATOR + input.getName()));
                } else if (input.isDirectory()) {
                    getSubdirFiles(parent + subdir.getName() + BuildPluginConstants.FILE_SEPARATOR, input);
                }
            }

    }
    
    /**
     * Returns files with extension as one of the extensions
     * @param folder
     * @param extensions
     * @return
     */
    private File[] filter(File folder, final String[] extensions){
    	FilenameFilter fileFilter = new FilenameFilter() {
			@Override
			public boolean accept(File dir, String name) {
				for (String extension : extensions) {
					if (name.endsWith(extension)) {
						return true;
					}
				}
				return false;
			}
		};
		return folder.listFiles(fileFilter);
    }

    /**
     * No dependencies
     */
    public IArtifact<?>[] getDependencies(IBuilderHost2 host, VisualizationArtifact artifact) {
        return new IArtifact<?>[0];
    }
}
