package com.sap.tc.glx;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.tools.ant.BuildException;

import com.sap.glx.ide.model.galaxy.task.Task;
import com.sap.glx.ide.model.galaxy.workflow.Collaboration;
import com.sap.glx.ide.model.galaxy.workflow.EventDefinition;
import com.sap.glx.paradigmInterface.buildapi.ICompiler;
import com.sap.glx.paradigmInterface.buildapi.IPostProcessor;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.BuildPluginLogConstants;
import com.sap.glx.paradigmInterface.util.BuildPluginUtilities;
import com.sap.glx.paradigmInterface.util.EhpVersionChecker;
import com.sap.glx.paradigmInterface.util.GenerateSDA;
import com.sap.glx.paradigmInterface.util.PackageWsdlUtil;
import com.sap.glx.paradigmInterface.util.TmpDirUtil;
import com.sap.glx.paradigmInterface.util.ToolUtils;
import com.sap.sdm.ant.api.JarSAPException;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.moin.ant.instance.MoinTaskData;
import com.sap.tc.moin.ant.task.MoinAntTask;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.ModelPartition;
import com.sap.tc.moin.repository.PRI;
import com.sap.tc.moin.repository.Partitionable;
import com.sap.tc.moin.repository.consistency.ConsistencyViolation;
import com.sap.tc.moin.repository.mmi.reflect.RefObject;
import com.sap.tc.moin.repository.ocl.OclRegistryService;
import com.sap.tc.moin.repository.ocl.metamodel.OclMetamodelConstraintRegistry;
import com.sap.tc.moin.repository.ocl.notification.DeferredConstraintViolationStatus;
import com.sap.tc.moin.repository.ocl.notification.DeferredConstraintViolationStatusItem;
import com.sap.tc.moin.repository.ocl.notification.OclManagerException;
import com.sap.tc.moin.repository.ocl.registry.OclRegistrationSeverity;
import com.sap.tc.moin.util.properties.Property;
import com.sap.tc.moin.util.properties.PropertyBag;

public class BpemTask extends MoinAntTask {

    HashMap<CompilerType, List<Object>> compedObjects;
    BuilderHostImpl builder;
    MoinTaskData td;
    private static final String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + BpemTask.class.getName();    

    @Override
    public void execute() throws BuildException {
        Log.debug(logPrefix + " execute() - entering.");

        td = getTaskData();
        Connection conn = td.getConnection();

        // Getting name, vendor and root directory
        IPluginBuildInfo pbi = (IPluginBuildInfo) BuildSessionManager.getFromBuildSession(IPluginBuildInfo.class.getName());
        IGlobalPluginUtil gpu = (IGlobalPluginUtil) BuildSessionManager.getFromBuildSession(IGlobalPluginUtil.class.getName());

        String dcName = pbi.getDCName();
        String dcVendor = pbi.getDCVendor();
        File dcRoot = pbi.getRootDir();

        Log.debug(logPrefix + " execute() - Dc name:" + dcName + "Dc vendor: " + dcVendor + "Dc root:" + dcRoot.getPath());

        try {
            gpu.createTempDir(BuildPluginConstants.GEN_BPEM_DIR + BuildPluginConstants.FILE_SEPARATOR
                    + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.COLLABORATION));
            gpu.createTempDir(BuildPluginConstants.GEN_BPEM_DIR + BuildPluginConstants.FILE_SEPARATOR
                    + CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.TASK));
        } catch (IOException ioE) {
            Log.error(" \"BPM.bp.000000\"  " + logPrefix + "  execute() - Exception during bpm's gen folder generation.", ioE);
            throw new BuildException(ioE);
        }

        // File genWorkflowDir = new File(genRoot, CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.WORKFLOW));
        // genWorkflowDir.mkdir();
        // File genTaskDir = new File(genRoot, CompilerRegistry.ARTIFACT_DIRS.get(BuildPluginConstants.TASK));
        // genTaskDir.mkdir();

        CRI cri = createCRI(dcName, dcVendor);
        HashSet<PRI> hSet = new HashSet<PRI>(conn.getSession().getInnerPartitions(cri));

        // Meta model version check
        Log.info(logPrefix + " execute() - Metamodel version validation...");
        metaModelVersionCheck(hSet, conn);

        // Sanity check
        if ((System.getProperty("com.glx.sanity.check") == null || !(System.getProperty("com.glx.sanity.check").equals("false")))) {
            Log.info(logPrefix + " execute() - Sanity check is enabled, com.glx.sanity.check system property isn't false.");

            // Iterate through partitions
            for (PRI pri : hSet) {
                if (!sanityCheck(conn, pri)) {
                    BuildException e = new BuildException("Consistency violation has been found. Fix your model accordingly.");
                    Log.error(logPrefix + " execute() - " + e.getMessage() + " See the above mentioned warnings.");
                    throw e;
                }
            }
        } else {
            Log.info(logPrefix + " execute() - Sanity check is disabled, com.glx.sanity.check system property is false or doesn't exist.");
        }

        builder = new BuilderHostImpl(conn, cri);
        TmpDirUtil tmpUtil = new TmpDirUtil(dcRoot);
        compedObjects = new HashMap<CompilerType, List<Object>>();

        CompilerRegistry.setArtifactType(BuildPluginConstants.OTHER_ARTIFACT);
        CompilerRegistry.resetIndex();
        
        /*
         * Package wsdls in bpem archive
         * See: https://wiki.wdf.sap.corp/display/bpem/Cross-DC+Service+Group+Usage#Cross-DCServiceGroupUsage-BuildTime%3ACopyingtheWSDL
         */
        PackageWsdlUtil packageWsdlUtil = new PackageWsdlUtil(conn, pbi, cri, builder);
        try {
			packageWsdlUtil.packageWsdls();
		} catch (Exception e1) {
			Log.error(" \"BPM.bp.000018\"  " + logPrefix + "  execute() - Exception during packaging wsdls in bpem archive.", e1);
            throw new BuildException(e1);
		}
    
        // Running dummy compiler for sources first. Done only once during building
        // This is the first (zero indexed) compiler in CompilerRegistry
		try {
            ICompiler currentCompiler = (ICompiler) Class.forName(CompilerRegistry.COMPILERS[0].getClassString()).newInstance();
            currentCompiler.compile(builder, ""); // No artifact is needed to be passed to this dummy compiler
        } catch (Exception e) {
            Log.error(" \"BPM.bp.000001\" " + logPrefix + "  execute() - SourceVersioner malfunction."
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }

        // Getting and compiling brms rules
        Log.info(logPrefix + " execute() - Initiating rule compilation.");
        CompilerRegistry.setArtifactType(BuildPluginConstants.BRMS);

        try {
            // callCompilersForRules(pbi);
            RulesArtifactsCompilationManager manager = new RulesArtifactsCompilationManager(pbi, builder, compedObjects, conn, this);
            manager.manageCompilation();
        } catch (Exception e) {
            Log.error(" \"BPM.bp.000002\" " + logPrefix + "  execute() :  Exception during compilation of rules."
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }

        // Getting and compiling Event Definitions
        Log.info(logPrefix + " execute() - Initiating event definition constraint check.");
        Collection<RefObject> result = queryArtifacts(conn, BuildPluginConstants.EVENT_DEFINITION, cri);
        CompilerRegistry.setArtifactType(BuildPluginConstants.EVENT_DEFINITION);
		// quick performance improvement fix. Using a scoped query to get only
		// the files in the first place would be better.
		HashSet<RefObject> rObjsToCheck = new HashSet<RefObject>();
		for (RefObject rObj : result){
			if (!(rObj.get___Partition().getPri().getPartitionName()
					.endsWith(BuildPluginConstants.EVENT_DEFINITION))) {
				rObjsToCheck.add(rObj);
			}
		}
        try {
            if (System.getProperty("com.glx.checkconstraint") == null || !(System.getProperty("com.glx.checkconstraint").equals("false"))) {
                constraintCheck(conn, rObjsToCheck, "com.sap.glx.ide.event.constraintcategory");
                Log.info(logPrefix + " execute() - Constraint check for event definitions is done.");
            }
        } catch (Exception e) {
            Log.error(" \"BPM.bp.000020\" " + logPrefix
                    + "  execute() - Exception during constraint check of event definitions. Check Your model for problems."
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }
        
        Log.info(logPrefix + " execute() - Initiating event definition compilation.");
        try {
            for (RefObject refobj : result) {
                Log.info(logPrefix + " execute() - Event def: " + refobj.toString());
            }
            callCompilers(result);
        } catch (Exception e) {
            Log.error(" \"BPM.bp.000021\" " + logPrefix + " execute() -  Exception during event definition compilation, compilerType: "
                    + CompilerRegistry.COMPILERS[CompilerRegistry.getIndex()].getCompiler()
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }

        // Getting and compiling tasks
        Log.info(logPrefix + " execute() - Initiating task constraint check.");
        for (RefObject object : result) {
            partitionCheck(object, dcVendor, dcName);
        }
        result = queryArtifacts(conn, BuildPluginConstants.TASK, cri);
        CompilerRegistry.setArtifactType(BuildPluginConstants.TASK);
        try {
            if (System.getProperty("com.glx.checkconstraint") == null || !(System.getProperty("com.glx.checkconstraint").equals("false"))) {
                constraintCheck(conn, result, "com.sap.glx.ide.task.constraintcategory");
                Log.info(logPrefix + " execute() - Constraint check for Tasks is done.");
            }
        } catch (Exception e) {
            Log.error(" \"BPM.bp.000003\" " + logPrefix
                    + "  execute() - Exception during constraint check of tasks. Check Your model for problems."
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }

        Log.info(logPrefix + " execute() - Initiating task compilation.");
        try {
            callCompilers(result);
        } catch (Exception e) {
            Log.error(" \"BPM.bp.000004\" " + logPrefix + " execute() -  Exception during task compilation, compilerType: "
                    + CompilerRegistry.COMPILERS[CompilerRegistry.getIndex()].getCompiler()
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }

        // Data mapping validation
        Log.info(logPrefix + " execute() - Initiating data mapping validation.");
        try {
        	new MappingValidator(conn, cri, builder.getWarnable()).validate();
        	Log.info(logPrefix + " execute() - Data mapping validation is done.");
        } catch(MappingValidator.ValidationErrorsDetectedException e) {
        	Log.error(" \"BPM.bp.000023\" " + logPrefix + " execute() - " + e.getMessage());
        	throw new BuildException(e);
        }
        
        // Getting and compiling processes
        Log.info(logPrefix + " execute() - Initiating process constraint check.");
        result = queryArtifacts(conn, BuildPluginConstants.COLLABORATION, cri);
        for (RefObject object : result) {
            partitionCheck(object, dcVendor, dcName);
        }
        CompilerRegistry.setArtifactType(BuildPluginConstants.COLLABORATION);
        Collection<RefObject> processesWithIsExcludedFromBuildFlagNotSet = removeProcessesWithIsExcludedFromBuildFlagSet(result); 
        try {
            if ((System.getProperty("com.glx.checkconstraint") == null || !(System.getProperty("com.glx.checkconstraint").equals("false")))) {
				HashSet<String> categories = new HashSet<String>();
				categories.add("com.sap.glx.ide.user.constraintcategory");
				// check if it is an EHP2 project and generate a marker if it
				// isn't
				if (EhpVersionChecker.isEhp2Project()) {
					// the following is a constraint that has only to be
					// evaluated for EHP2 DCs
					categories.add("com.sap.glx.ide.user.EHP2.constraintcategory");
				} else {
					// the following is a constraint that has only to be
					// evaluated for EHP1 DCs
					categories.add("com.sap.glx.ide.user.EHP1.constraintcategory");
				}            	
				constraintCheck(conn, processesWithIsExcludedFromBuildFlagNotSet, categories);
                Log.info(logPrefix + " execute() - Constraint check for processes is done");
            }
        } catch (Exception e) {
            Log.error(" \"BPM.bp.00005\" " + logPrefix
                    + "  execute() - Exception during constraint check of processes. Check Your model for problems.");
            throw new BuildException(e);
        }

        Log.info(logPrefix + " execute() - Initiating process compilation.");
        try {
            callCompilers(processesWithIsExcludedFromBuildFlagNotSet);
        } catch (Exception e) {
            Log.error(" \"BPM.bp.00006\" " + logPrefix + "  execute() - Exception during process compilation, compilerType: "
                    + CompilerRegistry.COMPILERS[CompilerRegistry.getIndex()].getCompiler()
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }
        // PostProcess workflows
        try {
            postProcess();
        } catch (Exception e) {
            Log.error(" \"BPM.bp.00007\" " + logPrefix + "  execute() - Exception during postprocess step."
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }
        
        // Generating SDA
        GenerateSDA generateSDA = new GenerateSDA(pbi.getGenDirDeploy());
        try {

            File tmpRoot = tmpUtil.getTmpDir();
            builder.createTocFile(new File(tmpUtil.getTmpGenDir(), BuildPluginConstants.CONTENT_TOC_FILE));
            generateSDA.generateOutOfBoundsArchives(builder.getArchiveRegistry());
            generateSDA.generateContentMetaFile(new File(tmpUtil.getTmpGenDir(), BuildPluginConstants.CONTENT_META_FILE), pbi
                    .getCBSLocation(), pbi.getCBSCounter(), System.currentTimeMillis());            
            generateSDA.copyMcArchive(pbi.getGenDirPublic());
            generateSDA.copyScdlFiles(new File(pbi.getTempDir(), BuildPluginConstants.SCDL_OUTPUT));
            generateSDA.copyScdlGlobalizationFiles(new File(pbi.getTempDir(), BuildPluginConstants.XLF_OUT));
            generateSDA.execute(dcName, dcVendor, pbi.getCBSLocation(), pbi.getCBSCounter(), tmpRoot);
        } catch (java.io.IOException e) {
            Log.error(logPrefix + " execute() - IOException during SDA generation: " + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        } catch (JarSAPException e) {
            Log.error(logPrefix + " execute() - JarSAPException during SDA generation: "
                    + BuildPluginUtilities.convertSatckTraceToString(e));
            throw new BuildException(e);
        }

        Log.debug(logPrefix + " execute() - " + "exiting.");

    }

    private Collection<RefObject> removeProcessesWithIsExcludedFromBuildFlagSet(
			Collection<RefObject> result) {
    	Collection<RefObject> resultSet = new ArrayList<RefObject>();
    	for (RefObject refobj : result) {
            // Check if the Collaboration is buildable (some BA processes shouldn't be compiled)
            if (((Collaboration) refobj).isExcludedFromBuild()) {
                Log.info(logPrefix + " Process " + ((Collaboration)refobj).getOriginalName() + " was not built because it is in draft status");
            }
            else
            {
            	resultSet.add(refobj);
            }
    	}
		return resultSet;
	}

	private void callCompilers(Collection<RefObject> result) throws Exception {
        Log.debug(logPrefix + " callCompilers(Collection<RefObject> result) - entering.");

        for (RefObject refobj : result) {
            CompilerRegistry.resetIndex();
            for (CompDirs compDir : CompilerRegistry.COMPILERS) {
                if (CompilerRegistry.getIndex() == 0) {
                    CompilerRegistry.setIndex(1);
                    continue;
                }
                processCompiler(refobj, compDir);

                CompilerRegistry.incrementIndex();
            }
        }
        Log.debug(logPrefix + " callCompilers(Collection<RefObject> result) - exiting.");

    }

    protected void processCompiler(Object obj, CompDirs compDir) throws Exception {
        Log.debug(logPrefix + " processCompiler(Object obj, CompDirs compDir) - entering.");
        Log.debug(logPrefix + " processCompilerObj(obj , compDir) - " + obj + " compDir: " + compDir);

        ICompiler currentCompiler = (ICompiler) Class.forName(compDir.getClassString()).newInstance();

        // if the object was already compiled with this Compiler, skip it
        if (compedObjects.get(compDir.getCompiler()) != null && compedObjects.get(compDir.getCompiler()).contains(obj))
            return;

        if (currentCompiler.canCompile(obj)) {
            // Log.debug(" processCompilerObj(obj , compDir) -  Obj: " + obj + ", compiler: " + compDir.getCompiler());
            Object[] refs = currentCompiler.getDependencies(builder, obj);
            int ind = CompilerRegistry.getIndex();
            // Call the same method recursively if there are dependencies
            for (Object ro : refs) {
                CompilerRegistry.resetIndex();
                // Compile recursively with all compilers
                for (CompDirs compDir2 : CompilerRegistry.COMPILERS) {
                    if (CompilerRegistry.getIndex() == 0) {
                        CompilerRegistry.setIndex(1);
                        continue;
                    }
                    // call processCompile if the object and the compiler are not the same as the current ones
                    // (this check is necessary as an artifact might return itself as a dependency)
                    if (!(ind == CompilerRegistry.getIndex() && ro == obj)) {
                        processCompiler(ro, compDir2);
                    }

                    CompilerRegistry.incrementIndex();
                }
            }
            CompilerRegistry.setIndex(ind);
            // call Compile method
            Log.info(logPrefix + " processCompilerObj(obj , compDir) - Compiling " + obj.toString() + ", CompilerType: "
                    + compDir.getCompiler());
            currentCompiler.compile(builder, obj);
            // Update list of compiled objects after compile is finished
            updateCompedObjects(compDir.getCompiler(), obj);

        }
        Log.debug(logPrefix + " processCompiler(Object obj, CompDirs compDir) - exiting.");
    }

    private void updateCompedObjects(CompilerType comp, Object obj) {
        Log.debug(logPrefix + " updateCompedObjects(CompilerType comp, Object obj) - entering.");
        Log.debug(logPrefix + " updateCompedObjects(comp, obj) - " + obj + " comp: " + comp);
        List<Object> list = compedObjects.get(comp);
        if (list == null) {
            list = new ArrayList<Object>();
        }
        list.add(obj); // update list
        compedObjects.put(comp, list); // update HashMap of artifacts with their lists
        Log.debug(logPrefix + " updateCompedObjects(CompilerType comp, Object obj) - exiting.");
    }

    private void postProcess() throws Exception {
        Log.debug(logPrefix + " postProcess() - entering.");
        for (String comp : CompilerRegistry.POSTPROCESSORS) {
            IPostProcessor postProc = (IPostProcessor) Class.forName(comp).newInstance();
            CompilerRegistry.setIndex(CompilerRegistry.getIndexOfCompiler(postProc.postProcessesWhat()));
            postProc.postProcess(builder);
        }
        Log.debug(logPrefix + " postProcess() - exiting.");
    }

    private Collection<RefObject> queryArtifacts(Connection conn, String artifact, CRI cri) throws BuildException {
        Log.debug(logPrefix + " queryArtifacts(Connection conn, String artifact, CRI cri) - entering.");

        Class cl = Object.class;
        String[] alias = null;

        if (artifact.equals(BuildPluginConstants.COLLABORATION)) {
            cl = Collaboration.class;
            alias = new String[] { "Galaxy", "Workflow", artifact };
        } else if (artifact.equals(BuildPluginConstants.TASK)) {
            cl = Task.class;
            alias = new String[] { "Galaxy", artifact, artifact };
        } else if (artifact.equals(BuildPluginConstants.EVENT_DEFINITION)) {
            cl = EventDefinition.class;
            alias = new String[] { "Galaxy", "Workflow", artifact };
        } else {
            String logTempPostfix = " Build plugin query artifacts: Artifact type is not supported: " + artifact;
            Log.error(" \"BPM.bp.00008\" " + logPrefix + "  queryArtifacts(conn,artifact, cri) - " + logTempPostfix);
            throw new BuildException(logTempPostfix);
        }

        Collection<RefObject> result = ToolUtils.getInstance().queryByType(conn, cl, alias, true, cri);

        Log.debug(logPrefix + " queryArtifacts(Connection conn, String artifact, CRI cri) - exiting.");
        return result;

    }

    private CRI createCRI(String name, String vendor) {
        return td.getMoin().createCri("PF", "DefaultDataArea", vendor + "/" + name);
    }

	/**
	 * Performs the constraint check for a given Set of RefObjects, if the
	 * RefObjects are Partitions
	 * 
	 * @param conn
	 *            the MOIN Connection
	 * @param refObjects
	 *            the RefObjects that are the Partitions to check
	 * @param category
	 *            the OCL constraint category which should be checked
	 */

	private void constraintCheck(Connection conn, Collection<RefObject> partitions, String category) {
		HashSet<String> categories = new HashSet<String>();
		categories.add(category);
		this.constraintCheck(conn, partitions, categories);

	}
    
    
	/**
	 * Performs the constraint check for a given Set of RefObjects, if the
	 * RefObjects are Partitions
	 * 
	 * @param conn
	 *            the MOIN Connection
	 * @param refObjects
	 *            the RefObjects that are the Partitions to check
	 * @param categories
	 *            the Set of OCL constraint categories which should be checked
	 */
	private void constraintCheck(Connection conn,
			Collection<RefObject> partitions, Set<String> categories) {
        Log.debug(logPrefix + " constraintCheck(Connection conn, Collection<RefObject> partitions)) - entering.");

        // if there are no partitions to check return
        if (partitions == null || partitions.isEmpty()) {
        	return;
        }
    	boolean errorsFound = false;
    	HashSet<PRI> pris = new HashSet<PRI>();
        for (RefObject partitionObject : partitions) {
        	pris.add(builder.getDCIdentifier(partitionObject));
        }
        
        // call the constraint evaluation
        OclRegistryService regService = conn.getOclRegistryService();
        OclMetamodelConstraintRegistry reg = regService.getMetamodelConstraintRegistry();
        try {
        	DeferredConstraintViolationStatus status = reg.verifyConstraints(pris, categories); 

        	for (DeferredConstraintViolationStatusItem violation : status.getAll()) {
        		// create the appropriate problem severity message
        		OclRegistrationSeverity severity = violation.getConstraintRegistration().getSeverity();
        		switch (severity) {
          			case Error:
          				errorsFound = true;
          				Log.error(logPrefix + " constraintCheck(conn,partitions) - Constraint violation: "
          						+ violation.getConstraintViolationMessage());
          				break;
          			case Warning:
          				Log.warn(logPrefix + " constraintCheck(conn,partitions) - Constraint violation: "
          						+ violation.getConstraintViolationMessage());
          				break;
          			case Info:
          				Log.info(logPrefix + " constraintCheck(conn,partitions) - Constraint violation: "
          						+ violation.getConstraintViolationMessage());
          				break;
           			}
            	}
        } catch (OclManagerException e) {
        	Log.error(" \"BPM.bp.00009\" " + logPrefix
        			+ " constraintCheck(conn,partitions,category) - OclManagerException in constraint checking.");
          throw new BuildException(e);
        }
        // stop the build if there are constraint violations with severity error
        if (errorsFound) {
        	throw new BuildException();
        }        
        Log.debug(logPrefix + " constraintCheck(conn,partitions) - exiting.");
    }

    private boolean sanityCheck(Connection conn, PRI partition) {
        Log.debug(logPrefix + " sanityCheck(Connection conn, ModelPartition partition) - entering.");
        boolean result = true;

        try {
            conn.getConsistencyViolationListenerRegistry().performConsistencyCheck(partition);
        } catch (Throwable t) {
            Log.error(logPrefix + " sanityCheck(Connection conn, ModelPartition partition) -  ", t);
            throw new BuildException(t);
        }

        Collection<ConsistencyViolation> consistencyProblems = conn.getConsistencyViolationListenerRegistry().getAllConsistencyViolations();
        if (consistencyProblems != null && consistencyProblems.size() != 0) {
            Log.info(logPrefix + " sanityCheck(Connection conn, ModelPartition partition) - partition:" + partition.toString());
            result = false;
            for (ConsistencyViolation violation : consistencyProblems) {
                Log.warn(logPrefix + " sanityCheck(Connection conn, ModelPartition partition) - violations: "
                        + violation.getDescription(conn));
            }
        } else {
            Log.debug(logPrefix + " sanityCheck(Connection conn, ModelPartition partition) - No consistency violations found on partition:"
                    + partition.toString());
        }

        Log.debug(logPrefix + " sanityCheck(Connection conn, ModelPartition partition) - exiting.");
        return result;
    }

    private void metaModelVersionCheck(HashSet<PRI> hSet, Connection conn) throws BuildException {
        Log.debug(logPrefix + " metaModelVersionCheck(HashSet<PRI> , Connection) - entering.");

        for (PRI pri : hSet) {
            ModelPartition modelPartition = conn.getPartition(pri);
            Map<CRI, String> versionInfoMap = modelPartition.getUsedMetamodels();
            for (CRI element : versionInfoMap.keySet()) {
                if (BuildPluginConstants.METAMODEL_NAME.equals(element.getContainerName())) {
                    String metaModelVersion = versionInfoMap.get(element);
                    if (metaModelVersion == null) {
                        Log.info(logPrefix + " metaModelVersionCheck(HashSet<PRI> , Connection) - partition:" + pri.getPartitionName()
                                + " container:" + element.getContainerName() + " metamodel version: " + metaModelVersion
                                + " build plugin version:" + BuildPluginConstants.BUILDPLUGIN_VERSION);
                    } else if (!"null".equals(metaModelVersion)
                            && BuildPluginConstants.BUILDPLUGIN_VERSION.compareToIgnoreCase(metaModelVersion) < 0) {
                        Log.error(logPrefix + " metaModelVersionCheck(HashSet<PRI> , Connection) - partition:" + pri.getPartitionName()
                                + " container:" + element.getContainerName() + " metamodel version: " + metaModelVersion
                                + " build plugin version:" + BuildPluginConstants.BUILDPLUGIN_VERSION);
                        Log.error(" \"BPM.bp.000017\"  " + logPrefix + " metaModelVersionCheck(HashSet<PRI> , Connection) - "
                                + BuildPluginConstants.VERSION_EXCEPTION_MESSAGE);
                        throw new BuildException(BuildPluginConstants.VERSION_EXCEPTION_MESSAGE);
                    }
                }
            }
        }
        Log.debug(logPrefix + " metaModelVersionCheck(HashSet<PRI> , Connection)) - exiting.");
    }
    
    /**
     * Checks the property bag directly contained in the partition of a given RefObject for the original developement component. This has to
     * match the development component which is currently built.
     * 
     * @param object model object
     * @param dcVendor
     * @param dcName
     */
    private void partitionCheck(RefObject object, String dcVendor, String dcName) {
        String dcVendorOfPartition = null;
        String dcNameOfPartition = null;
        ModelPartition partition = ((Partitionable) object).get___Partition();
        for (Partitionable element : partition.getElements()) {
            if (element instanceof PropertyBag) {
                PropertyBag bag = (PropertyBag) element;
                for (Property property : bag.getProperties()) {
                    if (BuildPluginConstants.PROPERTY_ORIGINAL_DC_VENDOR.equals(property.getKey()))
                        dcVendorOfPartition = property.getValue();
                    if (BuildPluginConstants.PROPERTY_ORIGINAL_DC_NAME.equals(property.getKey()))
                        dcNameOfPartition = property.getValue();
                }
            }
        }

        if (dcVendorOfPartition == null || dcNameOfPartition == null) {
            return;
        } else {
            if (dcVendorOfPartition.equals(dcVendor) && dcNameOfPartition.equals(dcName)) {
                return;
            } else {
                Log.error(" \"BPM.bp.000022\" " + logPrefix + " Process or task definition does not belong to this development component.");
                throw new BuildException("Process or task definition was not created in this development component. Creating copies of model files is not allowed.");
            }
        }
    }
}
