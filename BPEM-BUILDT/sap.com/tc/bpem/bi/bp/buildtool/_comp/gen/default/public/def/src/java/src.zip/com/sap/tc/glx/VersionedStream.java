package com.sap.tc.glx;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import com.sap.glx.util.DigestUtil;

public class VersionedStream extends BaseVersionedStream {

    public VersionedStream(final String fileName, final File fullPath, final Object artifact, final BuilderHostImpl aImpl)
            throws FileNotFoundException, NoSuchAlgorithmException {
        super(fileName, fullPath, artifact, aImpl);
    }

    @Override
    public void write(final byte[] b) throws IOException {
        super.write(b);
        currentAlgorithm.update(b);
    }

    @Override
    public void write(final byte[] b, final int off, final int len) throws IOException {
        super.write(b, off, len);
        currentAlgorithm.update(b, off, len);
    }

    @Override
    public void write(final int b) throws IOException {
        super.write(b);
        currentAlgorithm.update((byte) b);
    }

    /**
     * The close method saves the file and creates a new row into VersionRegistry.
     * 
     * @throws IOException
     */
    @Override
    public void close() throws IOException {
        if (!closeInvoked) {
            super.close();
            final String versionId = DigestUtil.computeDigest(currentAlgorithm);
            createFile(versionId);
            closeInvoked = true;
        }
    }
}
