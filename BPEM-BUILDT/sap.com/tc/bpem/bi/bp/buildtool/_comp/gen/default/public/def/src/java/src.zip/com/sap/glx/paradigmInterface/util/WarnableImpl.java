package com.sap.glx.paradigmInterface.util;

import com.sap.tc.moin.repository.mmi.reflect.RefObject;

import com.sap.glx.paradigmInterface.bpmn.compiler.Warnable;
import com.sap.tc.buildplugin.log.Log;

/**
 * A wrapper class to create Eclipse markers in the problems view when compiling a Galaxy paradigm model.
 * 
 * @author d042872
 * 
 */
public class WarnableImpl implements Warnable {

    private String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + WarnableImpl.class.getName();

    public void addWarning(Severity severity, RefObject object, String text, Object... params) {
        Log.debug(logPrefix + " addWarning(Severity severity, RefObject object, String text, Object... params) - entering.");
        
        if (severity == Severity.INFORMATION)
            Log.info(String.format(text, params));
        else if (severity == Severity.WARNING)
            Log.warn(String.format(text, params));
        else if (severity == Severity.ERROR)
            Log.error(String.format(text, params));
        
        Log.debug(logPrefix + " addWarning(Severity severity, RefObject object, String text, Object... params) - exiting.");
        }

    public void addWarning(Severity severity, String constraintId, RefObject object, String text, Object... params) {
        Log.debug(logPrefix + " addWarning(Severity severity, String constraintId, RefObject object, String text, Object... params) - entering.");
        
        if (severity == Severity.INFORMATION)
            Log.info(String.format(text, params));
        else if (severity == Severity.WARNING)
            Log.warn(String.format(text, params));
        else if (severity == Severity.ERROR)
            Log.error(String.format(text, params));
        
        Log.debug(logPrefix + " addWarning(Severity severity, String constraintId, RefObject object, String text, Object... params) - exiting.");
    }

    public void deleteWarnings(RefObject object) {
    // Anything to do here?
    }
}
