package com.sap.tc.glx;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;

/**
 * This class manages the filewriter method of the compilers.
 * 
 * @author I044123
 * 
 */
class VersionedStream2 extends FileOutputStream {
	private String fileName;
	private IArtifact<?> artifact;
	private MessageDigest currentAlgorithm;
	private BuilderHostImpl2 iImpl = null;
	private boolean ClosedInvoked;

	/**
	 * This constructor creates a new stream.
	 * 
	 * @param fileName -
	 *            The name of the file.
	 * @param fullPath -
	 *            The full path of the file.
	 * @param artifact -
	 *            The artifact which is compiled.
	 * @param aImpl -
	 *            The parent class.
	 * @throws FileNotFoundException
	 * @throws NoSuchAlgorithmException
	 */
	public VersionedStream2(String fileName, File fullPath, IArtifact<?> artifact,
			BuilderHostImpl2 aImpl) throws FileNotFoundException,
			NoSuchAlgorithmException {
		super(fullPath);
		this.iImpl = aImpl;
		this.fileName = fileName;
		this.artifact = artifact;
		this.ClosedInvoked = false;
		// Initiates the MD5 algorithm.

		currentAlgorithm = MessageDigest.getInstance("MD5");
		currentAlgorithm.reset();

	}

	/**
	 * This method calculates the hash code of the result file.
	 * 
	 * @return
	 */
	private String computeDigest() {
		byte[] hash = currentAlgorithm.digest();
		String d = "";
		for (int i = 0; i < hash.length; i++) {
			int v = hash[i] & 0xFF;
			if (v < 16)
				d += "0";
			d += Integer.toString(v, 16).toUpperCase(Locale.ENGLISH);
		}
		return d;
	}

	/**
	 * It converts the int value to byteArray.
	 * 
	 * @param value
	 * @return
	 */
	public byte[] intToByteArray(int value) {
		return new byte[] { (byte) (value >>> 24), (byte) (value >> 16 & 0xff),
				(byte) (value >> 8 & 0xff), (byte) (value & 0xff) };
	}

	/**
	 * Every write method is override because hash algorithm is updated.
	 */
	@Override
	public void write(byte[] b) throws IOException {
		super.write(b);
		currentAlgorithm.update(b);
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		super.write(b, off, len);
		currentAlgorithm.update(b);
	}

	@Override
	public void write(int b) throws IOException {
		super.write(b);
		currentAlgorithm.update((byte)b);
	}

	/**
	 * The close method saves the file and creates a new row into
	 * VersionRegistry.
	 * 
	 * @throws IOException
	 */
	@Override
	public void close() throws IOException {
		if (!ClosedInvoked){
			super.close();
			// Create every element of the VersionRegistryrow.
			String versionId = computeDigest();
			File targetDir = CompilerRegistry.getCompilerTargetDir(artifact.handledBy());
			String artifactPath = iImpl.getArtifactPath(artifact); 
			String sourcePath = targetDir.getPath() 
					+ BuildPluginConstants.FILE_SEPARATOR 
					+ artifactPath
					+ BuildPluginConstants.FILE_SEPARATOR
					+ fileName;
			String targetPath;
			if (targetDir.getPath().equals(""))
				targetPath = targetDir.getPath() + artifactPath + fileName;
			else
				targetPath = targetDir.getPath() + BuildPluginConstants.FILE_SEPARATOR + artifactPath
						+ fileName;
	
			VersionRegistryItem2 vr;
			// We check whether is a row in the VersionRegistry for this object.
			// If it is then update the row otherwise add a new one.
			int i = 0;
			while (i < iImpl.getVersionRegistrySize()) {
				vr = iImpl.getVersionRegistryRow(i);
				if ((vr.getArtifact().equals(artifact))
						&& (vr.getArtifact().handledBy() == artifact.handledBy())) {
					// vr.setVersionId(versionId);
					vr.setSourcePath(sourcePath);
					vr.setTargetPath(targetPath);
					vr.setToPackage(artifact.isLocal(iImpl.getLocalDCIdentifier()));
					iImpl.setVersionRegistryRow(i, vr);
					i = iImpl.getVersionRegistrySize() + 1;
				} else {
					i++;
				}
			}
			if (i == iImpl.getVersionRegistrySize()) {
				vr = new VersionRegistryItem2(artifact, versionId,
						sourcePath, targetPath, artifact.isLocal(iImpl.getLocalDCIdentifier()));
				iImpl.addVersionRegistry(vr);
			}
			ClosedInvoked = true;
		}
	}
	
}
