package com.sap.glx.paradigmInterface.util;

import java.io.File;
import java.io.IOException;

import org.apache.tools.ant.BuildException;

import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.log.Log;

public class TmpDirUtil {

    File rootDir;
    File tmpDir;
    File gen_bpmDir;
    File sdaTmpDir;
    private String logPrefix = BuildPluginLogConstants.CSN_COMPONENT_NAME + " " + TmpDirUtil.class.getName();

    public TmpDirUtil(File root) {
        IGlobalPluginUtil gpu = (IGlobalPluginUtil) BuildSessionManager.getFromBuildSession(IGlobalPluginUtil.class.getName());

        // Creating temporary directory
        try {
            if((tmpDir==null || !tmpDir.exists())){
               tmpDir =  gpu.createTempDir(BuildPluginConstants.TMP_DIR);
            }           
            gen_bpmDir = new File(tmpDir, BuildPluginConstants.GEN_BPEM_DIR);
            sdaTmpDir = gpu.createTempDir(BuildPluginConstants.SDA_TMP_DIR);
        } catch (IOException e) {
            Log.error(logPrefix + " TmpDirUtil(File root) - ", e);
            throw new BuildException(e);
        }

        rootDir = root;

    }

    public File getTmpDir() {
        return tmpDir;
    }

    public File getTmpGenDir() {
        return gen_bpmDir;
    }

    public File getSdaTmpDir() {
        return sdaTmpDir;
    }
}
