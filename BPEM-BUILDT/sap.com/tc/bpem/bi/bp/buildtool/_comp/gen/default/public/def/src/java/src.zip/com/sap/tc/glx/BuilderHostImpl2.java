package com.sap.tc.glx;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.sap.glx.paradigmInterface.bpmn.compiler.Warnable;
import com.sap.glx.paradigmInterface.buildapi.BpemBuildException;
import com.sap.glx.paradigmInterface.buildapi.IArtifact;
import com.sap.glx.paradigmInterface.buildapi.IBuilderHost2;
import com.sap.glx.paradigmInterface.buildapi.CompilerTypes.CompilerType;
import com.sap.glx.paradigmInterface.facades.IEsmpFacade;
import com.sap.glx.paradigmInterface.facades.impl.EsmpFacadeImpl;
import com.sap.glx.paradigmInterface.util.BuildPluginConstants;
import com.sap.glx.paradigmInterface.util.WarnableImpl;
import com.sap.tc.buildplugin.BuildSessionManager;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.log.Log;
import com.sap.tc.buildplugin.pp.api.IComponentDependencies;
import com.sap.tc.buildplugin.pp.api.IComponentDependency;
import com.sap.tc.moin.repository.CRI;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.Partitionable;

/**
 * This class manages the VersionRegistry which contains all information about
 * the compilers.
 * 
 * @author I044123
 * 
 */
public class BuilderHostImpl2 implements IBuilderHost2 {

	private IEsmpFacade esmp;
	private Vector<VersionRegistryItem2> versionRegistry = null;
	private Hashtable<String, File> archiveRegistry = null;
	private HashMap<CompilerType, Map<IArtifact<?>, List<Object>>> postProcessorData = null;
	private File tmpRoot;
	private CRI localDc;
	private IPluginBuildInfo pbi;
	private IGlobalPluginUtil gpu;
	private Connection conn;

	/**
	 * New VersionRegistry is created in the constructor and dcRoot is
	 * determined.
	 */
	public BuilderHostImpl2(Connection conn, CRI cri) {
		super();
		esmp = new EsmpFacadeImpl(conn);
		versionRegistry = new Vector<VersionRegistryItem2>();
		archiveRegistry = new Hashtable<String, File>();
		postProcessorData = new HashMap<CompilerType, Map<IArtifact<?>, List<Object>>>();
		pbi = (IPluginBuildInfo) BuildSessionManager
				.getFromBuildSession(IPluginBuildInfo.class.getName());
		gpu = (IGlobalPluginUtil) BuildSessionManager
				.getFromBuildSession(IGlobalPluginUtil.class.getName());
		tmpRoot = pbi.getTempDir();
		localDc = cri;
		this.conn = conn;

	}

	public Connection getConnection() {
		return conn;
	}

	public IEsmpFacade getEsmpFacade() {
		return esmp;
	}

	/**
	 * This method creates a new Stream where to write the result of the
	 * compiler.
	 */
	public OutputStream createVersionedTargetFile(String relativePath,
			IArtifact<?> sourceArtifact) throws BpemBuildException {

		// Full path of the output file
		StringBuilder fullName = new StringBuilder();
		fullName.append(tmpRoot.getPath())
				.append(BuildPluginConstants.FILE_SEPARATOR)
				.append(BuildPluginConstants.TMP_DIR)
				.append(BuildPluginConstants.FILE_SEPARATOR)
				.append(CompilerRegistry.getCompilerTargetDir(sourceArtifact
						.handledBy()))
				.append(BuildPluginConstants.FILE_SEPARATOR)
				.append(getArtifactPath(sourceArtifact))
				.append(BuildPluginConstants.FILE_SEPARATOR)
				.append(relativePath);
		File full = new File(fullName.toString());

		full.getParentFile().mkdirs();
		OutputStream outStream;
		try {
			outStream = new VersionedStream2(relativePath, full,
					sourceArtifact, this);
		} catch (FileNotFoundException e) {
			throw new BpemBuildException(e);
		} catch (NoSuchAlgorithmException e) {
			throw new BpemBuildException(e);
		}
		return outStream;
	}

	// /**
	// * This method is used by the CSV compiler because it needs to have a row
	// in
	// * the VersionRegistry from the beginning. When the file is written this
	// row
	// * will be updated.
	// */
	// public void calculateVersionId(IArtifact<?> artifact) {
	// String curVersionId = getVersionId(artifact);
	// if (curVersionId.equals("")) {
	// String versionId = String.valueOf(artifact.hashCode());
	// int compilerIndex = CompilerRegistry.getIndex();
	// VersionRegistry vr = new VersionRegistry(artifact,
	// CompilerRegistry.COMPILERS[compilerIndex].getCompiler(),
	// versionId, "", "", false);
	// //addVersionRegistry(vr);
	// }
	// }

	/**
	 * This method checks whether the artifact is in the VersionRegistry
	 */
	public String getVersionId(IArtifact<?> artifact) {
		for (VersionRegistryItem2 verItem : versionRegistry) {
			if (artifact.equals(verItem.getArtifact())) {
				return verItem.getVersionId();
			}
		}
		return null;
	}

	/**
	 * This method returns the application name
	 */
	public String getApplicationName() {
		pbi = (IPluginBuildInfo) BuildSessionManager
				.getFromBuildSession(IPluginBuildInfo.class.getName());
		String dcName = pbi.getDCName().replace('/', '~');
		String dcVendor = pbi.getDCVendor();

		return dcVendor + "/" + dcName;
	}

	/**
	 * This method returns the application name for a DC which contains the
	 * specific artifact
	 */
	public String getApplicationName(IArtifact<?> artifact) {
		if (artifact instanceof Partitionable) {
			return appNameEscaped(((Partitionable) artifact).get___Mri()
					.getContainerName());
		} else
			return null;
	}

	/**
	 * This method adds a new row into the VersionRegistry with the given
	 * artifact and versionID. If the row exists then nothing happens.
	 */
	public void setVersionId(IArtifact<?> artifact, String versionId) {
		String curVersionId = getVersionId(artifact);
		if (curVersionId == null) {
			VersionRegistryItem2 vr = new VersionRegistryItem2(artifact,
					versionId, "", "", false);
			addVersionRegistry(vr);
		}
	}

	/**
	 * This method gives back a CRI where the artifact is situated.
	 */
	public CRI getDCIdentifier(Object object) {
		if (object instanceof Partitionable) {
			return ((Partitionable) object).get___Mri().getCri();
		} else
			return null;
	}

	/**
	 * This method returns true if the artifact resides in the current DC. With
	 * the concept of having IArtifact interface, this method is not needed
	 * anymore.
	 */
	@Deprecated
	public boolean isFromLocalDC(IArtifact<?> artifact) {
		return artifact.isLocal(localDc);
	}

	/**
	 * This method gives back the CRI of the local DC.
	 */
	public CRI getLocalDCIdentifier() {
		return localDc;
	}

	/**
	 * This method gives back the current size of the VersionRegistry.
	 * 
	 * @return
	 */
	public int getVersionRegistrySize() {
		return versionRegistry.size();
	}

	/**
	 * This method gives back a row from the VersionRegistry which is situated
	 * in the given index.
	 * 
	 * @param rowIndex
	 * @return
	 */
	public VersionRegistryItem2 getVersionRegistryRow(int rowIndex) {
		return versionRegistry.get(rowIndex);
	}

	/**
	 * This method changes the VersionRegistry on the given rowIndex with the
	 * given row.
	 * 
	 * @param rowIndex
	 * @param vr
	 */
	public void setVersionRegistryRow(int rowIndex, VersionRegistryItem2 vr) {
		versionRegistry.set(rowIndex, vr);
	}

	/**
	 * This method writes every information into a content.toc file from the
	 * VersionRegistry.
	 */
	public boolean createTocFile(File tocLocation) throws IOException {
		StringBuilder tocFile = new StringBuilder();
		tocLocation.getParentFile().mkdirs();
		FileWriter fstream = new FileWriter(tocLocation);
		BufferedWriter out = new BufferedWriter(fstream);

		for (int i = 0; i < versionRegistry.size(); i++) {
			if (versionRegistry.get(i) != null
					&& versionRegistry.get(i).isToPackage() && !isDuplicate(i)) {
				tocFile = tocFile
						.append(versionRegistry.get(i).getTargetPath())
						.append("\t")
						.append(versionRegistry.get(i).getVersionId())
						.append("\n");
			}
		}
		out.write(tocFile.toString());
		out.close();
		return true;
	}

	/**
	 * This gives back a new Warnable implementation.
	 */
	public Warnable getWarnable() {
		return new WarnableImpl();
	}

	/**
	 * Adding data to store for the specific CompilerType and artifact.
	 */
	public void addPostProcessorData(IArtifact<?> artifact, Object data) {
		// get current CompilerType
		CompilerType currentComp = artifact.handledBy();

		// add it to store
		List<Object> list;
		Map<IArtifact<?>, List<Object>> hm = postProcessorData.get(currentComp);
		if (hm == null) {
			hm = new HashMap<IArtifact<?>, List<Object>>();
		}

		list = hm.get(artifact);
		if (list == null) {
			list = new ArrayList<Object>();
		}

		list.add(data); // update list
		hm.put(artifact, list); // update HashMap of artifacts with their lists
		postProcessorData.put(currentComp, hm); // update the HashMap of
		// CompilerTypes with their
		// HashMaps
	}

	/**
	 * Gives back the stored data for the specific CompilerType.
	 */
	public Map<IArtifact<?>, List<Object>> getPostProcessorData(
			CompilerType currentComp) {
		return postProcessorData.get(currentComp);
	}

	/**
	 * Low-level method to create a (non-versioned) file in an extra archive
	 * (beside the BPEM archive).
	 */
	public OutputStream createOutOfBoundsFile(String rootArchive,
			String filename) throws BpemBuildException {

		File tmpDir = null;

		// if this archive is not yet inserted in the list, create a temporary
		// directory for
		// storing all the files for it
		if (!archiveRegistry.containsKey(rootArchive)) {
			// Creating temporary directory
			try {
				tmpDir = gpu.createTempDir(rootArchive);
				archiveRegistry.put(rootArchive, tmpDir);
			} catch (IOException e) {
				Log.error(e);
				throw new BpemBuildException(e);
			}
		} else {
			tmpDir = archiveRegistry.get(rootArchive);
		}

		File outFile = new File(tmpDir, filename);
		outFile.getParentFile().mkdirs();
		Log.info("outOfBoundsFile: " + outFile.toString());
		FileOutputStream ret;
		try {
			ret = new FileOutputStream(outFile);
		} catch (FileNotFoundException e) {
			throw new BpemBuildException(e);
		}
		return ret;
	}

	/**
	 * This method adds a new row into the VersionRegistry.
	 * 
	 * @param vr
	 */
	void addVersionRegistry(final VersionRegistryItem2 vr) {
		versionRegistry.add(vr);
	}

	Hashtable<String, File> getArchiveRegistry() {
		return archiveRegistry;
	}

	private boolean isDuplicate(int index) {
		// Check if it has the same filename and versionId in the
		// versionRegistry as an earlier entry
		// cycles only on the previous entries! (i<index)
		for (int i = 0; i < index; i++) {
			if (versionRegistry.get(i).getSourcePath().equals(
					versionRegistry.get(index).getSourcePath())
					&& versionRegistry.get(i).getVersionId().equals(
							versionRegistry.get(index).getVersionId())) {
				return true;
			}
		}
		return false;
	}

	String getArtifactPath(IArtifact<?> artifact) {
		String cl = artifact.getObject().getClass().getSimpleName();
		if (BuildPluginConstants.COLLABORATION_CLASS.equals(cl)) {
			return CompilerRegistry.ARTIFACT_DIRS
					.get(BuildPluginConstants.COLLABORATION);
		} else if (BuildPluginConstants.TASK.equals(cl)) {
			return CompilerRegistry.ARTIFACT_DIRS
					.get(BuildPluginConstants.TASK);
		} else
			return CompilerRegistry.ARTIFACT_DIRS
					.get(BuildPluginConstants.OTHER_ARTIFACT);
	}

	private String appNameEscaped(String appName) {
		// Replace all '/' to '~' but the first one, because that is the
		// delimiter for vendor name
		String ret = appName.replace('/', '~');
		ret = ret.replaceFirst("~", "/");
		return ret;
	}

	public Boolean isDependencyAvailable(String dcVendor, String dcName,
			IBuilderHost2.DEP_TYPES depType) {
		pbi = (IPluginBuildInfo) BuildSessionManager
				.getFromBuildSession(IPluginBuildInfo.class.getName());
		IComponentDependencies dependencies = pbi.getDependencies();

		if (dependencies != null) {
			for (IComponentDependency dep : dependencies) {
				// check if the dependency is for the given dcName and dcVendor
				if (dep.getName().equals(dcName)
						&& dep.getVendor().equals(dcVendor)) {

					// if yes, then check if it's the given type of dependency
					if (IBuilderHost2.DEP_TYPES.BUILDTIME.equals(depType)) {
						if (dep.isAtBuild()) {
							return true;
						}
					} else if (IBuilderHost2.DEP_TYPES.DESIGNTIME
							.equals(depType)) {
						if (dep.isAtDesign()) {
							return true;
						}
					} else if (IBuilderHost2.DEP_TYPES.DEPLOYTIME
							.equals(depType)) {
						if (dep.isAtDeploy()) {
							return true;
						}
					} else if (IBuilderHost2.DEP_TYPES.RUNTIME.equals(depType)) {
						if (dep.isAtRuntime()) {
							return true;
						}
					}
				}
			}
		}

		return false;
	}

}
