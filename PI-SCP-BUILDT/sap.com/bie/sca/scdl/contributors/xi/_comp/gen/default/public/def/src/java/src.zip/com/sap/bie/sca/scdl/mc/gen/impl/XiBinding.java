package com.sap.bie.sca.scdl.mc.gen.impl;

import java.util.Collection;
import java.util.Collections;

import com.sap.bie.sca.scdl.adapter.IBinding;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.NoNullsList;

/**
 * Represents the xi binding element in the SCA assembly model
 */

public class XiBinding implements IBinding {

	private final NoNullsList<ICustomScdlElement> customElements = new NoNullsList<ICustomScdlElement>();

	public XiBinding(ICustomScdlElement xiCustomScdlElement) {
		addCustomElement(xiCustomScdlElement);
	}

	/**
	 * Adds custom element to the list of elements
	 * 
	 * @param customScdlElement
	 * @return result of {@link Collection#add(Object)}
	 * @throws NullPointerException
	 *             in case <code>customScdlElement</code> is <code>null</code>
	 */
	public boolean addCustomElement(final ICustomScdlElement customScdlElement) {
		return customElements.add(customScdlElement);
	}

	/**
	 * Returns all custom elemens defined for this element.
	 */
	@Override
	public Collection<ICustomScdlElement> getCustomElements() {
		return customElements.unmodifiable();
	}

	/**
	 * Returns all custom attributes defined for this element
	 */
	@Override
	public Collection<ICustomScdlAttribute> getCustomAttributes() {
		return Collections.emptyList();
	}

}