package com.sap.bie.sca.scdl.mc.gen.impl;

import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IBinding;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.gen.mc.IMcReferenceExtensionContribution;
import com.sap.bie.sca.scdl.gen.mc.IMcScdlReference;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReferenceCustomAttributes;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.moin.repository.Connection;

/**
 * Implementation to MC reference extension contribution interface; Contributes
 * a custom element and custom attributes to the MC SCDL reference based on
 * Service Reference design-time artifact (Reference Type: XI)
 * The contribution to scdl reference customisation is performed through .bpfext file with a content similar to the one below:
 * <?xml version="1.0" encoding="UTF-8"?>
 * <technologies version="1">
 *      <technology name="sap.com/bie/sca/scdl/contributors/xi">
 *      	<uses>sap.com/tc/bi/core</uses>
 *      	<definition>
 *      		<object-attributes key="com.sap.bie.sca.scdl.mc.gen.impl.XiBindingScdlReferenceExtensionContribution" attributes="ext-point[bie.sca.scdl.gen.mc.ref]" class="java.lang.String"/>
 *      	</definition>
 *      </technology>
 * </technologies>
 */

public class XiBindingScdlReferenceExtensionContribution implements
		IMcReferenceExtensionContribution {

	private static final String REFERENCE_TYPE = "XI";
	private static final String BINDING_TYPE = "binding.xi";
	private static final String BINDING_TYPE_LOCAL_PART = "xins";
	private static final String BINDING_TYPE_NAMESPACE = "http://www.sap.com/xmlns/sapsca/xi/1.0";

	/**
	 * Creates XIBinding and insert into scdlReference
	 */
	@Override
	public void applyCustomization(Connection conn, IPluginBuildInfo pbi,
			ServiceReference serviceRef, IMcScdlReference scdlReference) {

		List<ICustomScdlAttribute> attributes = new ArrayList<ICustomScdlAttribute>();
		for(ServiceReferenceCustomAttributes customProp : serviceRef.getSrCustomAttributes()) {
			ICustomScdlAttribute senderServiceName = new XiCustomScdlAttribute(
					new QName(BINDING_TYPE), customProp.getKey(),customProp.getValue());
			attributes.add(senderServiceName);
		}

		ICustomScdlElement xiCustomScdlElement = new XiCustomScdlElement(
				new QName(BINDING_TYPE_NAMESPACE, BINDING_TYPE, BINDING_TYPE_LOCAL_PART), attributes);

		IBinding xiBinding = new XiBinding(xiCustomScdlElement);

		scdlReference.setBinding(xiBinding);

	}

	@Override
	public String getSupportedServiceReferenceType() {
		return REFERENCE_TYPE;
	}
}
