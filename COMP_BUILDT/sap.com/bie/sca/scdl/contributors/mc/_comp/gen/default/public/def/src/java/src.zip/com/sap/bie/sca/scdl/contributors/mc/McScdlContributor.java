/**
 * 
 */
package com.sap.bie.sca.scdl.contributors.mc;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.IScdlContributor;
import com.sap.bie.sca.scdl.adapter.ScdlContributorException;
import com.sap.bie.sca.scdl.adapter.impl.Composite;
import com.sap.bie.sca.scdl.adapter.mc.SGConfigurationCustomSCDLElement;
import com.sap.bie.sca.scdl.adapter.mc.SGConfigurationLocalProviderCustomSCDLElement;
import com.sap.bie.sca.scdl.adapter.mc.ServiceGroupClassifValueCustomSCDLElement;
import com.sap.bie.sca.scdl.adapter.mc.ServiceGroupCustomSCDLElement;
import com.sap.bie.sca.scdl.adapter.mc.ServiceGroupsCustomSCDLElement;
import com.sap.bie.sca.scdl.gen.mc.IMcMetamodelInteraction;
import com.sap.bie.sca.scdl.gen.mc.IllegalMcDependenciesDetected;
import com.sap.bie.sca.scdl.gen.mc.McDependencyAnalyzator;
import com.sap.bie.sca.scdl.gen.mc.McReferenceGeneratorFactory;
import com.sap.bie.sca.scdl.gen.mc.NoMcDependenciesDetected;
import com.sap.ide.es.config.mc.model.mc.logicalsystem.ClassificationSystemValue;
import com.sap.ide.es.config.mc.model.mc.logicalsystem.LogicalSystem;
import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.Partitionable;

/**
 * @author d038406
 *
 */
public class McScdlContributor implements IScdlContributor {

	private Composite composite;
	private List<ServiceGroupCustomSCDLElement> srvGroupList;
	
    
	private IPluginBuildInfo pbi;
	private IMcMetamodelInteraction mcMetamodelInteractor;
	
	/* (non-Javadoc)
	 * @see com.sap.bie.sca.scdl.adapter.IScdlContributor#getComposites(com.sap.tc.buildplugin.api.IGlobalPluginUtil, com.sap.tc.buildplugin.api.IPluginBuildInfo)
	 */
	public IComposite getComposite(final Connection conn, IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo) {
		this.pbi = pluginBuildInfo;
		mcMetamodelInteractor = McReferenceGeneratorFactory.getInstance().newMcModelInteractor(conn, pluginBuildInfo);
		
		try {
			McDependencyAnalyzator.getInstance().isScdlGenerationEnabled(pbi);
		}
		catch(IllegalMcDependenciesDetected e) {
			throw new ScdlContributorException("Illegal configuration dependencies error", e); //$NON-NLS-1$
		}
		catch(NoMcDependenciesDetected e) {
			throw new ScdlContributorException("Missing configuration dependencies error", e); //$NON-NLS-1$
		}
		
		composite = new Composite(pbi.getDCName());
		
		srvGroupList = new ArrayList<ServiceGroupCustomSCDLElement>();
						
		final List<LogicalSystem> lsList = queryLogicalSystems(conn); 		
		getServiceGroups(lsList);
		
		if(srvGroupList.size() > 0) {
			final ServiceGroupsCustomSCDLElement srvGroups = new ServiceGroupsCustomSCDLElement();
			for(ICustomScdlElement srvGroup : srvGroupList) {
				srvGroups.addChild(srvGroup);
			}
			
			composite.addCustomElement(srvGroups);
			Collection<SGConfigurationCustomSCDLElement> sgElems = getSgConfigurations(lsList);
			
			for(SGConfigurationCustomSCDLElement sgElem : sgElems) {
				composite.addCustomElement(sgElem);
			}
		}
		
		return composite;
	}
	
	private List<LogicalSystem> queryLogicalSystems(Connection conn)
	{
		final List<LogicalSystem> lsList = mcMetamodelInteractor.getLogicalSystems();
		
		return lsList;
	}	

	private void getServiceGroups(List<LogicalSystem> lsList) 
	{				
		for(LogicalSystem ls : lsList) 
		{			
			addServiceGroupToComposite(ls);				
		}
	}
	
	private boolean isServiceGroupWithLSP(LogicalSystem srvGroup)
	{
		return (srvGroup.isLocalProviderSystem() != null) && 
			   (srvGroup.isLocalProviderSystem().booleanValue());		
	}
	
	private Collection<SGConfigurationCustomSCDLElement> getSgConfigurations(List<LogicalSystem> lsList)
	{
		final Collection<SGConfigurationCustomSCDLElement> lpSgList = new ArrayList<SGConfigurationCustomSCDLElement>();
				
		for (LogicalSystem ls : lsList)
		{						
			if (isServiceGroupWithLSP(ls))   
			{
				lpSgList.add(createSgConfiguration(ls));				
			}			
		}
		
		return lpSgList;		
	}
	
	private SGConfigurationCustomSCDLElement createSgConfiguration(LogicalSystem ls) 
	{
		final SGConfigurationCustomSCDLElement sgConf = new SGConfigurationCustomSCDLElement(mcMetamodelInteractor.getServiceGroupName(ls));
		sgConf.addChild(new SGConfigurationLocalProviderCustomSCDLElement());
		
		return sgConf;				
	}		
		
	private ServiceGroupCustomSCDLElement createServiceGroup(String sgName, Collection<ClassificationSystemValue> classifications, String sgBundleName) {
		
		final ServiceGroupCustomSCDLElement srvGrp = new ServiceGroupCustomSCDLElement(sgName, sgBundleName);		
		
		for(ClassificationSystemValue classifValue: classifications) 
	    {
			ServiceGroupClassifValueCustomSCDLElement valueElem = new ServiceGroupClassifValueCustomSCDLElement(classifValue.getQname().getNamespace(), classifValue.getQname().getName(), classifValue.getCode());
			srvGrp.addChild(valueElem);
			
			if(classifValue.getChildren()!=null && classifValue.getChildren().size()>0) {
				addSerivceGroupClassifElements(srvGrp, classifValue.getChildren());
			}
		}
		
		return srvGrp;				
	}
	
	private void addSerivceGroupClassifElements(ServiceGroupCustomSCDLElement srvGrp, Collection<ClassificationSystemValue> classifs) {
		for(ClassificationSystemValue classifValue: classifs) {
			ServiceGroupClassifValueCustomSCDLElement valueElem = new ServiceGroupClassifValueCustomSCDLElement(classifValue.getQname().getNamespace(), classifValue.getQname().getName(), classifValue.getCode());
			srvGrp.addChild(valueElem);
			
			if(classifValue.getChildren()!=null && classifValue.getChildren().size()>0) {
				addSerivceGroupClassifElements(srvGrp, classifValue.getChildren());
			}
		}
	}

	private boolean hasXlfFile(LogicalSystem srvGroup) {
		final Partitionable part = (Partitionable) srvGroup;
		final String partitionName = part.get___Partition().getPri().getPartitionName();
		File root = pbi.getRootDir();
		
		File srvGroupPartitionFile = new File(root.getPath()+File.separator+partitionName);
		
		if(srvGroupPartitionFile.exists()) {
			File srvGroupXlfFile = new File(root.getPath()+File.separator+partitionName+".xlf"); //$NON-NLS-1$
			
			return srvGroupXlfFile.exists();
		}
		
		return false;
	}
	
	private String getSGBundleNameForOldSrvGroups(LogicalSystem srvGroup) {
		final Partitionable part = (Partitionable) srvGroup;
		final String partitionName = part.get___Partition().getPri().getPartitionName();
		
		return partitionName.substring(partitionName.lastIndexOf("/")+1);//$NON-NLS-1$
	}
	
	private String getSGBundleName(LogicalSystem srvGroup) {
		String sgBundleName = null; 
			
		if(srvGroup.getGuid()==null) {
			if(hasXlfFile(srvGroup)) {
				sgBundleName = getSGBundleNameForOldSrvGroups(srvGroup);
			}
		}
		else {
			sgBundleName = srvGroup.getGuid()+".consgroup";
		}
		
		return sgBundleName;
	}
	
	private void addServiceGroupToComposite(LogicalSystem srvGroup) {		
		final ServiceGroupCustomSCDLElement srvGrp = createServiceGroup(mcMetamodelInteractor.getServiceGroupName(srvGroup), 
				srvGroup.getSystemClassifications(), getSGBundleName(srvGroup)); //$NON-NLS-1$
			
		addSrvGrpToSrvGroups(srvGrp);
	}

	private void addSrvGrpToSrvGroups(ServiceGroupCustomSCDLElement srvGrp) {
		for(ServiceGroupCustomSCDLElement srvGroup : srvGroupList) {
			if(srvGroup.getSrvGroupName().equals(srvGrp.getSrvGroupName())) {
				return;
			}
		}
		
		srvGroupList.add(srvGrp);
	}
}
