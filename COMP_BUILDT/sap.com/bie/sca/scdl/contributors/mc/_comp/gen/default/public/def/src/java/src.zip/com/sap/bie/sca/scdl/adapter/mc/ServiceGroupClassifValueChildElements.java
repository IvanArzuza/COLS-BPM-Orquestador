package com.sap.bie.sca.scdl.adapter.mc;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;

public class ServiceGroupClassifValueChildElements extends CustomScdlElement {
	public ServiceGroupClassifValueChildElements(QName name, String value) {
		super(name);
		
		addAttribute(new CustomScdlAttribute(new QName("value"), new AttributeValue(new QName(value))));
	}
}
