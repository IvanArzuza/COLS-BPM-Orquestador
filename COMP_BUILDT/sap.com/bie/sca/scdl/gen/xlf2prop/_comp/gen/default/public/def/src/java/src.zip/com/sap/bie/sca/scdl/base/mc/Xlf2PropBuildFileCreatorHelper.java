package com.sap.bie.sca.scdl.base.mc;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.gen.IGeneratorCall;
import com.sap.tc.buildplugin.util.BuildPluginException;
import com.sap.tc.buildplugin.util.IAntToolkit;

public class Xlf2PropBuildFileCreatorHelper {
	public static void createGeneratorCallPart(IGlobalPluginUtil gpu, IPluginBuildInfo pbi, String chainId)
			throws BuildPluginException, IOException {
		// calls the generator chain defined in .bpfext which generates the MM
		IGeneratorCall gc = gpu.createGeneratorCall(chainId);
		File xlf_out = gpu.createTempDir("xlf_out");
		gc.setOutputPath("default", xlf_out.getAbsolutePath());
		if(pbi.getDCType()!=null && pbi.getDCSubType()!=null && pbi.getDCType().equals("J2EE") && pbi.getDCSubType().equals("WebModule")) {
			pbi.getFolderAttributeManager().addFolderAttributes(xlf_out, "war-content[prefix[META-INF/sca-resources/]]");
		}
		gc.invoke();
	}

	public static void createScdlDeployArchivePreparationPart(IGlobalPluginUtil gpu, IPluginBuildInfo pbi, IAntToolkit antToolKit,
			String chainId, String generatorId) throws IOException {
		antToolKit.taskdef("prepda"); //$NON-NLS-1$
		IAntToolkit.Element entity = antToolKit.createElement("prepda"); //$NON-NLS-1$

		// create second fileset to collect the properties files
		List<String> xlf_out = gpu.getGeneratorTypeOutputFolders("sap.com~xlf2prop_gen_chain", "xlf_out");
		for (String o : xlf_out) {
			IAntToolkit.Element filesetChild = entity.createChild("fileset"); //$NON-NLS-1$
			filesetChild.addAttribute("dir", o); //$NON-NLS-1$ //$NON-NLS-2$
			filesetChild.addAttribute("prefix", "META-INF/sca-resources/"); //$NON-NLS-1$ //$NON-NLS-2$
		}
		entity.render();
	}
}
