package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IImplementation;

/**
 * Default {@link IImplementation} interface implementation. Can be used in order not to develop new
 * implementor every time we need {@link IImplementation} instance. 
 * 
 * @author I036509
 */
public class Implementation extends CustomizableElement implements IImplementation 
{
	private static final String IMPLEMENTATION = "implementation"; //$NON-NLS-1$
	private final QName name;
	
	/**
	 * Constructor
	 * @param customScdlElement
	 * @throws NullPointerException in case <code>customScdlElement</code> is <code>null</code>
	 */
	public Implementation(final String type) {
		emptyStringCheckParam(type, "type"); //$NON-NLS-1$
		this.name = new QName(IMPLEMENTATION + '.' + type);
	}
	
	/**
	 * Constructor
	 * @param customScdlElement
	 * @throws NullPointerException in case <code>customScdlElement</code> is <code>null</code>
	 */
	public Implementation(final QName name) {
		nullCheckParam(name, "name"); //$NON-NLS-1$
		this.name = name;
	}

	public QName getName() {
		return name;
	}
}
