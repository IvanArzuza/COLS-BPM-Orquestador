package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import java.text.MessageFormat;

import javax.xml.namespace.QName;
import com.sap.bie.sca.scdl.adapter.IAttributeValue;

/**
 * Default implementation of {@link IAttributeValue} 
 * 
 * @author I036509
 */
public class AttributeValue implements IAttributeValue 
{
	private final QName value;

	/**
	 * Constructor
	 * 
	 * @param value - the attribute value, {@link QName#getLocalPart()} is used as attribute value
	 * in order to keep the constructor signature simple 
	 * @throws NullPointerException in case <code>value</code> is <code>null</code>
	 */
	public AttributeValue(final QName value) 
	{
		nullCheckParam(value, "value"); //$NON-NLS-1$
		this.value = value;
	}

	public String getNamespace() {
		return value.getNamespaceURI();
	}

	public String getNamespacePrefix() {
		return value.getPrefix();
	}

	public String getValue() {
		return value.getLocalPart();
	}

	public String toString() {
		return MessageFormat.format("AttributeValue [{0}]", value); //$NON-NLS-1$
	}
	
	public int compareTo(IAttributeValue attrValue) {
		int result=0;
		
		result = attrValue.getNamespace().compareTo(this.getNamespace());
		if(result!=0)
			return result;
		
		result = attrValue.getValue().compareTo(this.getValue());
		return result;
	}
}
