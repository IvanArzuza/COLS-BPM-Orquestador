package com.sap.bie.sca.scdl.adapter.impl;

import static com.sap.bie.sca.scdl.gen.util.ContractChecker.emptyStringCheckParam;
import static com.sap.bie.sca.scdl.gen.util.ContractChecker.nullCheckParam;

import java.util.Collection;

import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IImplementation;
import com.sap.bie.sca.scdl.adapter.IReference;
import com.sap.bie.sca.scdl.adapter.IService;

/**
 * Default {@link IComponent} implementation. Can be used in order not to develop new
 * implementor every time we need {@link IComponent} instance. 
 * 
 * @author I036509
 */
public class Component extends CustomizableElement implements IComponent 
{
	private final NoNullsList<IReference> references = new NoNullsList<IReference>();
	private final NoNullsList<IService> services = new NoNullsList<IService>();
	
	private final IImplementation implementation;
	private final String name;
	
	/**
	 * Constructor
	 * @param name the name returned by {@link IComponent#getName()}
	 * @param implementation the implementation returned by {@link IComponent#getImplementation()} 
	 * @throws NullPointerException in case some of parameters is <code>null</code>
	 */
	public Component(final String name, final IImplementation implementation) 
	{
		emptyStringCheckParam(name, "name"); //$NON-NLS-1$
		nullCheckParam(implementation, "implementation"); //$NON-NLS-1$
		
		this.name = name;
		this.implementation = implementation;
	}
	
	public IImplementation getImplementation() {
		return implementation;
	}

	public String getName() {
		return name;
	}
	
	/**
	 * Adds service to the list of services
	 * @param service
	 * @return result of {@link Collection#add(Object)}
	 */
	public boolean addService(final IService service) {
		return services.add(service);
	}

	public Collection<IService> getServices() {
		return services;
	}
	
	/**
	 * Adds reference to the list of references 
	 * @param reference
	 * @return result of {@link Collection#add(Object)}
	 */
	public boolean addReference(final IReference reference) {
		return references.add(reference);
	}

	public Collection<IReference> getReferences() {
		return references;
	}
	
	@SuppressWarnings("nls")
	@Override
	public String toString()
	{
		final StringBuilder sb = new StringBuilder();
		sb.append("Component [").append(name).append("]:").append(implementation.toString()) //$NON-NLS-1$ //$NON-NLS-2$
		  .append("\n\tservices [").append(services.toString()).append(']') //$NON-NLS-1$
		  .append("\n\treferences [").append(references.toString()).append(']'); //$NON-NLS-1$
		
		return sb.toString();
	}
}
