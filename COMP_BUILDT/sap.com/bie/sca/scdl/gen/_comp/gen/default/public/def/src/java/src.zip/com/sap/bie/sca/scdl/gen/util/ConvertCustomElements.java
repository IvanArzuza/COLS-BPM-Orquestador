/**
 * 
 */
package com.sap.bie.sca.scdl.gen.util;

import java.util.Collection;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;

/**
 * @author d038406
 *
 */
public class ConvertCustomElements extends Convert {
	
	private final Collection<ICustomScdlElement> extensions;
	
	public ConvertCustomElements(final Collection<ICustomScdlElement> extensions, final Element root) {
		super(root);
		this.extensions = extensions;
	}
	
	final void run() {
		if (extensions != null) {
			for (ICustomScdlElement scaCustomScdlElement : extensions) {
				ScdlExportService.handleScaCustomElement(getRoot(), scaCustomScdlElement, getRoot());
			}
		}
	}
}
