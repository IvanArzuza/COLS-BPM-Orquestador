/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;


/**
 * Defines one specific custom attribute that is added to an sca element (either
 * a standard element or a custom element itself). A custom attribute has to be
 * defined in its own namespace. Otherwise this will lead to a xml file that is
 * not compatible with the standard.
 * 
 * @author d038406
 * 
 */
public interface ICustomScdlAttribute {

	/**
	 * 
	 * Return the namespace to which the attribute returned by {@link
	 * getAttrbuteName()} belong. Implementors MUST NOT return <code>null</code>.
	 * 
	 * @return
	 * 
	 */
	String getAttributeNamespace();

	/**
	 * 
	 * Return the namespace prefix for the namespace returned in {@link
	 * getAttributeNamespace()}. Implementors MUST NOT return <code>null</code>.
	 * 
	 * @return
	 * 
	 */
	String getAttributeNamespacePrefix();

	/**
	 * Returns the name of the custom attribute. Implementors MUST NOT return
	 * <code>null</code>.
	 * 
	 * @return
	 */
	String getAttributeName();
	
	/**
	 * Returns the value of the custom attribute. Implementors MUST NOT return
	 * <code>null</code>.
	 * 
	 * @return
	 */
	IAttributeValue getAttributeValue();
}
