/**
 * 
 */
package com.sap.bie.sca.scdl.merge;

import java.util.ArrayList;
import java.util.Collection;

import com.sap.bie.sca.scdl.adapter.IBinding;
import com.sap.bie.sca.scdl.adapter.IComponent;
import com.sap.bie.sca.scdl.adapter.IComposite;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;
import com.sap.bie.sca.scdl.adapter.IInterface;
import com.sap.bie.sca.scdl.adapter.IReference;
import com.sap.bie.sca.scdl.adapter.IService;
import com.sap.bie.sca.scdl.adapter.IWire;

/**
 * 
 * @author d038406
 * 
 */
public class ScdlContributionsMerger {
	private Collection<IComposite> composites = new ArrayList<IComposite>();
	private String dcName;
	
	public void setDcName(String dcName) {
		this.dcName = dcName;
	}
	
	/**
	 * 
	 * Implement and hook up the merge logic here.
	 * 
	 * @param components
	 * 
	 */
	public Collection<IComposite> mergeScdlContributions(final Collection<IComposite> contributedComposites) {
		DcComposite dcComposite = new DcComposite();
		dcComposite.setName(this.dcName);
		composites.clear();
		composites.add(dcComposite);
		
		for (IComposite composite : contributedComposites) {
			addComposite(composite);
		}
		
		return composites;
	}
	
	private void addComposite(IComposite contributedComposite) {
		for(IComposite composite : composites) {
			if(compareComposites(composite, contributedComposite)) {
				if(contributedComposite.getComponents()!=null && contributedComposite.getComponents().size()>0) {
					addComponents(contributedComposite.getComponents(), composite);
				}
				if(contributedComposite.getWires()!=null && contributedComposite.getWires().size()>0) {
					addWires(contributedComposite.getWires(), composite);
				}
				if(contributedComposite.getCustomElements()!=null && contributedComposite.getCustomElements().size()>0) {
					addCustomElements(contributedComposite.getCustomElements(), composite);
				}
				if(contributedComposite.getCustomAttributes()!=null && contributedComposite.getCustomAttributes().size()>0) {
					addCustomAttributes(contributedComposite.getCustomAttributes(), composite);
				}
			}
		}
	}

	private boolean compareElementAttributes(Collection<ICustomScdlAttribute> elemAttributes1, Collection<ICustomScdlAttribute> elemAttributes2) {
		for(ICustomScdlAttribute attr1: elemAttributes1) {
			for(ICustomScdlAttribute attr2:elemAttributes2) {
				if((!attr2.getAttributeName().equals(attr1.getAttributeName()) ||
						(!attr2.getAttributeNamespace().equals(attr1.getAttributeNamespace())))) {
					return false;
				}
				if((!attr2.getAttributeValue().getValue().equals(attr1.getAttributeValue().getValue()) ||
						(!attr2.getAttributeValue().getNamespace().equals(attr1.getAttributeValue().getNamespace())))) {
					return false;
				}
			}
		}
		
		for(ICustomScdlAttribute attr2: elemAttributes2) {
			for(ICustomScdlAttribute attr1:elemAttributes1) {
				if((!attr2.getAttributeName().equals(attr1.getAttributeName()) ||
						(!attr2.getAttributeNamespace().equals(attr1.getAttributeNamespace())))) {
					return false;
				}
				if((!attr1.getAttributeValue().getValue().equals(attr2.getAttributeValue().getValue()) ||
						(!attr1.getAttributeValue().getNamespace().equals(attr2.getAttributeValue().getNamespace())))) {
					return false;
				}
			}
		}
		
		return true;
	}
	
	private boolean compareCustomScdlElements(Collection<ICustomScdlElement> elements1, Collection<ICustomScdlElement> elements2) {
		boolean result=true;
		
		for(ICustomScdlElement el1:elements1) {
			for(ICustomScdlElement el2:elements2) {
				if(!compareCustomScdlElement(el1,el2))
					result=false;
			}
		}
		
		for(ICustomScdlElement el2:elements2) {
			for(ICustomScdlElement el1:elements1) {
				if(!compareCustomScdlElement(el2,el1))
					result=false;
			}
		}
		
		return result;		
	}

	private boolean compareCustomScdlElement(ICustomScdlElement customElem1, ICustomScdlElement customElem2) {
		if(!customElem1.getElementName().equals(
				customElem2.getElementName())) {
			return false;
		}
		
		if(!((customElem1.getNamespace()!=null 
				&& customElem1.getNamespace().equals(customElem2.getNamespace()))
				|| (customElem2.getNamespace()!=null 
						&& customElem2.getNamespace().equals(customElem1.getNamespace())))) {
			return false;
		}
		
		return compareElementAttributes(customElem1.getCustomAttributes(), customElem2.getCustomAttributes()); 
	}
	
	private boolean compareComponents(IComponent component1, IComponent component2) {
		return component1.getName().equals(component2.getName()) 
		&& compareElementAttributes(component1.getCustomAttributes(), component2.getCustomAttributes())
		&& compareCustomScdlElements(component1.getCustomElements(), component2.getCustomElements());
	}
	
	private boolean compareComposites(IComposite composite1, IComposite composite2) {
		//TODO For EhP2 we have agreed with our runtime colleagues to have only one
		// composite file per DC. Therefore this method will always return true and the 
		// real implementation is commented out.
		return true;
//		return composite1.getName().equals(composite2.getName()) 
//		&& composite1.getTargetnamespace().equals(composite2.getTargetnamespace());
	}
	
	private boolean compareReferences(IReference reference1, IReference reference2) {
		return reference1.getName().equals(reference2.getName())
		&& compareElementAttributes(reference1.getCustomAttributes(), reference2.getCustomAttributes())
		&& compareBindings(reference1.getBinding(), reference2.getBinding())
		&& compareScaInterfaces(reference1.getScainterface(), reference2.getScainterface());
	}
	
	private boolean compareServices(IService service1, IService service2) {
		return service1.getName().equals(service2.getName())
		&& compareElementAttributes(service1.getCustomAttributes(), service2.getCustomAttributes())
		&& compareBindings(service1.getBinding(), service2.getBinding())
		&& compareScaInterfaces(service1.getScainterface(), service2.getScainterface());
	}
	
	private boolean compareBindings(IBinding binding1, IBinding binding2)  {
		if((binding1==null) && (binding2==null))
			return true;
		
		return compareCustomScdlElements(binding1.getCustomElements(), binding2.getCustomElements());
	}
	
	private boolean compareScaInterfaces(IInterface interface1, IInterface interface2) {
		if((interface1==null) && (interface2==null))
			return true;
		
		return compareCustomScdlElements(interface1.getCustomElements(), interface2.getCustomElements());
	}
	
	private boolean compareWires(IWire wire1, IWire wire2) {
		return wire1.getSource().equals(wire2.getSource())
		&& wire1.getTarget().equals(wire2.getTarget());
	}
	
	private boolean containsComponent(IComposite composite, IComponent component) {
		for(IComponent comp : composite.getComponents()) {
			if(compareComponents(comp, component)) {
				return true;
			}
		}
		
		return false;
	}
	
	private boolean containsReference(IComponent component, IReference reference) {
		for(IReference ref : component.getReferences()) {
			if(compareReferences(ref, reference)) {
				return true;
			}
		}
		
		return false;
	}
	
	private boolean containsService(IComponent component, IService service) {
		for(IService srv : component.getServices()) {
			if(compareServices(srv, service)) {
				return true;
			}
		}
		
		return false;
	}
	
	private boolean containsWire(IComposite composite, IWire wire) {
		for(IWire compWire : composite.getWires()) {
			if(compareWires(compWire, wire)) {
				return true;
			}
		}
		
		return false;
	}
	
	private boolean containsCustomExtension(IComposite composite, ICustomScdlElement customExtension) {
		for(ICustomScdlElement compCustomExtension : composite.getCustomElements()) {
			if(compareCustomScdlElement(compCustomExtension, customExtension)) {
				return true;
			}
		}
		return false;
	}
	
	private boolean containsChildCustomScdlElement(ICustomScdlElement targetCustomScdlElement, ICustomScdlElement childCustomScdlElement) {
		for(ICustomScdlElement childTargetCustomScdlElement : targetCustomScdlElement.getChildren()) {
			if(compareCustomScdlElement(childTargetCustomScdlElement, childCustomScdlElement)) {
				return true;
			}
		}
		return false;
	}

	private boolean containsCustomAttribute(IComposite composite, ICustomScdlAttribute customAttribute) {
		for(ICustomScdlAttribute compCustomAttribute : composite.getCustomAttributes()) {
			if(customAttribute.getAttributeName().equals(compCustomAttribute.getAttributeName()) &&
					(customAttribute.getAttributeNamespace().equals(compCustomAttribute.getAttributeNamespace()))) {
				return true;
			}
		}
		return false;
	}
	
	private ICustomScdlElement getChildCustomScdlElement(ICustomScdlElement targetCustomScdlElement, ICustomScdlElement childCustomScdlElement) {
		for(ICustomScdlElement childTargetCustomScdlElement : targetCustomScdlElement.getChildren()) {
			if(compareCustomScdlElement(childTargetCustomScdlElement, childCustomScdlElement)) {
				return childTargetCustomScdlElement;
			}
		}
		return null;
	}
	
	private ICustomScdlElement getCustomExtension(IComposite composite, ICustomScdlElement customExtension) {
		for(ICustomScdlElement compCustomExtension : composite.getCustomElements()) {
			if(compareCustomScdlElement(compCustomExtension, customExtension)) {
				return compCustomExtension;
			}
		}
		return null;
	}
	
	private IComponent getComponent(IComposite composite, IComponent component) {
		for(IComponent comp : composite.getComponents()) {
			if(compareComponents(comp, component)) {
				return comp;
			}
		}
		
		return null;
	}
	
	private void addCustomAttributes(
			Collection<ICustomScdlAttribute> customAttributes,
			IComposite composite) {
		for(ICustomScdlAttribute attribute:customAttributes) {
			if(!containsCustomAttribute(composite, attribute)) {
				composite.getCustomAttributes().add(attribute);
			}
		}		
	}
	
	private void addCustomElements(
			Collection<ICustomScdlElement> customExtensions,
			IComposite composite) {
		for(ICustomScdlElement customExtension : customExtensions) {
			if(containsCustomExtension(composite, customExtension)) {
				if(customExtension.getChildren()!=null && customExtension.getChildren().size()>0) {
					addCustomExtensionsChildren(getCustomExtension(composite, customExtension), customExtension.getChildren());
				}
				continue;
			}
			composite.getCustomElements().add(customExtension);
		}
	}
	
	private void addCustomExtensionsChildren(ICustomScdlElement targetCustomScdlElement, Collection<ICustomScdlElement> childCustomScdlElements) {
		for(ICustomScdlElement childCustomScdlElement : childCustomScdlElements) {
			if(containsChildCustomScdlElement(targetCustomScdlElement, childCustomScdlElement)) {
				if(childCustomScdlElement.getChildren()!=null && childCustomScdlElement.getChildren().size()>0) {
					addCustomExtensionsChildren(getChildCustomScdlElement(targetCustomScdlElement, childCustomScdlElement), childCustomScdlElements);
				}
				continue;
			}
			
			targetCustomScdlElement.getChildren().add(childCustomScdlElement);
		}
	}

	private void addWires(Collection<IWire> wires, IComposite composite) {
		for(IWire wire : wires) {
			if(containsWire(composite, wire)) {
				continue;
			}
			
			composite.getWires().add(wire);
		}
	}

	private void addComponents(Collection<IComponent> components,
			IComposite composite) {
		for(IComponent component : components) {
			if(containsComponent(composite, component)) {
				addReferences(getComponent(composite, component), component.getReferences());
				addServices(getComponent(composite, component), component.getServices());
				continue;
			}
			
			composite.getComponents().add(component);
		}
	}
	
	private void addReferences(IComponent component, Collection<IReference> references) {
		for(IReference reference : references) {
			if(containsReference(component, reference)) {
				continue;
			}
			
			component.getReferences().add(reference);
		}
	}
	
	private void addServices(IComponent component, Collection<IService> services) {
		for(IService service : services) {
			if(containsService(component, service)) {
				continue;
			}
			
			component.getServices().add(service);
		}
	}
}
