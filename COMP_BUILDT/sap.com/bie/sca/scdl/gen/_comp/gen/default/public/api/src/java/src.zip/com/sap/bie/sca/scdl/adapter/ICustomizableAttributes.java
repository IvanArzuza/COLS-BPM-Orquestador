/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;

import java.util.Collection;

/**
 * Provides methods to contribute custom attributes to an element. A custom attribute
 * is an attribute that has not been defined by the SCA assembly model, but either by
 * a technology specific specification extension or any proprietary attributes. 
 * Custom attributes can be added for standard SCA model as well as a custom element.
 * 
 * @author d038406
 *
 */
public interface ICustomizableAttributes {
	/**
	 * Returns all custom attributes defined for this element.
	 * 
	 * @return
	 */
	Collection<ICustomScdlAttribute> getCustomAttributes();
}
