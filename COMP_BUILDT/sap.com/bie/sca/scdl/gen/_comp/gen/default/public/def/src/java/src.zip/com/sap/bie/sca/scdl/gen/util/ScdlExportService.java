/**
 * 
 */
package com.sap.bie.sca.scdl.gen.util;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.ICustomScdlElement;

/**
 * 
 * @author d038406
 * 
 */
public class ScdlExportService {

	/**
	 * @param root
	 * @param scaCustomElements
	 * @param scaCustomElementXmlParent
	 */
	public static void handleScaCustomElements(final Element root, final Collection<ICustomScdlElement> scaCustomElements,
			final Element scaCustomElementXmlParent) {
		for (Iterator<ICustomScdlElement> iterator = scaCustomElements.iterator(); iterator.hasNext();) {
			ICustomScdlElement scaCustomScdlElement = iterator.next();
			handleScaCustomElement(root, scaCustomScdlElement, scaCustomElementXmlParent);
		}
	}
	/**
	 * 
	 * @param scaCustomElement
	 * 
	 */
	public static void handleScaCustomElement(final Element root, final ICustomScdlElement scaCustomElement,
			final Element scaCustomElementXmlParent) {
		ContractChecker.nullCheckParam(scaCustomElement);
		ContractChecker.nullCheckParam(scaCustomElementXmlParent);
		String scdlTagName = scaCustomElement.getElementName();
		//According to Plamen and SOA Runtime colleagues it is perfectly fine and allowed by
		// the spec to define custom SCDL tags wihtout providing the namespace attribute.
		// Therefore the check for null is needed here.
		if(scaCustomElement.getNamespace()!=null) {
			scdlTagName = handleNamespace(root, scdlTagName, scaCustomElement.getNamespace(), scaCustomElement.getNamespacePrefix());
		}
		Element scaXmlCustomElement = root.getOwnerDocument().createElement(scdlTagName);
		handleScaCustomElementAttributes(root, scaCustomElement, scaXmlCustomElement);
		scaCustomElementXmlParent.appendChild(scaXmlCustomElement);
		if (scaCustomElement.getChildren()!= null && scaCustomElement.getChildren().size() > 0) {
			handleScaCustomElements(root, scaCustomElement.getChildren(), scaXmlCustomElement);
		}
	}

	/**
	 * 
	 * Generic method to create an xml tag with a name attribute.
	 * 
	 * @param xmlParent
	 *            - the parent of the element to be created.
	 * @param elementName
	 *            - the name of the element to be created.
	 * @param nameAttributeValue
	 *            - the value of the name attribute.
	 *            
	 * @return
	 * 
	 */
	public static Element createXmlTagWithNameAttribute(final Element root, final Element xmlParent, final String elementName,
			final String nameAttributeValue) {
		ContractChecker.nullCheckParam(root);
		ContractChecker.nullCheckParam(xmlParent);
		ContractChecker.nullCheckParam(elementName);
		ContractChecker.nullCheckParam(nameAttributeValue);
		ContractChecker.stringLengthGreaterThenCheck(nameAttributeValue, 0);
		Element newElement = root.getOwnerDocument().createElement(elementName);
		newElement.setAttribute("name", nameAttributeValue); //$NON-NLS-1$
		xmlParent.appendChild(newElement);
		return newElement;
	}

	/**
	 * 
	 * Generic method to create an xml tag with a name attribute.
	 * 
	 * @param xmlParent
	 *            - the parent of the element to be created.
	 * @param elementName
	 *            - the name of the element to be created.
	 * @param nameAttributeValue
	 *            - the value of the name attribute.
	 *            
	 * @return
	 * 
	 */
	public static Element createXmlTagWithNameAttributeAndCustomAttributes(final Element root, final Element xmlParent, final String elementName,
			final String nameAttributeValue, final Map<String, String> customAttributes) {
		ContractChecker.nullCheckParam(root);
		ContractChecker.nullCheckParam(xmlParent);
		ContractChecker.nullCheckParam(elementName);
		ContractChecker.nullCheckParam(nameAttributeValue);
		ContractChecker.stringLengthGreaterThenCheck(nameAttributeValue, 0);
		Element newElement = root.getOwnerDocument().createElement(elementName);
		newElement.setAttribute("name", nameAttributeValue); //$NON-NLS-1$
		if(customAttributes!=null) {
			for(String attribKey : customAttributes.keySet()) {
				newElement.setAttribute(attribKey, customAttributes.get(attribKey));
			}
		}
		xmlParent.appendChild(newElement);
		return newElement;
	}

	/**
	 * 
	 * @param mmScaCustomElement
	 * @param scaCustomElement
	 * 
	 */
	private static void handleScaCustomElementAttributes(Element root, final ICustomScdlElement mmScaCustomElement, Element scaCustomElement) {
		Collection<ICustomScdlAttribute> attributes = mmScaCustomElement.getCustomAttributes();
		handleAttributes(root, attributes, scaCustomElement);
	}
	
	public static void handleAttributes(Element root, final Collection<ICustomScdlAttribute> attributes, Element scaElement) {
		if (attributes != null && attributes.size() > 0) {
			for(ICustomScdlAttribute attribute:attributes) {
				
				IAttributeValue value = attribute.getAttributeValue();
				
				String strValue=null;
				if(value.getNamespacePrefix()==null) {
					strValue=value.getValue();
				}
				else {
					strValue=handleNamespaceForAttribute(root, value.getValue(), value.getNamespace(),
								value.getNamespacePrefix());
				}
				
				if(attribute.getAttributeNamespace()==null) {
					scaElement.setAttribute(attribute.getAttributeName(),
									strValue);
				}
				else {
					String name= handleNamespaceForAttribute(root, attribute.getAttributeName(), 
							attribute.getAttributeNamespace(), attribute.getAttributeNamespacePrefix());
					scaElement.setAttribute(name, strValue);
				}
			}
		}
	}

	/**
	 * 
	 * Takes care of the namespace handling. When defined in the MM the
	 * necessary entries for the corresponding element are added to the SCDL
	 * file.
	 * 
	 * @param impl
	 * 
	 * @return element tag
	 * 
	 */
	public static String handleNamespace(final Element root, final String elementTag, final String scaNamespace,
			final String scaNamespacePrefix) {
		// check namespace definition in the root element
		String xmlNsDef = "xmlns:" + scaNamespacePrefix; //$NON-NLS-1$
		if (!xmlNsDef.trim().equals("xmlns:") && root.getAttribute(xmlNsDef).equals("")) { //$NON-NLS-1$ //$NON-NLS-2$
			root.setAttribute(xmlNsDef, scaNamespace);
		}
		// TODO: check namespace URL in case namespace prefix is already
		// defined, in case we have to difference impls...
		if(scaNamespacePrefix!=null && scaNamespacePrefix.trim().length()>0) {
			return scaNamespacePrefix + ":" + elementTag; //$NON-NLS-1$
		}
		else {
			return elementTag;
		}
	}

	public static String handleNamespaceForAttribute(final Element root, final String attributeName, final String scaNamespace,
			final String scaNamespacePrefix) {
		// check namespace definition in the root element
		String xmlNsDef = "xmlns:" + scaNamespacePrefix; //$NON-NLS-1$
		if (!xmlNsDef.trim().equals("xmlns:") && root.getAttribute(xmlNsDef).equals("")) { //$NON-NLS-1$ //$NON-NLS-2$
			root.setAttribute(xmlNsDef, scaNamespace);
		}
		// TODO: check namespace URL in case namespace prefix is already
		// defined, in case we have to difference impls...
		if(scaNamespacePrefix!=null && scaNamespacePrefix.trim().length()>0) {
			return scaNamespacePrefix + ":" + attributeName; //$NON-NLS-1$
		}
		else {
			return attributeName;
		}
	}
}
