package com.sap.bie.sca.scdl.adapter;

import com.sap.tc.buildplugin.api.IGlobalPluginUtil;
import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.moin.repository.Connection;

/**
 * 
 * The common SCDL infrastructure adapter interface. This interface is to be
 * implemented by technologies contributing to a common SCDL.
 * 
 * @author d038406
 * 
 */
public interface IScdlContributor {

	/**
	 * @param connection
	 *            - temporary workaround to support usage of MOIN in our adapter
	 *            based DC build scenario // TODO discuss requirement of this
	 *            with Boris further and get rid of this param eventually.
	 * @param globalPluginUtil
	 * @param pluginBuildInfo
	 * @return
	 */
	IComposite getComposite(Connection connection,
			IGlobalPluginUtil globalPluginUtil, IPluginBuildInfo pluginBuildInfo);
}
