package com.sap.bie.sca.scdl.pp;

import com.sap.bie.sca.scdl.gen.ScdlGeneratorBuildFileCreator;
import com.sap.tc.buildplugin.pp.AbstractEntityHandler;
import com.sap.tc.buildplugin.pp.EntityDataProvider;
import com.sap.tc.buildplugin.pp.IEntityFileSet;
import com.sap.tc.buildplugin.pp.PackException;
import com.sap.tc.buildplugin.pp.PackerDestination;
import com.sap.tc.buildplugin.pp.api.IEntity;
import com.sap.tc.buildplugin.pp.util.FileSet;
import com.sap.tc.buildplugin.pp.util.PathIdentifier;

public class ScdlEntityHandler extends AbstractEntityHandler {
	
	private static final String SCDL_OUTPUT_INCLUDE_FOLDER = "META-INF/*"; //$NON-NLS-1$

	public void determineFileList(IEntityFileSet entityFileSet, IEntity entity, EntityDataProvider entityDataProvider) throws PackException {
		PathIdentifier path = new PathIdentifier(PathIdentifier.BASE_GEN, ScdlGeneratorBuildFileCreator.SCDL_OUTPUT);
		FileSet fs = entityDataProvider.createFileSet(path);
		fs.addInclude(SCDL_OUTPUT_INCLUDE_FOLDER);
		entityFileSet.addFileSet(PackerDestination.JAVALIB, fs);
		fs.dispose();
	}
}
