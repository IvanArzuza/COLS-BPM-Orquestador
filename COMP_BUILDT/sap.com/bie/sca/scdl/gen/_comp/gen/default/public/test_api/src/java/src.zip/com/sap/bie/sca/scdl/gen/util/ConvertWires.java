package com.sap.bie.sca.scdl.gen.util;

import java.util.Collection;

import org.w3c.dom.Element;

import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.IWire;

/**
 * 
 * This adds the wires contained in the project to the passed root.
 * 
 * @author D038406
 * 
 */
public class ConvertWires extends Convert {
	
	private static final String XML_TAG_WIRE = "wire"; //$NON-NLS-1$
	private static final String XML_ATTRIBUTE_SOURCE = "source"; //$NON-NLS-1$
	private static final String XML_ATTRIBUTE_TARGET = "target"; //$NON-NLS-1$
	
	private final Collection<IWire> wires;

	public ConvertWires(Collection<IWire> wires, Element root) {
		super(root);
		ContractChecker.nullCheckParam(wires);
		this.wires = wires;	
	}

	public final void run() {
		for (IWire wire : wires) {
			Element elWire = getRoot().getOwnerDocument().createElement(XML_TAG_WIRE);
			elWire.setAttribute(XML_ATTRIBUTE_TARGET, wire.getTarget()); 
			elWire.setAttribute(XML_ATTRIBUTE_SOURCE, wire.getSource()); 		
			
			Collection<ICustomScdlAttribute> customAttributes = wire.getCustomAttributes();					
			ScdlExportService.handleAttributes(getRoot(), customAttributes, elWire);				
			
			getRoot().appendChild(elWire);
		}
	}
}
