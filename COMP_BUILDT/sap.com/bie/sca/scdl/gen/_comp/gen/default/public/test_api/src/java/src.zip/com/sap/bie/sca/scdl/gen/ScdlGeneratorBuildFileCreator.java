package com.sap.bie.sca.scdl.gen;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import com.sap.tc.buildplugin.api.IDataContext;
import com.sap.tc.buildplugin.gen.AbstractGenerator;
import com.sap.tc.buildplugin.gen.GeneratorException;
import com.sap.tc.buildplugin.util.IAntToolkit;
import com.sap.tc.buildplugin.util.IAntToolkit.Element;

/**
 * 
 * This class defines the ant segment in the build file for the EC DT Metamodel --> RT (i.e. scdl)
 * generator.
 * 
 * @author D038406
 * 
 */
public class ScdlGeneratorBuildFileCreator extends AbstractGenerator {

	private static final String EC_GENERATOR_ID = "gen_scdl"; //$NON-NLS-1$
	public static final String SCDL_OUTPUT = "scdl_output"; //$NON-NLS-1$
	
	/* (non-Javadoc)
	 * @see com.sap.tc.buildplugin.gen.IGenerator#execute(com.sap.tc.buildplugin.util.IAntToolkit, com.sap.tc.buildplugin.api.IDataContext, java.util.Map, java.util.Map, java.util.Map, java.util.Map)
	 */
	@SuppressWarnings("unchecked")
	public void execute(IAntToolkit antWriter, IDataContext localContext, Map<String, List> inputPaths, Map<String, Object> outputPaths,
			Map<String, List> usedPaths, Map<String, Object> parameters) throws GeneratorException, IOException {
				
		Element elem = antWriter.createElement(EC_GENERATOR_ID);
		antWriter.startTimer("Starting Extension Configuration generator..."); //$NON-NLS-1$
		elem.render();
		antWriter.showTimer("Extension Configuration generator"); //$NON-NLS-1$
	}
}
