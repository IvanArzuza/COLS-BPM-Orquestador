/**
 * 
 */
package com.sap.bie.sca.scdl.adapter;

import java.util.Map;
import java.util.SortedSet;

/**
 * Certain elements in the composite file can be enriched with a classification.
 * This will be used to category contributions from different tools and/or 
 * technology and to visualize them at runtime.
 * 
 * The classification information will be generated into file that is compatible
 * with a service registry category. As a result, the sca metadata provided by
 * the contributor can be searched at runtime using the sr classification 
 * capabilities.
 * 
 * As of EhP2, only sca references and services ({@link IService} and {@link IReference})
 * can be classified.
 * 
 * @author d038406
 *
 */
public interface IClassifiedScdlContribution {
	
	/**
	 * Returns the categories which will be assigned to the object instance implementing
	 * this interface. The object will be listed at runtime under all these categories.
	 * The structure that is expected as output contains the category name as key as well
	 * as a set of values for this category. 
	 * 
	 * @return {@link Map} containing the categories to which the object will be assigned 
	 */
	public Map<IAttributeValue, SortedSet<IAttributeValue>> getScdlContributionClassifications();
}
