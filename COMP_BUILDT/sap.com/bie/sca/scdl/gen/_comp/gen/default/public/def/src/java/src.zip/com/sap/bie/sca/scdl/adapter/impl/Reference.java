package com.sap.bie.sca.scdl.adapter.impl;

import com.sap.bie.sca.scdl.adapter.IReference;

public class Reference extends ComponentElement implements IReference 
{
	private static final String REFERENCE = "reference"; //$NON-NLS-1$

	public Reference(String name) {
		super(name);
	}
	
	public Reference() {
		this(REFERENCE); 
	}
}
