package com.sap.bie.sca.scdl.mc.adapter;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.ComponentElement;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.gen.mc.IMcScdlReference;
import com.sap.bie.sca.scdl.gen.mc.McNamespaceConstants;

public class McReference extends ComponentElement implements IMcScdlReference 
{
	public McReference(final String name) {
		super(name);
	}

	public void setSrvGroupName(String srvGroupName) 
	{
		final IAttributeValue value = new AttributeValue(new QName(srvGroupName));
		final ICustomScdlAttribute attribute = new CustomScdlAttribute(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, McNamespaceConstants.SERVICE_GROUP, McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME), value);
		addAttribute(attribute);
	}

	public void setAuthProfileName(final String authProfileName) {
		final IAttributeValue value = new AttributeValue(new QName(authProfileName));
		final ICustomScdlAttribute attribute = new CustomScdlAttribute(new QName(McNamespaceConstants.SAPCONFIG_NAMESPACE_VALUE, McNamespaceConstants.AUTHENTICATION_PROFILE, McNamespaceConstants.SAPCONFIG_NAMESPACE_NAME), value);
		addAttribute(attribute);
	}
}
