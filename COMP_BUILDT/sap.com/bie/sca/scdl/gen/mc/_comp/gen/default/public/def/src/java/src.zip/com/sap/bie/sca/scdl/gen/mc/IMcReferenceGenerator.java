package com.sap.bie.sca.scdl.gen.mc;

import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IReference;

public interface IMcReferenceGenerator {
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided Mass Configuration metadata. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param srIds - the list of service reference ids for which the scdl 
	 * reference tags are needed
	 * @return the list of SCDL references to be associated to the provided 
	 * component
	 */
	public List<IReference> genReferences(String[] srIds) throws NoSuchServiceReferenceExistsException; 
	
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided Mass Configuration metadata. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param srIds - the list of service reference ids for which the scdl 
	 * reference tags are needed
	 * @param wsdlLocations - the list of wsdl locations mapping exactly in the same order
	 * as the provided list of service reference ids. This means that a service reference
	 * that can be found in the provided list srIds at position 0 is the service reference
	 * generated out of wsdl location described in the wsdlLocations list at position 0. 
	 * The length of srIds array and wsdlLocations array should be identical otherwise an 
	 * IndexOutOfBoundsException will be thrown.
	 * @return the list of SCDL references to be associated to the provided 
	 * component
	 */
	public List<IReference> genReferences(String[] srIds, String[] wsdlLocations) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided Mass Configuration metadata. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param srvGroupName - the qualified name of the MC Service Group object 
	 * @param portTypeQualifiedName - a list of WSDL portType quialifed names where the namespace 
	 * is the key in this map and the value is the portType unqualified name 
	 * @return the list of SCDL references to be associated to the provided 
	 * component
	 */
	public List<IReference> genReferences(String srvGroupName, Map<String, String> portTypeQualifiedName) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided Mass Configuration metadata. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param srvGroupName - the qualified name of the MC Service Group object 
	 * @param portTypeQualifiedName - a list of WSDL portType quialifed names where the namespace 
	 * is the key in this map and the value is the portType unqualified name 
	 * @param wsdlLocations - the list of wsdl locations mapping exactly to the provided 
	 * portType qualified name in the portTypeQualifiedName map. 
	 * @return the list of SCDL references to be associated to the provided 
	 * component
	 */
	public List<IReference> genReferences(String srvGroupName, Map<String, String> portTypeQualifiedName, Map<String, String> wsdlLocations) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided Mass Configuration metadata. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param srvGroupName - the qualified name of the MC Service Group object 
	 * @param portTypeName - the WSDL portType unqualified name 
	 * @param portTypeNamespace - the WSDL portType namespace 
	 * @return the list of SCDL references to be associated to the provided 
	 * component
	 */
	public List<IReference> genReferences(String srvGroupName, String portTypeName, String portTypeNamespace) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided Mass Configuration metadata. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param srvGroupName - the qualified name of the MC Service Group object 
	 * @param portTypeName - the WSDL portType unqualified name 
	 * @param portTypeNamespace - the WSDL portType namespace 
	 * @param wsdlLocation - the wsdl location of the given portType 
	 * @return the list of SCDL references to be associated to the provided 
	 * component
	 */
	public List<IReference> genReferences(String srvGroupName, String portTypeName, String portTypeNamespace, String wsdlLocation) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided Mass Configuration metadata. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param srvGroupName - the qualified name of the MC Service Group object 
	 * @return the list of SCDL references to be associated to the provided 
	 * component
	 */
	public List<IReference> genReferences(String srvGroupName) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided Mass Configuration metadata. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param srvGroupName - the qualified name of the MC Service Group object 
	 * @param wsdlLocation - it is assumed that all service references for the given service
	 * group are coming out of only one wsdl and its location is required. 
	 * @return the list of SCDL references to be associated to the provided 
	 * component
	 */
	public List<IReference> genReferences(String srvGroupName, String wsdlLocation) throws NoSuchServiceReferenceExistsException;
	
	/**
	 * Utility method for generating the SCDL reference objects for a given SCDL 
	 * component and based on the provided collection of port type's. The generated 
	 * SCDL reference objects are automatically assigned to the provided component. The
	 * returned list is a copy of the already associated list of SCDL references to the 
	 * provided SCDL component.
	 * 
	 * @param portTypes map containing portType QName as key and wsdlLocation as value 
	 * @return map of generated references. In case some of provided portTypeNames is not found
	 * in mass configuration meta-data references for this portType is not added to the map. 
	 * @throws NoSuchServiceReferenceExistsException
	 */
	public Map<QName, List<IReference>> genReferences(final Map<QName, String> portTypes) throws NoSuchServiceReferenceExistsException;
}
