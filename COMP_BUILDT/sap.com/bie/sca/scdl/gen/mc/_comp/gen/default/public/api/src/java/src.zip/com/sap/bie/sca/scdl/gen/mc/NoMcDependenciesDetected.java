package com.sap.bie.sca.scdl.gen.mc;

public class NoMcDependenciesDetected extends Exception {
	private static final long serialVersionUID = 1L;

	public NoMcDependenciesDetected(String message) {
		super(message);
	}
}
