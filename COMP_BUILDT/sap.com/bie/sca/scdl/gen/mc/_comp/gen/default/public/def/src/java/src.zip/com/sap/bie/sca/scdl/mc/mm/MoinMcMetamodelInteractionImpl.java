package com.sap.bie.sca.scdl.mc.mm;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.moin.repository.mmi.reflect.RefBaseObject;
import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.gen.mc.IMcMetamodelInteraction;
import com.sap.bie.sca.scdl.gen.mc.NoSuchServiceReferenceExistsException;
import com.sap.ide.es.config.mc.model.mc.logicalsystem.LogicalSystem;
import com.sap.ide.es.config.mc.model.mc.servicereferences.ServiceReference;
import com.sap.tc.moin.repository.Connection;
import com.sap.tc.moin.repository.MRI;
import com.sap.tc.moin.repository.PRI;
import com.sap.tc.moin.repository.Partitionable;
import com.sap.tc.moin.repository.mql.MQLProcessor;
import com.sap.tc.moin.repository.mql.MQLResultSet;
import com.sap.tc.moin.repository.mql.QueryScopeProvider;

public class MoinMcMetamodelInteractionImpl implements IMcMetamodelInteraction {
	private static final String MC_MODEL_CONTAINER_NAME = "sap.com/com/sap/ide/es/config/mc/model"; //$NON-NLS-1$
	
    private static final String TYPE_SERVICE_REFERENCE = "ServiceReference"; //$NON-NLS-1$
	private static final String PACKAGE_SERVICEREFERENCES = "mc::\"servicereferences\""; //$NON-NLS-1$
	private static final String ALIAS_SERVICE_REFERENCE = "sr"; //$NON-NLS-1$
	
    private static final String TYPE_LOGICAL_SYSTEM = "LogicalSystem"; //$NON-NLS-1$
	private static final String PACKAGE_LOGICALSYSTEM = "mc::\"logicalsystem\""; //$NON-NLS-1$
	private static final String ALIAS_LOGICAL_SYSTEM = "ls"; //$NON-NLS-1$
	
	private String containerName;
	private Connection connection;
	
	public MoinMcMetamodelInteractionImpl(IPluginBuildInfo pbi, Connection conn) {
		this.containerName = pbi.getDCVendor() + "/" + pbi.getDCName(); //$NON-NLS-1$
		this.connection = conn;
	}
	
	private final MQLResultSet doQuery( final String query)
	{
		PRI[] partitionScope = new PRI[] { this.connection.getNullPartition().getPri() };
		MQLProcessor processor = this.connection.getMQLProcessor();
		QueryScopeProvider scopeProvider = processor.getQueryScopeProvider(	true, 
																			partitionScope, 
																			processor.getCrisForContainerNames( this.containerName ) );
		MQLResultSet resultSet = processor.execute(	query, 
													scopeProvider );

		return resultSet;
	}
	
	public ServiceReference getServiceReference(String srId) throws NoSuchServiceReferenceExistsException {
		String query = String.format(  "select %s from \"%s\"#%s::%s withoutsubtypes as %s where %s.id='%s'", //$NON-NLS-1$
				   ALIAS_SERVICE_REFERENCE,
				   MC_MODEL_CONTAINER_NAME, 
				   PACKAGE_SERVICEREFERENCES, 
				   TYPE_SERVICE_REFERENCE, 
				   ALIAS_SERVICE_REFERENCE,
				   ALIAS_SERVICE_REFERENCE,
				   srId);
		final MQLResultSet resultSet = doQuery(query);
		final List<RefBaseObject> result = convertMQLResultSetToList(resultSet, ALIAS_SERVICE_REFERENCE);
		
		if(result.size()==0) {
			throw new NoSuchServiceReferenceExistsException("Service reference with id: "+srId+" was not found!"); //$NON-NLS-1$
		}
		
		return (ServiceReference) result.get(0);
	}
	
	public String getServiceReferenceId(String srvGroupName, String portTypeNamespace, String portTypeName) throws NoSuchServiceReferenceExistsException 
	{
		for (ServiceReference servRef : getAllServiceReferences())
		{
			final String srGrpName = servRef.getLogicalSystem().getName();
			final String prtTypeName = servRef.getPorttype().getName();
			final String prtTypeNamespace = servRef.getPorttype().getNamespace();
			
			if(srGrpName.equals(srvGroupName) && prtTypeName.equals(portTypeName) && prtTypeNamespace.equals(prtTypeNamespace)) {
				return servRef.getId();
			}
		}
		
		throw new NoSuchServiceReferenceExistsException("No service reference found for the following search criteria:\nService Group: "+srvGroupName+"\nPortType Namespace: "+portTypeNamespace+"\nPortType Name: "+portTypeName); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
	}	
	
	public List<ServiceReference> getAllServiceReferences() 
	{
		final List<ServiceReference> serviceReferences = new ArrayList<ServiceReference>();
		final String query = String.format(  "select %s from \"%s\"#%s::%s withoutsubtypes as %s", //$NON-NLS-1$
				   ALIAS_SERVICE_REFERENCE, 
				   MC_MODEL_CONTAINER_NAME, 
				   PACKAGE_SERVICEREFERENCES, 
				   TYPE_SERVICE_REFERENCE, 
				   ALIAS_SERVICE_REFERENCE );
		final MQLResultSet resultSet = doQuery(query);
		final List<RefBaseObject> result = convertMQLResultSetToList(resultSet, ALIAS_SERVICE_REFERENCE);
		
		if (result == null) {
			return serviceReferences;
		}
		
		for (RefBaseObject reference : result) {
			if (reference instanceof ServiceReference) {
				serviceReferences.add((ServiceReference)reference);
			}
		}
		
		return serviceReferences;
	}	
	
	public List<String> getServiceReferenceIds(final String srvGroupName) 
	{
		final List<String> sRefIds = new ArrayList<String>();
		for (ServiceReference srvRef : getAllServiceReferences()) {
			if (srvRef.getLogicalSystem().getName().equals(srvGroupName)) {
				sRefIds.add(srvRef.getId());
			}
		}
		
		return sRefIds;
	}	
	
	public Map<QName, List<ServiceReference>> getServiceReferences(final Collection<QName> portTypeNames) 
	{
		final  Map<QName, List<ServiceReference>> found = new HashMap<QName, List<ServiceReference>>(portTypeNames.size());
		for (QName name : portTypeNames) {
			found.put(name, new ArrayList<ServiceReference>());
		}
		
		final  List<ServiceReference> allServiceRefs = getAllServiceReferences();
		for (QName portTypeName : portTypeNames) 
		{
			for (ServiceReference ref : allServiceRefs) {
				if (ref.getPorttype().getName().equals(portTypeName.getLocalPart()) && 
					ref.getPorttype().getNamespace().equals(portTypeName.getNamespaceURI())) {
					found.get(portTypeName).add(ref);
				}
			}
		}
		
		return found;
	}
	
	@SuppressWarnings("unchecked")
	protected <T extends RefBaseObject> List<T> convertMQLResultSetToList(	MQLResultSet resultSet, 
																			String objectAlias ) 
	{
		List<T> result = new ArrayList<T>( resultSet.getSize() );
		for ( int i = 0; i < resultSet.getSize(); i++ ) 
		{
			MRI mri = resultSet.getMri(i, objectAlias);
			RefBaseObject object = this.connection.getElement( mri );
			if ( object != null ) 
			{
				result.add( (T)object );
			}
		}
		return result;	
	}
	
	public String getServiceGroupName(LogicalSystem srvGroup) {
		final Partitionable part = (Partitionable) srvGroup;
		final String partitionName = part.get___Partition().getPri().getPartitionName();
		
		final String pathDelimiter = "/"; //$NON-NLS-1$
		String packageName = ""; //$NON-NLS-1$
		
		final int firstDelimPosition = partitionName.indexOf(pathDelimiter);
	
		if (firstDelimPosition != -1 && firstDelimPosition != partitionName.lastIndexOf(pathDelimiter)) {
			packageName = partitionName.substring("mc".length() + 1, 
					partitionName.lastIndexOf(pathDelimiter)); //$NON-NLS-1$
		}
		packageName = packageName.replace(pathDelimiter, "."); //$NON-NLS-1$
		
		return (packageName.length()==0 ? srvGroup.getName() : packageName+"."+srvGroup.getName()); //$NON-NLS-1$
	}
	
	public List<LogicalSystem> getLogicalSystems() {
		String query = String.format(  "select %s from \"%s\"#%s::%s withoutsubtypes as %s", //$NON-NLS-1$
		   		   ALIAS_LOGICAL_SYSTEM, //$NON-NLS-1$
		   		   MC_MODEL_CONTAINER_NAME, //$NON-NLS-1$
		   		   PACKAGE_LOGICALSYSTEM, //$NON-NLS-1$
		   		   TYPE_LOGICAL_SYSTEM, //$NON-NLS-1$
				   ALIAS_LOGICAL_SYSTEM ); //$NON-NLS-1$

	
		final MQLResultSet resultSet = doQuery(query);
		final List<RefBaseObject> result = convertMQLResultSetToList(resultSet, ALIAS_LOGICAL_SYSTEM);
		
		List<LogicalSystem> serviceGroups = new ArrayList<LogicalSystem>();
		
		for(RefBaseObject srvGroup : result) {
			if(srvGroup instanceof LogicalSystem) {
				serviceGroups.add((LogicalSystem)srvGroup);
			}
		}
		
		return serviceGroups;
 	}
}
