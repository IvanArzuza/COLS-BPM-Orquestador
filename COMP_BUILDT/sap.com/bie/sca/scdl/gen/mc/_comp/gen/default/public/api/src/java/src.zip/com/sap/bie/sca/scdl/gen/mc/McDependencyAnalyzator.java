package com.sap.bie.sca.scdl.gen.mc;

import com.sap.tc.buildplugin.api.IPluginBuildInfo;
import com.sap.tc.buildplugin.pp.api.IComponentDependencies;
import com.sap.tc.buildplugin.pp.api.IComponentDependency;

/**
 * Utility class to be used by contributors to SCDL generation and validate that the DC  
 * dependencies to the supported Mass Configuration build infrastructure are set correctly
 * and the correct archive will be produced. 
 * 
 * @author i036201 Georgi Hristov
 *
 */
public class McDependencyAnalyzator {
	private static McDependencyAnalyzator mcDepAnalyzator;
	private static final String BIE_SCA_SCDL_GEN = "bie/sca/scdl/gen";
	private static final String TC_BI_MCTECH = "tc/bi/mctech";
	
	private McDependencyAnalyzator() {
		
	}
	
	public static McDependencyAnalyzator getInstance() {
		if(mcDepAnalyzator==null) {
			mcDepAnalyzator = new McDependencyAnalyzator();
		}
		
		return mcDepAnalyzator;
	}
	
	/**
	 * Utility method for validating the DC dependencies to Mass Configuration build 
	 * infrastructure.  
	 * 
	 * @param pbi descriptor object representing the currently built dc
	 * @return <code>true</code> if the currently built dc is SCDL generation enabled
	 * or <code>false</code> if it is *.cfgar enabled
	 * @throws IllegalMcDependenciesDetected if the currently built dc has simultaneously
	 * dependencies to SCDL generation and to *.cfgar build dc
	 * @throws NoMcDependenciesDetected if the currently built dc does not have any dependency
	 * to the SCDL generation and to *.cfgar build dc 
	 */
	public boolean isScdlGenerationEnabled(IPluginBuildInfo pbi) throws IllegalMcDependenciesDetected, NoMcDependenciesDetected {
		boolean isScdlGenerationEnabled = false;
		boolean isMcTechEnabled = false;
		
		IComponentDependencies dependencies = pbi.getDependencies();
		
		for (IComponentDependency dep: dependencies){
			if (TC_BI_MCTECH.equals(dep.getComponentName()) && dep.isAtBuild()){
				isMcTechEnabled = true;
			}
			else if (BIE_SCA_SCDL_GEN.equals(dep.getComponentName()) && dep.isAtBuild()){
				isScdlGenerationEnabled = true;
			}
		}
		
		if(isScdlGenerationEnabled && isMcTechEnabled) {
			throw new IllegalMcDependenciesDetected("The dc: "+pbi.getDCName()+" has simultaneous dependencies to SCDL generation and old cfgar packaging concept. As a result the produced archive won't be deployable !"); //NON-NLS-1 //NON-NLS-2
		}
		
		if(!isScdlGenerationEnabled && !isMcTechEnabled) {
			throw new NoMcDependenciesDetected("The dc: "+pbi.getDCName()+" has no dependency to SCDL generation or to old cfgar packaging concept. As a result the produced archive won't contain any Smart Configuration related metadata !"); //NON-NLS-1
		}
		
		return isScdlGenerationEnabled;
	}

}
