package com.sap.bie.sca.scdl.gen.mc;

public class McNamespaceConstants 
{
	public static final String AUTHENTICATION_PROFILE = "authenticationProfile"; //$NON-NLS-1$
	public static final String SERVICE_GROUP = "serviceGroup"; //$NON-NLS-1$
	
	public static final String SAPCONFIG_NAMESPACE_NAME = "sapconfig"; //$NON-NLS-1$
	public static final String SAPCONFIG_NAMESPACE_VALUE = "http://www.sap.com/webas/2007/03/esoa/config/system"; //$NON-NLS-1$ 
	
	public static final String BINDING_RFC_NAMESPACE_NAME = "sapbindingrfc"; //$NON-NLS-1$
	public static final String BINDING_RFC_NAMESPACE_VALUE = "http://www.sap.com/xmlns/sapsca/rfc/1.0"; //$NON-NLS-1$
	
	public static final String WSDL_LOC_NAMESPACE_NAME = "sapinterfacewsdlloc"; //$NON-NLS-1$
	public static final String WSDL_LOC_NAMESPACE_VALUE = "http://www.sap.com/xmlns/sapsca/1.0"; //$NON-NLS-1$
}
