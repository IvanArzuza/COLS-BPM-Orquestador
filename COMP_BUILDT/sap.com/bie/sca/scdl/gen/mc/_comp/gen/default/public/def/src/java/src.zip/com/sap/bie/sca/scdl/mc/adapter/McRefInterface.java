package com.sap.bie.sca.scdl.mc.adapter;

import java.text.MessageFormat;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.IAttributeValue;
import com.sap.bie.sca.scdl.adapter.ICustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.AttributeValue;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlAttribute;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;
import com.sap.bie.sca.scdl.adapter.impl.Interface;
import com.sap.bie.sca.scdl.gen.mc.McNamespaceConstants;

public class McRefInterface extends Interface
{
	private static final String LOCATION_ATTRIBUTE = "location"; //$NON-NLS-1$
	private static final String INTERFACE_ATTRIBUTE = "interface"; //$NON-NLS-1$
	private static final String INTERFACE_WSDL = "wsdl"; //$NON-NLS-1$
	
	public McRefInterface(final QName portTypeName, final String wsdlLocation) 
	{
		super(INTERFACE_WSDL);
		
		if (portTypeName == null) {
			throw new NullPointerException("supplied portTypeName should not be null"); //$NON-NLS-1$
		}
		
		CustomScdlElement mcRefInterface = new CustomScdlElement(getName()); 
		addAttributes(portTypeName, wsdlLocation);
		
		for(ICustomScdlAttribute attrib : getCustomAttributes()) {
			mcRefInterface.addAttribute(attrib);
		}
		
		addCustomElement(mcRefInterface);
	}
	
	private void addAttributes(final QName portTypeName, final String wsdlLocation) 
	{
		final String valuePattern = "{0}#wsdl.interface({1})"; //$NON-NLS-1$
		final QName value = new QName(MessageFormat.format(valuePattern, portTypeName.getNamespaceURI(), portTypeName.getLocalPart()));
		addAttribute(new CustomScdlAttribute(new QName(INTERFACE_ATTRIBUTE), new AttributeValue(value)));
		
		if(wsdlLocation!=null && wsdlLocation.trim().length()>0) {
			final IAttributeValue locationValue = new AttributeValue(new QName(wsdlLocation));
			addAttribute(new CustomScdlAttribute(new QName(McNamespaceConstants.WSDL_LOC_NAMESPACE_VALUE, LOCATION_ATTRIBUTE, McNamespaceConstants.WSDL_LOC_NAMESPACE_NAME), locationValue));
		}
	}
}
