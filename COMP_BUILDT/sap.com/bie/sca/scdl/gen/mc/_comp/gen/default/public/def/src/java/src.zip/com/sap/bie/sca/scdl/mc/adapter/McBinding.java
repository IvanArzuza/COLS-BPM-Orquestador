package com.sap.bie.sca.scdl.mc.adapter;

import javax.xml.namespace.QName;

import com.sap.bie.sca.scdl.adapter.impl.Binding;
import com.sap.bie.sca.scdl.adapter.impl.CustomScdlElement;

public class McBinding extends Binding 
{
	public McBinding(final QName bindingType) {
		super(new QName(bindingType.getNamespaceURI(), "binding." + bindingType.getLocalPart(), bindingType.getPrefix())); //$NON-NLS-1$
		
		addCustomElement(new CustomScdlElement(getName()));
	}
}
